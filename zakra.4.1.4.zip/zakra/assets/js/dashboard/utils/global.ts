import { zakraLocalized } from '../types';

export const localized: zakraLocalized = (window as any)._ZAKRA_DASHBOARD_;
