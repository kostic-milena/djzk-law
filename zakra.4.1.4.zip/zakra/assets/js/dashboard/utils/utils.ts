const localized: {
	enable_mega_menu: boolean;
} = (window as any).__ZAKRA_SETTINGS__;

export { localized };
