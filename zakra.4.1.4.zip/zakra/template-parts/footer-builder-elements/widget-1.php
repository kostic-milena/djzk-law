<?php

dynamic_sidebar( 'footer-sidebar-1' );
