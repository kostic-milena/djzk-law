<?php
$html_2 = get_theme_mod( 'zakra_header_html_2', '' );
echo '<div class="zak-html-2">';
echo $html_2;
echo '</div>';
