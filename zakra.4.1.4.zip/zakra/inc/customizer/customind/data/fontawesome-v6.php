<?php return [
	[
		'name'  => '0',
		'class' => 'fa-solid fa-0',
	],
	[
		'name'  => '1',
		'class' => 'fa-solid fa-1',
	],
	[
		'name'  => '2',
		'class' => 'fa-solid fa-2',
	],
	[
		'name'  => '3',
		'class' => 'fa-solid fa-3',
	],
	[
		'name'  => '4',
		'class' => 'fa-solid fa-4',
	],
	[
		'name'  => '5',
		'class' => 'fa-solid fa-5',
	],
	[
		'name'  => '6',
		'class' => 'fa-solid fa-6',
	],
	[
		'name'  => '7',
		'class' => 'fa-solid fa-7',
	],
	[
		'name'  => '8',
		'class' => 'fa-solid fa-8',
	],
	[
		'name'  => '9',
		'class' => 'fa-solid fa-9',
	],
	[
		'name'  => '42.group',
		'class' => 'fa-brands fa-42-group',
	],
	[
		'name'  => '500px',
		'class' => 'fa-brands fa-500px',
	],
	[
		'name'  => 'A',
		'class' => 'fa-solid fa-a',
	],
	[
		'name'  => 'Accessible Icon',
		'class' => 'fa-brands fa-accessible-icon',
	],
	[
		'name'  => 'Accusoft',
		'class' => 'fa-brands fa-accusoft',
	],
	[
		'name'  => 'Address Book',
		'class' => 'fa-solid fa-address-book',
	],
	[
		'name'  => 'Address Card',
		'class' => 'fa-solid fa-address-card',
	],
	[
		'name'  => 'App.net',
		'class' => 'fa-brands fa-adn',
	],
	[
		'name'  => 'Adversal',
		'class' => 'fa-brands fa-adversal',
	],
	[
		'name'  => 'affiliatetheme',
		'class' => 'fa-brands fa-affiliatetheme',
	],
	[
		'name'  => 'Airbnb',
		'class' => 'fa-brands fa-airbnb',
	],
	[
		'name'  => 'Algolia',
		'class' => 'fa-brands fa-algolia',
	],
	[
		'name'  => 'Align Center',
		'class' => 'fa-solid fa-align-center',
	],
	[
		'name'  => 'Align Justify',
		'class' => 'fa-solid fa-align-justify',
	],
	[
		'name'  => 'Align Left',
		'class' => 'fa-solid fa-align-left',
	],
	[
		'name'  => 'Align Right',
		'class' => 'fa-solid fa-align-right',
	],
	[
		'name'  => 'Alipay',
		'class' => 'fa-brands fa-alipay',
	],
	[
		'name'  => 'Amazon',
		'class' => 'fa-brands fa-amazon',
	],
	[
		'name'  => 'Amazon Pay',
		'class' => 'fa-brands fa-amazon-pay',
	],
	[
		'name'  => 'Amilia',
		'class' => 'fa-brands fa-amilia',
	],
	[
		'name'  => 'Anchor',
		'class' => 'fa-solid fa-anchor',
	],
	[
		'name'  => 'Anchor Circle Check',
		'class' => 'fa-solid fa-anchor-circle-check',
	],
	[
		'name'  => 'Anchor Circle Exclamation',
		'class' => 'fa-solid fa-anchor-circle-exclamation',
	],
	[
		'name'  => 'Anchor Circle Xmark',
		'class' => 'fa-solid fa-anchor-circle-xmark',
	],
	[
		'name'  => 'Anchor Lock',
		'class' => 'fa-solid fa-anchor-lock',
	],
	[
		'name'  => 'Android',
		'class' => 'fa-brands fa-android',
	],
	[
		'name'  => 'AngelList',
		'class' => 'fa-brands fa-angellist',
	],
	[
		'name'  => 'Angle Down',
		'class' => 'fa-solid fa-angle-down',
	],
	[
		'name'  => 'Angle Left',
		'class' => 'fa-solid fa-angle-left',
	],
	[
		'name'  => 'Angle Right',
		'class' => 'fa-solid fa-angle-right',
	],
	[
		'name'  => 'Angle Up',
		'class' => 'fa-solid fa-angle-up',
	],
	[
		'name'  => 'Angles Down',
		'class' => 'fa-solid fa-angles-down',
	],
	[
		'name'  => 'Angles Left',
		'class' => 'fa-solid fa-angles-left',
	],
	[
		'name'  => 'Angles Right',
		'class' => 'fa-solid fa-angles-right',
	],
	[
		'name'  => 'Angles Up',
		'class' => 'fa-solid fa-angles-up',
	],
	[
		'name'  => 'Angry Creative',
		'class' => 'fa-brands fa-angrycreative',
	],
	[
		'name'  => 'Angular',
		'class' => 'fa-brands fa-angular',
	],
	[
		'name'  => 'Ankh',
		'class' => 'fa-solid fa-ankh',
	],
	[
		'name'  => 'App Store',
		'class' => 'fa-brands fa-app-store',
	],
	[
		'name'  => 'iOS App Store',
		'class' => 'fa-brands fa-app-store-ios',
	],
	[
		'name'  => 'Apper Systems AB',
		'class' => 'fa-brands fa-apper',
	],
	[
		'name'  => 'Apple',
		'class' => 'fa-brands fa-apple',
	],
	[
		'name'  => 'Apple Pay',
		'class' => 'fa-brands fa-apple-pay',
	],
	[
		'name'  => 'Apple Whole',
		'class' => 'fa-solid fa-apple-whole',
	],
	[
		'name'  => 'Archway',
		'class' => 'fa-solid fa-archway',
	],
	[
		'name'  => 'Arrow Down',
		'class' => 'fa-solid fa-arrow-down',
	],
	[
		'name'  => 'Arrow Down 1 9',
		'class' => 'fa-solid fa-arrow-down-1-9',
	],
	[
		'name'  => 'Arrow Down 9 1',
		'class' => 'fa-solid fa-arrow-down-9-1',
	],
	[
		'name'  => 'Arrow Down A Z',
		'class' => 'fa-solid fa-arrow-down-a-z',
	],
	[
		'name'  => 'Arrow Down Long',
		'class' => 'fa-solid fa-arrow-down-long',
	],
	[
		'name'  => 'Arrow Down Short Wide',
		'class' => 'fa-solid fa-arrow-down-short-wide',
	],
	[
		'name'  => 'Arrow Down Up Across Line',
		'class' => 'fa-solid fa-arrow-down-up-across-line',
	],
	[
		'name'  => 'Arrow Down Up Lock',
		'class' => 'fa-solid fa-arrow-down-up-lock',
	],
	[
		'name'  => 'Arrow Down Wide Short',
		'class' => 'fa-solid fa-arrow-down-wide-short',
	],
	[
		'name'  => 'Arrow Down Z A',
		'class' => 'fa-solid fa-arrow-down-z-a',
	],
	[
		'name'  => 'Arrow Left',
		'class' => 'fa-solid fa-arrow-left',
	],
	[
		'name'  => 'Arrow Left Long',
		'class' => 'fa-solid fa-arrow-left-long',
	],
	[
		'name'  => 'Arrow Pointer',
		'class' => 'fa-solid fa-arrow-pointer',
	],
	[
		'name'  => 'Arrow Right',
		'class' => 'fa-solid fa-arrow-right',
	],
	[
		'name'  => 'Arrow Right Arrow Left',
		'class' => 'fa-solid fa-arrow-right-arrow-left',
	],
	[
		'name'  => 'Arrow Right From Bracket',
		'class' => 'fa-solid fa-arrow-right-from-bracket',
	],
	[
		'name'  => 'Arrow Right Long',
		'class' => 'fa-solid fa-arrow-right-long',
	],
	[
		'name'  => 'Arrow Right To Bracket',
		'class' => 'fa-solid fa-arrow-right-to-bracket',
	],
	[
		'name'  => 'Arrow Right To City',
		'class' => 'fa-solid fa-arrow-right-to-city',
	],
	[
		'name'  => 'Arrow Rotate Left',
		'class' => 'fa-solid fa-arrow-rotate-left',
	],
	[
		'name'  => 'Arrow Rotate Right',
		'class' => 'fa-solid fa-arrow-rotate-right',
	],
	[
		'name'  => 'Arrow Trend Down',
		'class' => 'fa-solid fa-arrow-trend-down',
	],
	[
		'name'  => 'Arrow Trend Up',
		'class' => 'fa-solid fa-arrow-trend-up',
	],
	[
		'name'  => 'Arrow Turn Down',
		'class' => 'fa-solid fa-arrow-turn-down',
	],
	[
		'name'  => 'Arrow Turn Up',
		'class' => 'fa-solid fa-arrow-turn-up',
	],
	[
		'name'  => 'Arrow Up',
		'class' => 'fa-solid fa-arrow-up',
	],
	[
		'name'  => 'Arrow Up 1 9',
		'class' => 'fa-solid fa-arrow-up-1-9',
	],
	[
		'name'  => 'Arrow Up 9 1',
		'class' => 'fa-solid fa-arrow-up-9-1',
	],
	[
		'name'  => 'Arrow Up A Z',
		'class' => 'fa-solid fa-arrow-up-a-z',
	],
	[
		'name'  => 'Arrow Up From Bracket',
		'class' => 'fa-solid fa-arrow-up-from-bracket',
	],
	[
		'name'  => 'Arrow Up From Ground Water',
		'class' => 'fa-solid fa-arrow-up-from-ground-water',
	],
	[
		'name'  => 'Arrow Up From Water Pump',
		'class' => 'fa-solid fa-arrow-up-from-water-pump',
	],
	[
		'name'  => 'Arrow Up Long',
		'class' => 'fa-solid fa-arrow-up-long',
	],
	[
		'name'  => 'Arrow Up Right Dots',
		'class' => 'fa-solid fa-arrow-up-right-dots',
	],
	[
		'name'  => 'Arrow Up Right From Square',
		'class' => 'fa-solid fa-arrow-up-right-from-square',
	],
	[
		'name'  => 'Arrow Up Short Wide',
		'class' => 'fa-solid fa-arrow-up-short-wide',
	],
	[
		'name'  => 'Arrow Up Wide Short',
		'class' => 'fa-solid fa-arrow-up-wide-short',
	],
	[
		'name'  => 'Arrow Up Z A',
		'class' => 'fa-solid fa-arrow-up-z-a',
	],
	[
		'name'  => 'Arrows Down To Line',
		'class' => 'fa-solid fa-arrows-down-to-line',
	],
	[
		'name'  => 'Arrows Down To People',
		'class' => 'fa-solid fa-arrows-down-to-people',
	],
	[
		'name'  => 'Arrows Left Right',
		'class' => 'fa-solid fa-arrows-left-right',
	],
	[
		'name'  => 'Arrows Left Right To Line',
		'class' => 'fa-solid fa-arrows-left-right-to-line',
	],
	[
		'name'  => 'Arrows Rotate',
		'class' => 'fa-solid fa-arrows-rotate',
	],
	[
		'name'  => 'Arrows Spin',
		'class' => 'fa-solid fa-arrows-spin',
	],
	[
		'name'  => 'Arrows Split Up And Left',
		'class' => 'fa-solid fa-arrows-split-up-and-left',
	],
	[
		'name'  => 'Arrows To Circle',
		'class' => 'fa-solid fa-arrows-to-circle',
	],
	[
		'name'  => 'Arrows To Dot',
		'class' => 'fa-solid fa-arrows-to-dot',
	],
	[
		'name'  => 'Arrows To Eye',
		'class' => 'fa-solid fa-arrows-to-eye',
	],
	[
		'name'  => 'Arrows Turn Right',
		'class' => 'fa-solid fa-arrows-turn-right',
	],
	[
		'name'  => 'Arrows Turn To Dots',
		'class' => 'fa-solid fa-arrows-turn-to-dots',
	],
	[
		'name'  => 'Arrows Up Down',
		'class' => 'fa-solid fa-arrows-up-down',
	],
	[
		'name'  => 'Arrows Up Down Left Right',
		'class' => 'fa-solid fa-arrows-up-down-left-right',
	],
	[
		'name'  => 'Arrows Up To Line',
		'class' => 'fa-solid fa-arrows-up-to-line',
	],
	[
		'name'  => 'Artstation',
		'class' => 'fa-brands fa-artstation',
	],
	[
		'name'  => 'Asterisk',
		'class' => 'fa-solid fa-asterisk',
	],
	[
		'name'  => 'Asymmetrik, Ltd.',
		'class' => 'fa-brands fa-asymmetrik',
	],
	[
		'name'  => 'At',
		'class' => 'fa-solid fa-at',
	],
	[
		'name'  => 'Atlassian',
		'class' => 'fa-brands fa-atlassian',
	],
	[
		'name'  => 'Atom',
		'class' => 'fa-solid fa-atom',
	],
	[
		'name'  => 'Audible',
		'class' => 'fa-brands fa-audible',
	],
	[
		'name'  => 'Audio Description',
		'class' => 'fa-solid fa-audio-description',
	],
	[
		'name'  => 'Austral Sign',
		'class' => 'fa-solid fa-austral-sign',
	],
	[
		'name'  => 'Autoprefixer',
		'class' => 'fa-brands fa-autoprefixer',
	],
	[
		'name'  => 'avianex',
		'class' => 'fa-brands fa-avianex',
	],
	[
		'name'  => 'Aviato',
		'class' => 'fa-brands fa-aviato',
	],
	[
		'name'  => 'Award',
		'class' => 'fa-solid fa-award',
	],
	[
		'name'  => 'Amazon Web Services (AWS)',
		'class' => 'fa-brands fa-aws',
	],
	[
		'name'  => 'B',
		'class' => 'fa-solid fa-b',
	],
	[
		'name'  => 'Baby',
		'class' => 'fa-solid fa-baby',
	],
	[
		'name'  => 'Baby Carriage',
		'class' => 'fa-solid fa-baby-carriage',
	],
	[
		'name'  => 'Backward',
		'class' => 'fa-solid fa-backward',
	],
	[
		'name'  => 'Backward Fast',
		'class' => 'fa-solid fa-backward-fast',
	],
	[
		'name'  => 'Backward Step',
		'class' => 'fa-solid fa-backward-step',
	],
	[
		'name'  => 'Bacon',
		'class' => 'fa-solid fa-bacon',
	],
	[
		'name'  => 'Bacteria',
		'class' => 'fa-solid fa-bacteria',
	],
	[
		'name'  => 'Bacterium',
		'class' => 'fa-solid fa-bacterium',
	],
	[
		'name'  => 'Bag Shopping',
		'class' => 'fa-solid fa-bag-shopping',
	],
	[
		'name'  => 'Bahai',
		'class' => 'fa-solid fa-bahai',
	],
	[
		'name'  => 'Baht Sign',
		'class' => 'fa-solid fa-baht-sign',
	],
	[
		'name'  => 'Ban',
		'class' => 'fa-solid fa-ban',
	],
	[
		'name'  => 'Ban Smoking',
		'class' => 'fa-solid fa-ban-smoking',
	],
	[
		'name'  => 'Bandage',
		'class' => 'fa-solid fa-bandage',
	],
	[
		'name'  => 'Bandcamp',
		'class' => 'fa-brands fa-bandcamp',
	],
	[
		'name'  => 'Bangladeshi Taka Sign',
		'class' => 'fa-solid fa-bangladeshi-taka-sign',
	],
	[
		'name'  => 'Barcode',
		'class' => 'fa-solid fa-barcode',
	],
	[
		'name'  => 'Bars',
		'class' => 'fa-solid fa-bars',
	],
	[
		'name'  => 'Bars Progress',
		'class' => 'fa-solid fa-bars-progress',
	],
	[
		'name'  => 'Bars Staggered',
		'class' => 'fa-solid fa-bars-staggered',
	],
	[
		'name'  => 'Baseball',
		'class' => 'fa-solid fa-baseball',
	],
	[
		'name'  => 'Baseball Bat Ball',
		'class' => 'fa-solid fa-baseball-bat-ball',
	],
	[
		'name'  => 'Basket Shopping',
		'class' => 'fa-solid fa-basket-shopping',
	],
	[
		'name'  => 'Basketball',
		'class' => 'fa-solid fa-basketball',
	],
	[
		'name'  => 'Bath',
		'class' => 'fa-solid fa-bath',
	],
	[
		'name'  => 'Battery Empty',
		'class' => 'fa-solid fa-battery-empty',
	],
	[
		'name'  => 'Battery Full',
		'class' => 'fa-solid fa-battery-full',
	],
	[
		'name'  => 'Battery Half',
		'class' => 'fa-solid fa-battery-half',
	],
	[
		'name'  => 'Battery Quarter',
		'class' => 'fa-solid fa-battery-quarter',
	],
	[
		'name'  => 'Battery Three Quarters',
		'class' => 'fa-solid fa-battery-three-quarters',
	],
	[
		'name'  => 'Battle.net',
		'class' => 'fa-brands fa-battle-net',
	],
	[
		'name'  => 'Bed',
		'class' => 'fa-solid fa-bed',
	],
	[
		'name'  => 'Bed Pulse',
		'class' => 'fa-solid fa-bed-pulse',
	],
	[
		'name'  => 'Beer Mug Empty',
		'class' => 'fa-solid fa-beer-mug-empty',
	],
	[
		'name'  => 'Behance',
		'class' => 'fa-brands fa-behance',
	],
	[
		'name'  => 'Bell',
		'class' => 'fa-solid fa-bell',
	],
	[
		'name'  => 'Bell Concierge',
		'class' => 'fa-solid fa-bell-concierge',
	],
	[
		'name'  => 'Bell Slash',
		'class' => 'fa-solid fa-bell-slash',
	],
	[
		'name'  => 'Bezier Curve',
		'class' => 'fa-solid fa-bezier-curve',
	],
	[
		'name'  => 'Bicycle',
		'class' => 'fa-solid fa-bicycle',
	],
	[
		'name'  => 'Bilibili',
		'class' => 'fa-brands fa-bilibili',
	],
	[
		'name'  => 'BIMobject',
		'class' => 'fa-brands fa-bimobject',
	],
	[
		'name'  => 'Binoculars',
		'class' => 'fa-solid fa-binoculars',
	],
	[
		'name'  => 'Biohazard',
		'class' => 'fa-solid fa-biohazard',
	],
	[
		'name'  => 'Bitbucket',
		'class' => 'fa-brands fa-bitbucket',
	],
	[
		'name'  => 'Bitcoin',
		'class' => 'fa-brands fa-bitcoin',
	],
	[
		'name'  => 'Bitcoin Sign',
		'class' => 'fa-solid fa-bitcoin-sign',
	],
	[
		'name'  => 'Bity',
		'class' => 'fa-brands fa-bity',
	],
	[
		'name'  => 'Font Awesome Black Tie',
		'class' => 'fa-brands fa-black-tie',
	],
	[
		'name'  => 'BlackBerry',
		'class' => 'fa-brands fa-blackberry',
	],
	[
		'name'  => 'Blender',
		'class' => 'fa-solid fa-blender',
	],
	[
		'name'  => 'Blender Phone',
		'class' => 'fa-solid fa-blender-phone',
	],
	[
		'name'  => 'Blog',
		'class' => 'fa-solid fa-blog',
	],
	[
		'name'  => 'Blogger',
		'class' => 'fa-brands fa-blogger',
	],
	[
		'name'  => 'Blogger B',
		'class' => 'fa-brands fa-blogger-b',
	],
	[
		'name'  => 'Bluesky',
		'class' => 'fa-brands fa-bluesky',
	],
	[
		'name'  => 'Bluetooth',
		'class' => 'fa-brands fa-bluetooth',
	],
	[
		'name'  => 'Bluetooth',
		'class' => 'fa-brands fa-bluetooth-b',
	],
	[
		'name'  => 'Bold',
		'class' => 'fa-solid fa-bold',
	],
	[
		'name'  => 'Bolt',
		'class' => 'fa-solid fa-bolt',
	],
	[
		'name'  => 'Bolt Lightning',
		'class' => 'fa-solid fa-bolt-lightning',
	],
	[
		'name'  => 'Bomb',
		'class' => 'fa-solid fa-bomb',
	],
	[
		'name'  => 'Bone',
		'class' => 'fa-solid fa-bone',
	],
	[
		'name'  => 'Bong',
		'class' => 'fa-solid fa-bong',
	],
	[
		'name'  => 'Book',
		'class' => 'fa-solid fa-book',
	],
	[
		'name'  => 'Book Atlas',
		'class' => 'fa-solid fa-book-atlas',
	],
	[
		'name'  => 'Book Bible',
		'class' => 'fa-solid fa-book-bible',
	],
	[
		'name'  => 'Book Bookmark',
		'class' => 'fa-solid fa-book-bookmark',
	],
	[
		'name'  => 'Book Journal Whills',
		'class' => 'fa-solid fa-book-journal-whills',
	],
	[
		'name'  => 'Book Medical',
		'class' => 'fa-solid fa-book-medical',
	],
	[
		'name'  => 'Book Open',
		'class' => 'fa-solid fa-book-open',
	],
	[
		'name'  => 'Book Open Reader',
		'class' => 'fa-solid fa-book-open-reader',
	],
	[
		'name'  => 'Book Quran',
		'class' => 'fa-solid fa-book-quran',
	],
	[
		'name'  => 'Book Skull',
		'class' => 'fa-solid fa-book-skull',
	],
	[
		'name'  => 'Book Tanakh',
		'class' => 'fa-solid fa-book-tanakh',
	],
	[
		'name'  => 'Bookmark',
		'class' => 'fa-solid fa-bookmark',
	],
	[
		'name'  => 'Bootstrap',
		'class' => 'fa-brands fa-bootstrap',
	],
	[
		'name'  => 'Border All',
		'class' => 'fa-solid fa-border-all',
	],
	[
		'name'  => 'Border None',
		'class' => 'fa-solid fa-border-none',
	],
	[
		'name'  => 'Border Top Left',
		'class' => 'fa-solid fa-border-top-left',
	],
	[
		'name'  => 'Bore Hole',
		'class' => 'fa-solid fa-bore-hole',
	],
	[
		'name'  => 'Bots',
		'class' => 'fa-brands fa-bots',
	],
	[
		'name'  => 'Bottle Droplet',
		'class' => 'fa-solid fa-bottle-droplet',
	],
	[
		'name'  => 'Bottle Water',
		'class' => 'fa-solid fa-bottle-water',
	],
	[
		'name'  => 'Bowl Food',
		'class' => 'fa-solid fa-bowl-food',
	],
	[
		'name'  => 'Bowl Rice',
		'class' => 'fa-solid fa-bowl-rice',
	],
	[
		'name'  => 'Bowling Ball',
		'class' => 'fa-solid fa-bowling-ball',
	],
	[
		'name'  => 'Box',
		'class' => 'fa-solid fa-box',
	],
	[
		'name'  => 'Box Archive',
		'class' => 'fa-solid fa-box-archive',
	],
	[
		'name'  => 'Box Open',
		'class' => 'fa-solid fa-box-open',
	],
	[
		'name'  => 'Box Tissue',
		'class' => 'fa-solid fa-box-tissue',
	],
	[
		'name'  => 'Boxes Packing',
		'class' => 'fa-solid fa-boxes-packing',
	],
	[
		'name'  => 'Boxes Stacked',
		'class' => 'fa-solid fa-boxes-stacked',
	],
	[
		'name'  => 'Braille',
		'class' => 'fa-solid fa-braille',
	],
	[
		'name'  => 'Brain',
		'class' => 'fa-solid fa-brain',
	],
	[
		'name'  => 'Brave',
		'class' => 'fa-brands fa-brave',
	],
	[
		'name'  => 'Brave Reverse',
		'class' => 'fa-brands fa-brave-reverse',
	],
	[
		'name'  => 'Brazilian Real Sign',
		'class' => 'fa-solid fa-brazilian-real-sign',
	],
	[
		'name'  => 'Bread Slice',
		'class' => 'fa-solid fa-bread-slice',
	],
	[
		'name'  => 'Bridge',
		'class' => 'fa-solid fa-bridge',
	],
	[
		'name'  => 'Bridge Circle Check',
		'class' => 'fa-solid fa-bridge-circle-check',
	],
	[
		'name'  => 'Bridge Circle Exclamation',
		'class' => 'fa-solid fa-bridge-circle-exclamation',
	],
	[
		'name'  => 'Bridge Circle Xmark',
		'class' => 'fa-solid fa-bridge-circle-xmark',
	],
	[
		'name'  => 'Bridge Lock',
		'class' => 'fa-solid fa-bridge-lock',
	],
	[
		'name'  => 'Bridge Water',
		'class' => 'fa-solid fa-bridge-water',
	],
	[
		'name'  => 'Briefcase',
		'class' => 'fa-solid fa-briefcase',
	],
	[
		'name'  => 'Briefcase Medical',
		'class' => 'fa-solid fa-briefcase-medical',
	],
	[
		'name'  => 'Broom',
		'class' => 'fa-solid fa-broom',
	],
	[
		'name'  => 'Broom Ball',
		'class' => 'fa-solid fa-broom-ball',
	],
	[
		'name'  => 'Brush',
		'class' => 'fa-solid fa-brush',
	],
	[
		'name'  => 'BTC',
		'class' => 'fa-brands fa-btc',
	],
	[
		'name'  => 'Bucket',
		'class' => 'fa-solid fa-bucket',
	],
	[
		'name'  => 'Buffer',
		'class' => 'fa-brands fa-buffer',
	],
	[
		'name'  => 'Bug',
		'class' => 'fa-solid fa-bug',
	],
	[
		'name'  => 'Bug Slash',
		'class' => 'fa-solid fa-bug-slash',
	],
	[
		'name'  => 'Bugs',
		'class' => 'fa-solid fa-bugs',
	],
	[
		'name'  => 'Building',
		'class' => 'fa-solid fa-building',
	],
	[
		'name'  => 'Building Circle Arrow Right',
		'class' => 'fa-solid fa-building-circle-arrow-right',
	],
	[
		'name'  => 'Building Circle Check',
		'class' => 'fa-solid fa-building-circle-check',
	],
	[
		'name'  => 'Building Circle Exclamation',
		'class' => 'fa-solid fa-building-circle-exclamation',
	],
	[
		'name'  => 'Building Circle Xmark',
		'class' => 'fa-solid fa-building-circle-xmark',
	],
	[
		'name'  => 'Building Columns',
		'class' => 'fa-solid fa-building-columns',
	],
	[
		'name'  => 'Building Flag',
		'class' => 'fa-solid fa-building-flag',
	],
	[
		'name'  => 'Building Lock',
		'class' => 'fa-solid fa-building-lock',
	],
	[
		'name'  => 'Building Ngo',
		'class' => 'fa-solid fa-building-ngo',
	],
	[
		'name'  => 'Building Shield',
		'class' => 'fa-solid fa-building-shield',
	],
	[
		'name'  => 'Building Un',
		'class' => 'fa-solid fa-building-un',
	],
	[
		'name'  => 'Building User',
		'class' => 'fa-solid fa-building-user',
	],
	[
		'name'  => 'Building Wheat',
		'class' => 'fa-solid fa-building-wheat',
	],
	[
		'name'  => 'Bullhorn',
		'class' => 'fa-solid fa-bullhorn',
	],
	[
		'name'  => 'Bullseye',
		'class' => 'fa-solid fa-bullseye',
	],
	[
		'name'  => 'Burger',
		'class' => 'fa-solid fa-burger',
	],
	[
		'name'  => 'Büromöbel-Experte GmbH & Co. KG.',
		'class' => 'fa-brands fa-buromobelexperte',
	],
	[
		'name'  => 'Burst',
		'class' => 'fa-solid fa-burst',
	],
	[
		'name'  => 'Bus',
		'class' => 'fa-solid fa-bus',
	],
	[
		'name'  => 'Bus Simple',
		'class' => 'fa-solid fa-bus-simple',
	],
	[
		'name'  => 'Business Time',
		'class' => 'fa-solid fa-business-time',
	],
	[
		'name'  => 'Buy n Large',
		'class' => 'fa-brands fa-buy-n-large',
	],
	[
		'name'  => 'BuySellAds',
		'class' => 'fa-brands fa-buysellads',
	],
	[
		'name'  => 'C',
		'class' => 'fa-solid fa-c',
	],
	[
		'name'  => 'Cable Car',
		'class' => 'fa-solid fa-cable-car',
	],
	[
		'name'  => 'Cake Candles',
		'class' => 'fa-solid fa-cake-candles',
	],
	[
		'name'  => 'Calculator',
		'class' => 'fa-solid fa-calculator',
	],
	[
		'name'  => 'Calendar',
		'class' => 'fa-solid fa-calendar',
	],
	[
		'name'  => 'Calendar Check',
		'class' => 'fa-solid fa-calendar-check',
	],
	[
		'name'  => 'Calendar Day',
		'class' => 'fa-solid fa-calendar-day',
	],
	[
		'name'  => 'Calendar Days',
		'class' => 'fa-solid fa-calendar-days',
	],
	[
		'name'  => 'Calendar Minus',
		'class' => 'fa-solid fa-calendar-minus',
	],
	[
		'name'  => 'Calendar Plus',
		'class' => 'fa-solid fa-calendar-plus',
	],
	[
		'name'  => 'Calendar Week',
		'class' => 'fa-solid fa-calendar-week',
	],
	[
		'name'  => 'Calendar Xmark',
		'class' => 'fa-solid fa-calendar-xmark',
	],
	[
		'name'  => 'Camera',
		'class' => 'fa-solid fa-camera',
	],
	[
		'name'  => 'Camera Retro',
		'class' => 'fa-solid fa-camera-retro',
	],
	[
		'name'  => 'Camera Rotate',
		'class' => 'fa-solid fa-camera-rotate',
	],
	[
		'name'  => 'Campground',
		'class' => 'fa-solid fa-campground',
	],
	[
		'name'  => 'Canadian Maple Leaf',
		'class' => 'fa-brands fa-canadian-maple-leaf',
	],
	[
		'name'  => 'Candy Cane',
		'class' => 'fa-solid fa-candy-cane',
	],
	[
		'name'  => 'Cannabis',
		'class' => 'fa-solid fa-cannabis',
	],
	[
		'name'  => 'Capsules',
		'class' => 'fa-solid fa-capsules',
	],
	[
		'name'  => 'Car',
		'class' => 'fa-solid fa-car',
	],
	[
		'name'  => 'Car Battery',
		'class' => 'fa-solid fa-car-battery',
	],
	[
		'name'  => 'Car Burst',
		'class' => 'fa-solid fa-car-burst',
	],
	[
		'name'  => 'Car On',
		'class' => 'fa-solid fa-car-on',
	],
	[
		'name'  => 'Car Rear',
		'class' => 'fa-solid fa-car-rear',
	],
	[
		'name'  => 'Car Side',
		'class' => 'fa-solid fa-car-side',
	],
	[
		'name'  => 'Car Tunnel',
		'class' => 'fa-solid fa-car-tunnel',
	],
	[
		'name'  => 'Caravan',
		'class' => 'fa-solid fa-caravan',
	],
	[
		'name'  => 'Caret Down',
		'class' => 'fa-solid fa-caret-down',
	],
	[
		'name'  => 'Caret Left',
		'class' => 'fa-solid fa-caret-left',
	],
	[
		'name'  => 'Caret Right',
		'class' => 'fa-solid fa-caret-right',
	],
	[
		'name'  => 'Caret Up',
		'class' => 'fa-solid fa-caret-up',
	],
	[
		'name'  => 'Carrot',
		'class' => 'fa-solid fa-carrot',
	],
	[
		'name'  => 'Cart Arrow Down',
		'class' => 'fa-solid fa-cart-arrow-down',
	],
	[
		'name'  => 'Cart Flatbed',
		'class' => 'fa-solid fa-cart-flatbed',
	],
	[
		'name'  => 'Cart Flatbed Suitcase',
		'class' => 'fa-solid fa-cart-flatbed-suitcase',
	],
	[
		'name'  => 'Cart Plus',
		'class' => 'fa-solid fa-cart-plus',
	],
	[
		'name'  => 'Cart Shopping',
		'class' => 'fa-solid fa-cart-shopping',
	],
	[
		'name'  => 'Cash Register',
		'class' => 'fa-solid fa-cash-register',
	],
	[
		'name'  => 'Cat',
		'class' => 'fa-solid fa-cat',
	],
	[
		'name'  => 'Amazon Pay Credit Card',
		'class' => 'fa-brands fa-cc-amazon-pay',
	],
	[
		'name'  => 'Cc Amex',
		'class' => 'fa-brands fa-cc-amex',
	],
	[
		'name'  => 'Apple Pay Credit Card',
		'class' => 'fa-brands fa-cc-apple-pay',
	],
	[
		'name'  => 'Diner\'s Club Credit Card',
		'class' => 'fa-brands fa-cc-diners-club',
	],
	[
		'name'  => 'Discover Credit Card',
		'class' => 'fa-brands fa-cc-discover',
	],
	[
		'name'  => 'JCB Credit Card',
		'class' => 'fa-brands fa-cc-jcb',
	],
	[
		'name'  => 'MasterCard Credit Card',
		'class' => 'fa-brands fa-cc-mastercard',
	],
	[
		'name'  => 'Paypal Credit Card',
		'class' => 'fa-brands fa-cc-paypal',
	],
	[
		'name'  => 'Stripe Credit Card',
		'class' => 'fa-brands fa-cc-stripe',
	],
	[
		'name'  => 'Visa Credit Card',
		'class' => 'fa-brands fa-cc-visa',
	],
	[
		'name'  => 'Cedi Sign',
		'class' => 'fa-solid fa-cedi-sign',
	],
	[
		'name'  => 'Cent Sign',
		'class' => 'fa-solid fa-cent-sign',
	],
	[
		'name'  => 'Centercode',
		'class' => 'fa-brands fa-centercode',
	],
	[
		'name'  => 'Centos',
		'class' => 'fa-brands fa-centos',
	],
	[
		'name'  => 'Certificate',
		'class' => 'fa-solid fa-certificate',
	],
	[
		'name'  => 'Chair',
		'class' => 'fa-solid fa-chair',
	],
	[
		'name'  => 'Chalkboard',
		'class' => 'fa-solid fa-chalkboard',
	],
	[
		'name'  => 'Chalkboard User',
		'class' => 'fa-solid fa-chalkboard-user',
	],
	[
		'name'  => 'Champagne Glasses',
		'class' => 'fa-solid fa-champagne-glasses',
	],
	[
		'name'  => 'Charging Station',
		'class' => 'fa-solid fa-charging-station',
	],
	[
		'name'  => 'Chart Area',
		'class' => 'fa-solid fa-chart-area',
	],
	[
		'name'  => 'Chart Bar',
		'class' => 'fa-solid fa-chart-bar',
	],
	[
		'name'  => 'Chart Column',
		'class' => 'fa-solid fa-chart-column',
	],
	[
		'name'  => 'Chart Gantt',
		'class' => 'fa-solid fa-chart-gantt',
	],
	[
		'name'  => 'Chart Line',
		'class' => 'fa-solid fa-chart-line',
	],
	[
		'name'  => 'Chart Pie',
		'class' => 'fa-solid fa-chart-pie',
	],
	[
		'name'  => 'Chart Simple',
		'class' => 'fa-solid fa-chart-simple',
	],
	[
		'name'  => 'Check',
		'class' => 'fa-solid fa-check',
	],
	[
		'name'  => 'Check Double',
		'class' => 'fa-solid fa-check-double',
	],
	[
		'name'  => 'Check To Slot',
		'class' => 'fa-solid fa-check-to-slot',
	],
	[
		'name'  => 'Cheese',
		'class' => 'fa-solid fa-cheese',
	],
	[
		'name'  => 'Chess',
		'class' => 'fa-solid fa-chess',
	],
	[
		'name'  => 'Chess Bishop',
		'class' => 'fa-solid fa-chess-bishop',
	],
	[
		'name'  => 'Chess Board',
		'class' => 'fa-solid fa-chess-board',
	],
	[
		'name'  => 'Chess King',
		'class' => 'fa-solid fa-chess-king',
	],
	[
		'name'  => 'Chess Knight',
		'class' => 'fa-solid fa-chess-knight',
	],
	[
		'name'  => 'Chess Pawn',
		'class' => 'fa-solid fa-chess-pawn',
	],
	[
		'name'  => 'Chess Queen',
		'class' => 'fa-solid fa-chess-queen',
	],
	[
		'name'  => 'Chess Rook',
		'class' => 'fa-solid fa-chess-rook',
	],
	[
		'name'  => 'Chevron Down',
		'class' => 'fa-solid fa-chevron-down',
	],
	[
		'name'  => 'Chevron Left',
		'class' => 'fa-solid fa-chevron-left',
	],
	[
		'name'  => 'Chevron Right',
		'class' => 'fa-solid fa-chevron-right',
	],
	[
		'name'  => 'Chevron Up',
		'class' => 'fa-solid fa-chevron-up',
	],
	[
		'name'  => 'Child',
		'class' => 'fa-solid fa-child',
	],
	[
		'name'  => 'Child Combatant',
		'class' => 'fa-solid fa-child-combatant',
	],
	[
		'name'  => 'Child Dress',
		'class' => 'fa-solid fa-child-dress',
	],
	[
		'name'  => 'Child Reaching',
		'class' => 'fa-solid fa-child-reaching',
	],
	[
		'name'  => 'Children',
		'class' => 'fa-solid fa-children',
	],
	[
		'name'  => 'Chrome',
		'class' => 'fa-brands fa-chrome',
	],
	[
		'name'  => 'Chromecast',
		'class' => 'fa-brands fa-chromecast',
	],
	[
		'name'  => 'Church',
		'class' => 'fa-solid fa-church',
	],
	[
		'name'  => 'Circle',
		'class' => 'fa-solid fa-circle',
	],
	[
		'name'  => 'Circle Arrow Down',
		'class' => 'fa-solid fa-circle-arrow-down',
	],
	[
		'name'  => 'Circle Arrow Left',
		'class' => 'fa-solid fa-circle-arrow-left',
	],
	[
		'name'  => 'Circle Arrow Right',
		'class' => 'fa-solid fa-circle-arrow-right',
	],
	[
		'name'  => 'Circle Arrow Up',
		'class' => 'fa-solid fa-circle-arrow-up',
	],
	[
		'name'  => 'Circle Check',
		'class' => 'fa-solid fa-circle-check',
	],
	[
		'name'  => 'Circle Chevron Down',
		'class' => 'fa-solid fa-circle-chevron-down',
	],
	[
		'name'  => 'Circle Chevron Left',
		'class' => 'fa-solid fa-circle-chevron-left',
	],
	[
		'name'  => 'Circle Chevron Right',
		'class' => 'fa-solid fa-circle-chevron-right',
	],
	[
		'name'  => 'Circle Chevron Up',
		'class' => 'fa-solid fa-circle-chevron-up',
	],
	[
		'name'  => 'Circle Dollar To Slot',
		'class' => 'fa-solid fa-circle-dollar-to-slot',
	],
	[
		'name'  => 'Circle Dot',
		'class' => 'fa-solid fa-circle-dot',
	],
	[
		'name'  => 'Circle Down',
		'class' => 'fa-solid fa-circle-down',
	],
	[
		'name'  => 'Circle Exclamation',
		'class' => 'fa-solid fa-circle-exclamation',
	],
	[
		'name'  => 'Circle H',
		'class' => 'fa-solid fa-circle-h',
	],
	[
		'name'  => 'Circle Half Stroke',
		'class' => 'fa-solid fa-circle-half-stroke',
	],
	[
		'name'  => 'Circle Info',
		'class' => 'fa-solid fa-circle-info',
	],
	[
		'name'  => 'Circle Left',
		'class' => 'fa-solid fa-circle-left',
	],
	[
		'name'  => 'Circle Minus',
		'class' => 'fa-solid fa-circle-minus',
	],
	[
		'name'  => 'Circle Nodes',
		'class' => 'fa-solid fa-circle-nodes',
	],
	[
		'name'  => 'Circle Notch',
		'class' => 'fa-solid fa-circle-notch',
	],
	[
		'name'  => 'Circle Pause',
		'class' => 'fa-solid fa-circle-pause',
	],
	[
		'name'  => 'Circle Play',
		'class' => 'fa-solid fa-circle-play',
	],
	[
		'name'  => 'Circle Plus',
		'class' => 'fa-solid fa-circle-plus',
	],
	[
		'name'  => 'Circle Question',
		'class' => 'fa-solid fa-circle-question',
	],
	[
		'name'  => 'Circle Radiation',
		'class' => 'fa-solid fa-circle-radiation',
	],
	[
		'name'  => 'Circle Right',
		'class' => 'fa-solid fa-circle-right',
	],
	[
		'name'  => 'Circle Stop',
		'class' => 'fa-solid fa-circle-stop',
	],
	[
		'name'  => 'Circle Up',
		'class' => 'fa-solid fa-circle-up',
	],
	[
		'name'  => 'Circle User',
		'class' => 'fa-solid fa-circle-user',
	],
	[
		'name'  => 'Circle Xmark',
		'class' => 'fa-solid fa-circle-xmark',
	],
	[
		'name'  => 'City',
		'class' => 'fa-solid fa-city',
	],
	[
		'name'  => 'Clapperboard',
		'class' => 'fa-solid fa-clapperboard',
	],
	[
		'name'  => 'Clipboard',
		'class' => 'fa-solid fa-clipboard',
	],
	[
		'name'  => 'Clipboard Check',
		'class' => 'fa-solid fa-clipboard-check',
	],
	[
		'name'  => 'Clipboard List',
		'class' => 'fa-solid fa-clipboard-list',
	],
	[
		'name'  => 'Clipboard Question',
		'class' => 'fa-solid fa-clipboard-question',
	],
	[
		'name'  => 'Clipboard User',
		'class' => 'fa-solid fa-clipboard-user',
	],
	[
		'name'  => 'Clock',
		'class' => 'fa-solid fa-clock',
	],
	[
		'name'  => 'Clock Rotate Left',
		'class' => 'fa-solid fa-clock-rotate-left',
	],
	[
		'name'  => 'Clone',
		'class' => 'fa-solid fa-clone',
	],
	[
		'name'  => 'Closed Captioning',
		'class' => 'fa-solid fa-closed-captioning',
	],
	[
		'name'  => 'Cloud',
		'class' => 'fa-solid fa-cloud',
	],
	[
		'name'  => 'Cloud Arrow Down',
		'class' => 'fa-solid fa-cloud-arrow-down',
	],
	[
		'name'  => 'Cloud Arrow Up',
		'class' => 'fa-solid fa-cloud-arrow-up',
	],
	[
		'name'  => 'Cloud Bolt',
		'class' => 'fa-solid fa-cloud-bolt',
	],
	[
		'name'  => 'Cloud Meatball',
		'class' => 'fa-solid fa-cloud-meatball',
	],
	[
		'name'  => 'Cloud Moon',
		'class' => 'fa-solid fa-cloud-moon',
	],
	[
		'name'  => 'Cloud Moon Rain',
		'class' => 'fa-solid fa-cloud-moon-rain',
	],
	[
		'name'  => 'Cloud Rain',
		'class' => 'fa-solid fa-cloud-rain',
	],
	[
		'name'  => 'Cloud Showers Heavy',
		'class' => 'fa-solid fa-cloud-showers-heavy',
	],
	[
		'name'  => 'Cloud Showers Water',
		'class' => 'fa-solid fa-cloud-showers-water',
	],
	[
		'name'  => 'Cloud Sun',
		'class' => 'fa-solid fa-cloud-sun',
	],
	[
		'name'  => 'Cloud Sun Rain',
		'class' => 'fa-solid fa-cloud-sun-rain',
	],
	[
		'name'  => 'Cloudflare',
		'class' => 'fa-brands fa-cloudflare',
	],
	[
		'name'  => 'cloudscale.ch',
		'class' => 'fa-brands fa-cloudscale',
	],
	[
		'name'  => 'Cloudsmith',
		'class' => 'fa-brands fa-cloudsmith',
	],
	[
		'name'  => 'cloudversify',
		'class' => 'fa-brands fa-cloudversify',
	],
	[
		'name'  => 'Clover',
		'class' => 'fa-solid fa-clover',
	],
	[
		'name'  => 'Cmplid',
		'class' => 'fa-brands fa-cmplid',
	],
	[
		'name'  => 'Code',
		'class' => 'fa-solid fa-code',
	],
	[
		'name'  => 'Code Branch',
		'class' => 'fa-solid fa-code-branch',
	],
	[
		'name'  => 'Code Commit',
		'class' => 'fa-solid fa-code-commit',
	],
	[
		'name'  => 'Code Compare',
		'class' => 'fa-solid fa-code-compare',
	],
	[
		'name'  => 'Code Fork',
		'class' => 'fa-solid fa-code-fork',
	],
	[
		'name'  => 'Code Merge',
		'class' => 'fa-solid fa-code-merge',
	],
	[
		'name'  => 'Code Pull Request',
		'class' => 'fa-solid fa-code-pull-request',
	],
	[
		'name'  => 'Codepen',
		'class' => 'fa-brands fa-codepen',
	],
	[
		'name'  => 'Codie Pie',
		'class' => 'fa-brands fa-codiepie',
	],
	[
		'name'  => 'Coins',
		'class' => 'fa-solid fa-coins',
	],
	[
		'name'  => 'Colon Sign',
		'class' => 'fa-solid fa-colon-sign',
	],
	[
		'name'  => 'Comment',
		'class' => 'fa-solid fa-comment',
	],
	[
		'name'  => 'Comment Dollar',
		'class' => 'fa-solid fa-comment-dollar',
	],
	[
		'name'  => 'Comment Dots',
		'class' => 'fa-solid fa-comment-dots',
	],
	[
		'name'  => 'Comment Medical',
		'class' => 'fa-solid fa-comment-medical',
	],
	[
		'name'  => 'Comment Slash',
		'class' => 'fa-solid fa-comment-slash',
	],
	[
		'name'  => 'Comment Sms',
		'class' => 'fa-solid fa-comment-sms',
	],
	[
		'name'  => 'Comments',
		'class' => 'fa-solid fa-comments',
	],
	[
		'name'  => 'Comments Dollar',
		'class' => 'fa-solid fa-comments-dollar',
	],
	[
		'name'  => 'Compact Disc',
		'class' => 'fa-solid fa-compact-disc',
	],
	[
		'name'  => 'Compass',
		'class' => 'fa-solid fa-compass',
	],
	[
		'name'  => 'Compass Drafting',
		'class' => 'fa-solid fa-compass-drafting',
	],
	[
		'name'  => 'Compress',
		'class' => 'fa-solid fa-compress',
	],
	[
		'name'  => 'Computer',
		'class' => 'fa-solid fa-computer',
	],
	[
		'name'  => 'Computer Mouse',
		'class' => 'fa-solid fa-computer-mouse',
	],
	[
		'name'  => 'Confluence',
		'class' => 'fa-brands fa-confluence',
	],
	[
		'name'  => 'Connect Develop',
		'class' => 'fa-brands fa-connectdevelop',
	],
	[
		'name'  => 'Contao',
		'class' => 'fa-brands fa-contao',
	],
	[
		'name'  => 'Cookie',
		'class' => 'fa-solid fa-cookie',
	],
	[
		'name'  => 'Cookie Bite',
		'class' => 'fa-solid fa-cookie-bite',
	],
	[
		'name'  => 'Copy',
		'class' => 'fa-solid fa-copy',
	],
	[
		'name'  => 'Copyright',
		'class' => 'fa-solid fa-copyright',
	],
	[
		'name'  => 'Cotton Bureau',
		'class' => 'fa-brands fa-cotton-bureau',
	],
	[
		'name'  => 'Couch',
		'class' => 'fa-solid fa-couch',
	],
	[
		'name'  => 'Cow',
		'class' => 'fa-solid fa-cow',
	],
	[
		'name'  => 'cPanel',
		'class' => 'fa-brands fa-cpanel',
	],
	[
		'name'  => 'Creative Commons',
		'class' => 'fa-brands fa-creative-commons',
	],
	[
		'name'  => 'Creative Commons Attribution',
		'class' => 'fa-brands fa-creative-commons-by',
	],
	[
		'name'  => 'Creative Commons Noncommercial',
		'class' => 'fa-brands fa-creative-commons-nc',
	],
	[
		'name'  => 'Creative Commons Noncommercial (Euro Sign)',
		'class' => 'fa-brands fa-creative-commons-nc-eu',
	],
	[
		'name'  => 'Creative Commons Noncommercial (Yen Sign)',
		'class' => 'fa-brands fa-creative-commons-nc-jp',
	],
	[
		'name'  => 'Creative Commons No Derivative Works',
		'class' => 'fa-brands fa-creative-commons-nd',
	],
	[
		'name'  => 'Creative Commons Public Domain',
		'class' => 'fa-brands fa-creative-commons-pd',
	],
	[
		'name'  => 'Alternate Creative Commons Public Domain',
		'class' => 'fa-brands fa-creative-commons-pd-alt',
	],
	[
		'name'  => 'Creative Commons Remix',
		'class' => 'fa-brands fa-creative-commons-remix',
	],
	[
		'name'  => 'Creative Commons Share Alike',
		'class' => 'fa-brands fa-creative-commons-sa',
	],
	[
		'name'  => 'Creative Commons Sampling',
		'class' => 'fa-brands fa-creative-commons-sampling',
	],
	[
		'name'  => 'Creative Commons Sampling +',
		'class' => 'fa-brands fa-creative-commons-sampling-plus',
	],
	[
		'name'  => 'Creative Commons Share',
		'class' => 'fa-brands fa-creative-commons-share',
	],
	[
		'name'  => 'Creative Commons CC0',
		'class' => 'fa-brands fa-creative-commons-zero',
	],
	[
		'name'  => 'Credit Card',
		'class' => 'fa-solid fa-credit-card',
	],
	[
		'name'  => 'Critical Role',
		'class' => 'fa-brands fa-critical-role',
	],
	[
		'name'  => 'Crop',
		'class' => 'fa-solid fa-crop',
	],
	[
		'name'  => 'Crop Simple',
		'class' => 'fa-solid fa-crop-simple',
	],
	[
		'name'  => 'Cross',
		'class' => 'fa-solid fa-cross',
	],
	[
		'name'  => 'Crosshairs',
		'class' => 'fa-solid fa-crosshairs',
	],
	[
		'name'  => 'Crow',
		'class' => 'fa-solid fa-crow',
	],
	[
		'name'  => 'Crown',
		'class' => 'fa-solid fa-crown',
	],
	[
		'name'  => 'Crutch',
		'class' => 'fa-solid fa-crutch',
	],
	[
		'name'  => 'Cruzeiro Sign',
		'class' => 'fa-solid fa-cruzeiro-sign',
	],
	[
		'name'  => 'CSS 3 Logo',
		'class' => 'fa-brands fa-css3',
	],
	[
		'name'  => 'Alternate CSS3 Logo',
		'class' => 'fa-brands fa-css3-alt',
	],
	[
		'name'  => 'Cube',
		'class' => 'fa-solid fa-cube',
	],
	[
		'name'  => 'Cubes',
		'class' => 'fa-solid fa-cubes',
	],
	[
		'name'  => 'Cubes Stacked',
		'class' => 'fa-solid fa-cubes-stacked',
	],
	[
		'name'  => 'Cuttlefish',
		'class' => 'fa-brands fa-cuttlefish',
	],
	[
		'name'  => 'D',
		'class' => 'fa-solid fa-d',
	],
	[
		'name'  => 'Dungeons & Dragons',
		'class' => 'fa-brands fa-d-and-d',
	],
	[
		'name'  => 'D&D Beyond',
		'class' => 'fa-brands fa-d-and-d-beyond',
	],
	[
		'name'  => 'dailymotion',
		'class' => 'fa-brands fa-dailymotion',
	],
	[
		'name'  => 'DashCube',
		'class' => 'fa-brands fa-dashcube',
	],
	[
		'name'  => 'Database',
		'class' => 'fa-solid fa-database',
	],
	[
		'name'  => 'Debian',
		'class' => 'fa-brands fa-debian',
	],
	[
		'name'  => 'Deezer',
		'class' => 'fa-brands fa-deezer',
	],
	[
		'name'  => 'Delete Left',
		'class' => 'fa-solid fa-delete-left',
	],
	[
		'name'  => 'Delicious',
		'class' => 'fa-brands fa-delicious',
	],
	[
		'name'  => 'Democrat',
		'class' => 'fa-solid fa-democrat',
	],
	[
		'name'  => 'deploy.dog',
		'class' => 'fa-brands fa-deploydog',
	],
	[
		'name'  => 'Deskpro',
		'class' => 'fa-brands fa-deskpro',
	],
	[
		'name'  => 'Desktop',
		'class' => 'fa-solid fa-desktop',
	],
	[
		'name'  => 'DEV',
		'class' => 'fa-brands fa-dev',
	],
	[
		'name'  => 'deviantART',
		'class' => 'fa-brands fa-deviantart',
	],
	[
		'name'  => 'Dharmachakra',
		'class' => 'fa-solid fa-dharmachakra',
	],
	[
		'name'  => 'DHL',
		'class' => 'fa-brands fa-dhl',
	],
	[
		'name'  => 'Diagram Next',
		'class' => 'fa-solid fa-diagram-next',
	],
	[
		'name'  => 'Diagram Predecessor',
		'class' => 'fa-solid fa-diagram-predecessor',
	],
	[
		'name'  => 'Diagram Project',
		'class' => 'fa-solid fa-diagram-project',
	],
	[
		'name'  => 'Diagram Successor',
		'class' => 'fa-solid fa-diagram-successor',
	],
	[
		'name'  => 'Diamond',
		'class' => 'fa-solid fa-diamond',
	],
	[
		'name'  => 'Diamond Turn Right',
		'class' => 'fa-solid fa-diamond-turn-right',
	],
	[
		'name'  => 'Diaspora',
		'class' => 'fa-brands fa-diaspora',
	],
	[
		'name'  => 'Dice',
		'class' => 'fa-solid fa-dice',
	],
	[
		'name'  => 'Dice D20',
		'class' => 'fa-solid fa-dice-d20',
	],
	[
		'name'  => 'Dice D6',
		'class' => 'fa-solid fa-dice-d6',
	],
	[
		'name'  => 'Dice Five',
		'class' => 'fa-solid fa-dice-five',
	],
	[
		'name'  => 'Dice Four',
		'class' => 'fa-solid fa-dice-four',
	],
	[
		'name'  => 'Dice One',
		'class' => 'fa-solid fa-dice-one',
	],
	[
		'name'  => 'Dice Six',
		'class' => 'fa-solid fa-dice-six',
	],
	[
		'name'  => 'Dice Three',
		'class' => 'fa-solid fa-dice-three',
	],
	[
		'name'  => 'Dice Two',
		'class' => 'fa-solid fa-dice-two',
	],
	[
		'name'  => 'Digg Logo',
		'class' => 'fa-brands fa-digg',
	],
	[
		'name'  => 'Digital Ocean',
		'class' => 'fa-brands fa-digital-ocean',
	],
	[
		'name'  => 'Discord',
		'class' => 'fa-brands fa-discord',
	],
	[
		'name'  => 'Discourse',
		'class' => 'fa-brands fa-discourse',
	],
	[
		'name'  => 'Disease',
		'class' => 'fa-solid fa-disease',
	],
	[
		'name'  => 'Display',
		'class' => 'fa-solid fa-display',
	],
	[
		'name'  => 'Divide',
		'class' => 'fa-solid fa-divide',
	],
	[
		'name'  => 'Dna',
		'class' => 'fa-solid fa-dna',
	],
	[
		'name'  => 'DocHub',
		'class' => 'fa-brands fa-dochub',
	],
	[
		'name'  => 'Docker',
		'class' => 'fa-brands fa-docker',
	],
	[
		'name'  => 'Dog',
		'class' => 'fa-solid fa-dog',
	],
	[
		'name'  => 'Dollar Sign',
		'class' => 'fa-solid fa-dollar-sign',
	],
	[
		'name'  => 'Dolly',
		'class' => 'fa-solid fa-dolly',
	],
	[
		'name'  => 'Dong Sign',
		'class' => 'fa-solid fa-dong-sign',
	],
	[
		'name'  => 'Door Closed',
		'class' => 'fa-solid fa-door-closed',
	],
	[
		'name'  => 'Door Open',
		'class' => 'fa-solid fa-door-open',
	],
	[
		'name'  => 'Dove',
		'class' => 'fa-solid fa-dove',
	],
	[
		'name'  => 'Down Left And Up Right To Center',
		'class' => 'fa-solid fa-down-left-and-up-right-to-center',
	],
	[
		'name'  => 'Down Long',
		'class' => 'fa-solid fa-down-long',
	],
	[
		'name'  => 'Download',
		'class' => 'fa-solid fa-download',
	],
	[
		'name'  => 'Draft2digital',
		'class' => 'fa-brands fa-draft2digital',
	],
	[
		'name'  => 'Dragon',
		'class' => 'fa-solid fa-dragon',
	],
	[
		'name'  => 'Draw Polygon',
		'class' => 'fa-solid fa-draw-polygon',
	],
	[
		'name'  => 'Dribbble',
		'class' => 'fa-brands fa-dribbble',
	],
	[
		'name'  => 'Dropbox',
		'class' => 'fa-brands fa-dropbox',
	],
	[
		'name'  => 'Droplet',
		'class' => 'fa-solid fa-droplet',
	],
	[
		'name'  => 'Droplet Slash',
		'class' => 'fa-solid fa-droplet-slash',
	],
	[
		'name'  => 'Drum',
		'class' => 'fa-solid fa-drum',
	],
	[
		'name'  => 'Drum Steelpan',
		'class' => 'fa-solid fa-drum-steelpan',
	],
	[
		'name'  => 'Drumstick Bite',
		'class' => 'fa-solid fa-drumstick-bite',
	],
	[
		'name'  => 'Drupal Logo',
		'class' => 'fa-brands fa-drupal',
	],
	[
		'name'  => 'Dumbbell',
		'class' => 'fa-solid fa-dumbbell',
	],
	[
		'name'  => 'Dumpster',
		'class' => 'fa-solid fa-dumpster',
	],
	[
		'name'  => 'Dumpster Fire',
		'class' => 'fa-solid fa-dumpster-fire',
	],
	[
		'name'  => 'Dungeon',
		'class' => 'fa-solid fa-dungeon',
	],
	[
		'name'  => 'Dyalog',
		'class' => 'fa-brands fa-dyalog',
	],
	[
		'name'  => 'E',
		'class' => 'fa-solid fa-e',
	],
	[
		'name'  => 'Ear Deaf',
		'class' => 'fa-solid fa-ear-deaf',
	],
	[
		'name'  => 'Ear Listen',
		'class' => 'fa-solid fa-ear-listen',
	],
	[
		'name'  => 'Earlybirds',
		'class' => 'fa-brands fa-earlybirds',
	],
	[
		'name'  => 'Earth Africa',
		'class' => 'fa-solid fa-earth-africa',
	],
	[
		'name'  => 'Earth Americas',
		'class' => 'fa-solid fa-earth-americas',
	],
	[
		'name'  => 'Earth Asia',
		'class' => 'fa-solid fa-earth-asia',
	],
	[
		'name'  => 'Earth Europe',
		'class' => 'fa-solid fa-earth-europe',
	],
	[
		'name'  => 'Earth Oceania',
		'class' => 'fa-solid fa-earth-oceania',
	],
	[
		'name'  => 'eBay',
		'class' => 'fa-brands fa-ebay',
	],
	[
		'name'  => 'Edge Browser',
		'class' => 'fa-brands fa-edge',
	],
	[
		'name'  => 'Edge Legacy Browser',
		'class' => 'fa-brands fa-edge-legacy',
	],
	[
		'name'  => 'Egg',
		'class' => 'fa-solid fa-egg',
	],
	[
		'name'  => 'Eject',
		'class' => 'fa-solid fa-eject',
	],
	[
		'name'  => 'Elementor',
		'class' => 'fa-brands fa-elementor',
	],
	[
		'name'  => 'Elevator',
		'class' => 'fa-solid fa-elevator',
	],
	[
		'name'  => 'Ellipsis',
		'class' => 'fa-solid fa-ellipsis',
	],
	[
		'name'  => 'Ellipsis Vertical',
		'class' => 'fa-solid fa-ellipsis-vertical',
	],
	[
		'name'  => 'Ello',
		'class' => 'fa-brands fa-ello',
	],
	[
		'name'  => 'Ember',
		'class' => 'fa-brands fa-ember',
	],
	[
		'name'  => 'Galactic Empire',
		'class' => 'fa-brands fa-empire',
	],
	[
		'name'  => 'Envelope',
		'class' => 'fa-solid fa-envelope',
	],
	[
		'name'  => 'Envelope Circle Check',
		'class' => 'fa-solid fa-envelope-circle-check',
	],
	[
		'name'  => 'Envelope Open',
		'class' => 'fa-solid fa-envelope-open',
	],
	[
		'name'  => 'Envelope Open Text',
		'class' => 'fa-solid fa-envelope-open-text',
	],
	[
		'name'  => 'Envelopes Bulk',
		'class' => 'fa-solid fa-envelopes-bulk',
	],
	[
		'name'  => 'Envira Gallery',
		'class' => 'fa-brands fa-envira',
	],
	[
		'name'  => 'Equals',
		'class' => 'fa-solid fa-equals',
	],
	[
		'name'  => 'Eraser',
		'class' => 'fa-solid fa-eraser',
	],
	[
		'name'  => 'Erlang',
		'class' => 'fa-brands fa-erlang',
	],
	[
		'name'  => 'Ethereum',
		'class' => 'fa-brands fa-ethereum',
	],
	[
		'name'  => 'Ethernet',
		'class' => 'fa-solid fa-ethernet',
	],
	[
		'name'  => 'Etsy',
		'class' => 'fa-brands fa-etsy',
	],
	[
		'name'  => 'Euro Sign',
		'class' => 'fa-solid fa-euro-sign',
	],
	[
		'name'  => 'Evernote',
		'class' => 'fa-brands fa-evernote',
	],
	[
		'name'  => 'Exclamation',
		'class' => 'fa-solid fa-exclamation',
	],
	[
		'name'  => 'Expand',
		'class' => 'fa-solid fa-expand',
	],
	[
		'name'  => 'ExpeditedSSL',
		'class' => 'fa-brands fa-expeditedssl',
	],
	[
		'name'  => 'Explosion',
		'class' => 'fa-solid fa-explosion',
	],
	[
		'name'  => 'Eye',
		'class' => 'fa-solid fa-eye',
	],
	[
		'name'  => 'Eye Dropper',
		'class' => 'fa-solid fa-eye-dropper',
	],
	[
		'name'  => 'Eye Low Vision',
		'class' => 'fa-solid fa-eye-low-vision',
	],
	[
		'name'  => 'Eye Slash',
		'class' => 'fa-solid fa-eye-slash',
	],
	[
		'name'  => 'F',
		'class' => 'fa-solid fa-f',
	],
	[
		'name'  => 'Face Angry',
		'class' => 'fa-solid fa-face-angry',
	],
	[
		'name'  => 'Face Dizzy',
		'class' => 'fa-solid fa-face-dizzy',
	],
	[
		'name'  => 'Face Flushed',
		'class' => 'fa-solid fa-face-flushed',
	],
	[
		'name'  => 'Face Frown',
		'class' => 'fa-solid fa-face-frown',
	],
	[
		'name'  => 'Face Frown Open',
		'class' => 'fa-solid fa-face-frown-open',
	],
	[
		'name'  => 'Face Grimace',
		'class' => 'fa-solid fa-face-grimace',
	],
	[
		'name'  => 'Face Grin',
		'class' => 'fa-solid fa-face-grin',
	],
	[
		'name'  => 'Face Grin Beam',
		'class' => 'fa-solid fa-face-grin-beam',
	],
	[
		'name'  => 'Face Grin Beam Sweat',
		'class' => 'fa-solid fa-face-grin-beam-sweat',
	],
	[
		'name'  => 'Face Grin Hearts',
		'class' => 'fa-solid fa-face-grin-hearts',
	],
	[
		'name'  => 'Face Grin Squint',
		'class' => 'fa-solid fa-face-grin-squint',
	],
	[
		'name'  => 'Face Grin Squint Tears',
		'class' => 'fa-solid fa-face-grin-squint-tears',
	],
	[
		'name'  => 'Face Grin Stars',
		'class' => 'fa-solid fa-face-grin-stars',
	],
	[
		'name'  => 'Face Grin Tears',
		'class' => 'fa-solid fa-face-grin-tears',
	],
	[
		'name'  => 'Face Grin Tongue',
		'class' => 'fa-solid fa-face-grin-tongue',
	],
	[
		'name'  => 'Face Grin Tongue Squint',
		'class' => 'fa-solid fa-face-grin-tongue-squint',
	],
	[
		'name'  => 'Face Grin Tongue Wink',
		'class' => 'fa-solid fa-face-grin-tongue-wink',
	],
	[
		'name'  => 'Face Grin Wide',
		'class' => 'fa-solid fa-face-grin-wide',
	],
	[
		'name'  => 'Face Grin Wink',
		'class' => 'fa-solid fa-face-grin-wink',
	],
	[
		'name'  => 'Face Kiss',
		'class' => 'fa-solid fa-face-kiss',
	],
	[
		'name'  => 'Face Kiss Beam',
		'class' => 'fa-solid fa-face-kiss-beam',
	],
	[
		'name'  => 'Face Kiss Wink Heart',
		'class' => 'fa-solid fa-face-kiss-wink-heart',
	],
	[
		'name'  => 'Face Laugh',
		'class' => 'fa-solid fa-face-laugh',
	],
	[
		'name'  => 'Face Laugh Beam',
		'class' => 'fa-solid fa-face-laugh-beam',
	],
	[
		'name'  => 'Face Laugh Squint',
		'class' => 'fa-solid fa-face-laugh-squint',
	],
	[
		'name'  => 'Face Laugh Wink',
		'class' => 'fa-solid fa-face-laugh-wink',
	],
	[
		'name'  => 'Face Meh',
		'class' => 'fa-solid fa-face-meh',
	],
	[
		'name'  => 'Face Meh Blank',
		'class' => 'fa-solid fa-face-meh-blank',
	],
	[
		'name'  => 'Face Rolling Eyes',
		'class' => 'fa-solid fa-face-rolling-eyes',
	],
	[
		'name'  => 'Face Sad Cry',
		'class' => 'fa-solid fa-face-sad-cry',
	],
	[
		'name'  => 'Face Sad Tear',
		'class' => 'fa-solid fa-face-sad-tear',
	],
	[
		'name'  => 'Face Smile',
		'class' => 'fa-solid fa-face-smile',
	],
	[
		'name'  => 'Face Smile Beam',
		'class' => 'fa-solid fa-face-smile-beam',
	],
	[
		'name'  => 'Face Smile Wink',
		'class' => 'fa-solid fa-face-smile-wink',
	],
	[
		'name'  => 'Face Surprise',
		'class' => 'fa-solid fa-face-surprise',
	],
	[
		'name'  => 'Face Tired',
		'class' => 'fa-solid fa-face-tired',
	],
	[
		'name'  => 'Facebook',
		'class' => 'fa-brands fa-facebook',
	],
	[
		'name'  => 'Facebook F',
		'class' => 'fa-brands fa-facebook-f',
	],
	[
		'name'  => 'Facebook Messenger',
		'class' => 'fa-brands fa-facebook-messenger',
	],
	[
		'name'  => 'Fan',
		'class' => 'fa-solid fa-fan',
	],
	[
		'name'  => 'Fantasy Flight-games',
		'class' => 'fa-brands fa-fantasy-flight-games',
	],
	[
		'name'  => 'Faucet',
		'class' => 'fa-solid fa-faucet',
	],
	[
		'name'  => 'Faucet Drip',
		'class' => 'fa-solid fa-faucet-drip',
	],
	[
		'name'  => 'Fax',
		'class' => 'fa-solid fa-fax',
	],
	[
		'name'  => 'Feather',
		'class' => 'fa-solid fa-feather',
	],
	[
		'name'  => 'Feather Pointed',
		'class' => 'fa-solid fa-feather-pointed',
	],
	[
		'name'  => 'FedEx',
		'class' => 'fa-brands fa-fedex',
	],
	[
		'name'  => 'Fedora',
		'class' => 'fa-brands fa-fedora',
	],
	[
		'name'  => 'Ferry',
		'class' => 'fa-solid fa-ferry',
	],
	[
		'name'  => 'Figma',
		'class' => 'fa-brands fa-figma',
	],
	[
		'name'  => 'File',
		'class' => 'fa-solid fa-file',
	],
	[
		'name'  => 'File Arrow Down',
		'class' => 'fa-solid fa-file-arrow-down',
	],
	[
		'name'  => 'File Arrow Up',
		'class' => 'fa-solid fa-file-arrow-up',
	],
	[
		'name'  => 'File Audio',
		'class' => 'fa-solid fa-file-audio',
	],
	[
		'name'  => 'File Circle Check',
		'class' => 'fa-solid fa-file-circle-check',
	],
	[
		'name'  => 'File Circle Exclamation',
		'class' => 'fa-solid fa-file-circle-exclamation',
	],
	[
		'name'  => 'File Circle Minus',
		'class' => 'fa-solid fa-file-circle-minus',
	],
	[
		'name'  => 'File Circle Plus',
		'class' => 'fa-solid fa-file-circle-plus',
	],
	[
		'name'  => 'File Circle Question',
		'class' => 'fa-solid fa-file-circle-question',
	],
	[
		'name'  => 'File Circle Xmark',
		'class' => 'fa-solid fa-file-circle-xmark',
	],
	[
		'name'  => 'File Code',
		'class' => 'fa-solid fa-file-code',
	],
	[
		'name'  => 'File Contract',
		'class' => 'fa-solid fa-file-contract',
	],
	[
		'name'  => 'File Csv',
		'class' => 'fa-solid fa-file-csv',
	],
	[
		'name'  => 'File Excel',
		'class' => 'fa-solid fa-file-excel',
	],
	[
		'name'  => 'File Export',
		'class' => 'fa-solid fa-file-export',
	],
	[
		'name'  => 'File Image',
		'class' => 'fa-solid fa-file-image',
	],
	[
		'name'  => 'File Import',
		'class' => 'fa-solid fa-file-import',
	],
	[
		'name'  => 'File Invoice',
		'class' => 'fa-solid fa-file-invoice',
	],
	[
		'name'  => 'File Invoice Dollar',
		'class' => 'fa-solid fa-file-invoice-dollar',
	],
	[
		'name'  => 'File Lines',
		'class' => 'fa-solid fa-file-lines',
	],
	[
		'name'  => 'File Medical',
		'class' => 'fa-solid fa-file-medical',
	],
	[
		'name'  => 'File Pdf',
		'class' => 'fa-solid fa-file-pdf',
	],
	[
		'name'  => 'File Pen',
		'class' => 'fa-solid fa-file-pen',
	],
	[
		'name'  => 'File Powerpoint',
		'class' => 'fa-solid fa-file-powerpoint',
	],
	[
		'name'  => 'File Prescription',
		'class' => 'fa-solid fa-file-prescription',
	],
	[
		'name'  => 'File Shield',
		'class' => 'fa-solid fa-file-shield',
	],
	[
		'name'  => 'File Signature',
		'class' => 'fa-solid fa-file-signature',
	],
	[
		'name'  => 'File Video',
		'class' => 'fa-solid fa-file-video',
	],
	[
		'name'  => 'File Waveform',
		'class' => 'fa-solid fa-file-waveform',
	],
	[
		'name'  => 'File Word',
		'class' => 'fa-solid fa-file-word',
	],
	[
		'name'  => 'File Zipper',
		'class' => 'fa-solid fa-file-zipper',
	],
	[
		'name'  => 'Fill',
		'class' => 'fa-solid fa-fill',
	],
	[
		'name'  => 'Fill Drip',
		'class' => 'fa-solid fa-fill-drip',
	],
	[
		'name'  => 'Film',
		'class' => 'fa-solid fa-film',
	],
	[
		'name'  => 'Filter',
		'class' => 'fa-solid fa-filter',
	],
	[
		'name'  => 'Filter Circle Dollar',
		'class' => 'fa-solid fa-filter-circle-dollar',
	],
	[
		'name'  => 'Filter Circle Xmark',
		'class' => 'fa-solid fa-filter-circle-xmark',
	],
	[
		'name'  => 'Fingerprint',
		'class' => 'fa-solid fa-fingerprint',
	],
	[
		'name'  => 'Fire',
		'class' => 'fa-solid fa-fire',
	],
	[
		'name'  => 'Fire Burner',
		'class' => 'fa-solid fa-fire-burner',
	],
	[
		'name'  => 'Fire Extinguisher',
		'class' => 'fa-solid fa-fire-extinguisher',
	],
	[
		'name'  => 'Fire Flame Curved',
		'class' => 'fa-solid fa-fire-flame-curved',
	],
	[
		'name'  => 'Fire Flame Simple',
		'class' => 'fa-solid fa-fire-flame-simple',
	],
	[
		'name'  => 'Firefox',
		'class' => 'fa-brands fa-firefox',
	],
	[
		'name'  => 'Firefox Browser',
		'class' => 'fa-brands fa-firefox-browser',
	],
	[
		'name'  => 'First Order',
		'class' => 'fa-brands fa-first-order',
	],
	[
		'name'  => 'Alternate First Order',
		'class' => 'fa-brands fa-first-order-alt',
	],
	[
		'name'  => 'firstdraft',
		'class' => 'fa-brands fa-firstdraft',
	],
	[
		'name'  => 'Fish',
		'class' => 'fa-solid fa-fish',
	],
	[
		'name'  => 'Fish Fins',
		'class' => 'fa-solid fa-fish-fins',
	],
	[
		'name'  => 'Flag',
		'class' => 'fa-solid fa-flag',
	],
	[
		'name'  => 'Flag Checkered',
		'class' => 'fa-solid fa-flag-checkered',
	],
	[
		'name'  => 'Flag Usa',
		'class' => 'fa-solid fa-flag-usa',
	],
	[
		'name'  => 'Flask',
		'class' => 'fa-solid fa-flask',
	],
	[
		'name'  => 'Flask Vial',
		'class' => 'fa-solid fa-flask-vial',
	],
	[
		'name'  => 'Flickr',
		'class' => 'fa-brands fa-flickr',
	],
	[
		'name'  => 'Flipboard',
		'class' => 'fa-brands fa-flipboard',
	],
	[
		'name'  => 'Floppy Disk',
		'class' => 'fa-solid fa-floppy-disk',
	],
	[
		'name'  => 'Florin Sign',
		'class' => 'fa-solid fa-florin-sign',
	],
	[
		'name'  => 'Fly',
		'class' => 'fa-brands fa-fly',
	],
	[
		'name'  => 'Folder',
		'class' => 'fa-solid fa-folder',
	],
	[
		'name'  => 'Folder Closed',
		'class' => 'fa-solid fa-folder-closed',
	],
	[
		'name'  => 'Folder Minus',
		'class' => 'fa-solid fa-folder-minus',
	],
	[
		'name'  => 'Folder Open',
		'class' => 'fa-solid fa-folder-open',
	],
	[
		'name'  => 'Folder Plus',
		'class' => 'fa-solid fa-folder-plus',
	],
	[
		'name'  => 'Folder Tree',
		'class' => 'fa-solid fa-folder-tree',
	],
	[
		'name'  => 'Font',
		'class' => 'fa-solid fa-font',
	],
	[
		'name'  => 'Font Awesome',
		'class' => 'fa-solid fa-font-awesome',
	],
	[
		'name'  => 'Fonticons',
		'class' => 'fa-brands fa-fonticons',
	],
	[
		'name'  => 'Fonticons Fi',
		'class' => 'fa-brands fa-fonticons-fi',
	],
	[
		'name'  => 'Football',
		'class' => 'fa-solid fa-football',
	],
	[
		'name'  => 'Fort Awesome',
		'class' => 'fa-brands fa-fort-awesome',
	],
	[
		'name'  => 'Alternate Fort Awesome',
		'class' => 'fa-brands fa-fort-awesome-alt',
	],
	[
		'name'  => 'Forumbee',
		'class' => 'fa-brands fa-forumbee',
	],
	[
		'name'  => 'Forward',
		'class' => 'fa-solid fa-forward',
	],
	[
		'name'  => 'Forward Fast',
		'class' => 'fa-solid fa-forward-fast',
	],
	[
		'name'  => 'Forward Step',
		'class' => 'fa-solid fa-forward-step',
	],
	[
		'name'  => 'Foursquare',
		'class' => 'fa-brands fa-foursquare',
	],
	[
		'name'  => 'Franc Sign',
		'class' => 'fa-solid fa-franc-sign',
	],
	[
		'name'  => 'freeCodeCamp',
		'class' => 'fa-brands fa-free-code-camp',
	],
	[
		'name'  => 'FreeBSD',
		'class' => 'fa-brands fa-freebsd',
	],
	[
		'name'  => 'Frog',
		'class' => 'fa-solid fa-frog',
	],
	[
		'name'  => 'Fulcrum',
		'class' => 'fa-brands fa-fulcrum',
	],
	[
		'name'  => 'Futbol',
		'class' => 'fa-solid fa-futbol',
	],
	[
		'name'  => 'G',
		'class' => 'fa-solid fa-g',
	],
	[
		'name'  => 'Galactic Republic',
		'class' => 'fa-brands fa-galactic-republic',
	],
	[
		'name'  => 'Galactic Senate',
		'class' => 'fa-brands fa-galactic-senate',
	],
	[
		'name'  => 'Gamepad',
		'class' => 'fa-solid fa-gamepad',
	],
	[
		'name'  => 'Gas Pump',
		'class' => 'fa-solid fa-gas-pump',
	],
	[
		'name'  => 'Gauge',
		'class' => 'fa-solid fa-gauge',
	],
	[
		'name'  => 'Gauge High',
		'class' => 'fa-solid fa-gauge-high',
	],
	[
		'name'  => 'Gauge Simple',
		'class' => 'fa-solid fa-gauge-simple',
	],
	[
		'name'  => 'Gauge Simple High',
		'class' => 'fa-solid fa-gauge-simple-high',
	],
	[
		'name'  => 'Gavel',
		'class' => 'fa-solid fa-gavel',
	],
	[
		'name'  => 'Gear',
		'class' => 'fa-solid fa-gear',
	],
	[
		'name'  => 'Gears',
		'class' => 'fa-solid fa-gears',
	],
	[
		'name'  => 'Gem',
		'class' => 'fa-solid fa-gem',
	],
	[
		'name'  => 'Genderless',
		'class' => 'fa-solid fa-genderless',
	],
	[
		'name'  => 'Get Pocket',
		'class' => 'fa-brands fa-get-pocket',
	],
	[
		'name'  => 'GG Currency',
		'class' => 'fa-brands fa-gg',
	],
	[
		'name'  => 'GG Currency Circle',
		'class' => 'fa-brands fa-gg-circle',
	],
	[
		'name'  => 'Ghost',
		'class' => 'fa-solid fa-ghost',
	],
	[
		'name'  => 'Gift',
		'class' => 'fa-solid fa-gift',
	],
	[
		'name'  => 'Gifts',
		'class' => 'fa-solid fa-gifts',
	],
	[
		'name'  => 'Git',
		'class' => 'fa-brands fa-git',
	],
	[
		'name'  => 'Git Alt',
		'class' => 'fa-brands fa-git-alt',
	],
	[
		'name'  => 'GitHub',
		'class' => 'fa-brands fa-github',
	],
	[
		'name'  => 'Alternate GitHub',
		'class' => 'fa-brands fa-github-alt',
	],
	[
		'name'  => 'GitKraken',
		'class' => 'fa-brands fa-gitkraken',
	],
	[
		'name'  => 'GitLab',
		'class' => 'fa-brands fa-gitlab',
	],
	[
		'name'  => 'Gitter',
		'class' => 'fa-brands fa-gitter',
	],
	[
		'name'  => 'Glass Water',
		'class' => 'fa-solid fa-glass-water',
	],
	[
		'name'  => 'Glass Water Droplet',
		'class' => 'fa-solid fa-glass-water-droplet',
	],
	[
		'name'  => 'Glasses',
		'class' => 'fa-solid fa-glasses',
	],
	[
		'name'  => 'Glide',
		'class' => 'fa-brands fa-glide',
	],
	[
		'name'  => 'Glide G',
		'class' => 'fa-brands fa-glide-g',
	],
	[
		'name'  => 'Globe',
		'class' => 'fa-solid fa-globe',
	],
	[
		'name'  => 'Gofore',
		'class' => 'fa-brands fa-gofore',
	],
	[
		'name'  => 'Go',
		'class' => 'fa-brands fa-golang',
	],
	[
		'name'  => 'Golf Ball Tee',
		'class' => 'fa-solid fa-golf-ball-tee',
	],
	[
		'name'  => 'Goodreads',
		'class' => 'fa-brands fa-goodreads',
	],
	[
		'name'  => 'Goodreads G',
		'class' => 'fa-brands fa-goodreads-g',
	],
	[
		'name'  => 'Google Logo',
		'class' => 'fa-brands fa-google',
	],
	[
		'name'  => 'Google Drive',
		'class' => 'fa-brands fa-google-drive',
	],
	[
		'name'  => 'Google Pay',
		'class' => 'fa-brands fa-google-pay',
	],
	[
		'name'  => 'Google Play',
		'class' => 'fa-brands fa-google-play',
	],
	[
		'name'  => 'Google Plus',
		'class' => 'fa-brands fa-google-plus',
	],
	[
		'name'  => 'Google Plus G',
		'class' => 'fa-brands fa-google-plus-g',
	],
	[
		'name'  => 'Google Scholar',
		'class' => 'fa-brands fa-google-scholar',
	],
	[
		'name'  => 'Google Wallet',
		'class' => 'fa-brands fa-google-wallet',
	],
	[
		'name'  => 'Gopuram',
		'class' => 'fa-solid fa-gopuram',
	],
	[
		'name'  => 'Graduation Cap',
		'class' => 'fa-solid fa-graduation-cap',
	],
	[
		'name'  => 'Gratipay (Gittip)',
		'class' => 'fa-brands fa-gratipay',
	],
	[
		'name'  => 'Grav',
		'class' => 'fa-brands fa-grav',
	],
	[
		'name'  => 'Greater Than',
		'class' => 'fa-solid fa-greater-than',
	],
	[
		'name'  => 'Greater Than Equal',
		'class' => 'fa-solid fa-greater-than-equal',
	],
	[
		'name'  => 'Grip',
		'class' => 'fa-solid fa-grip',
	],
	[
		'name'  => 'Grip Lines',
		'class' => 'fa-solid fa-grip-lines',
	],
	[
		'name'  => 'Grip Lines Vertical',
		'class' => 'fa-solid fa-grip-lines-vertical',
	],
	[
		'name'  => 'Grip Vertical',
		'class' => 'fa-solid fa-grip-vertical',
	],
	[
		'name'  => 'Gripfire, Inc.',
		'class' => 'fa-brands fa-gripfire',
	],
	[
		'name'  => 'Group Arrows Rotate',
		'class' => 'fa-solid fa-group-arrows-rotate',
	],
	[
		'name'  => 'Grunt',
		'class' => 'fa-brands fa-grunt',
	],
	[
		'name'  => 'Guarani Sign',
		'class' => 'fa-solid fa-guarani-sign',
	],
	[
		'name'  => 'Guilded',
		'class' => 'fa-brands fa-guilded',
	],
	[
		'name'  => 'Guitar',
		'class' => 'fa-solid fa-guitar',
	],
	[
		'name'  => 'Gulp',
		'class' => 'fa-brands fa-gulp',
	],
	[
		'name'  => 'Gun',
		'class' => 'fa-solid fa-gun',
	],
	[
		'name'  => 'H',
		'class' => 'fa-solid fa-h',
	],
	[
		'name'  => 'Hacker News',
		'class' => 'fa-brands fa-hacker-news',
	],
	[
		'name'  => 'Hackerrank',
		'class' => 'fa-brands fa-hackerrank',
	],
	[
		'name'  => 'Hammer',
		'class' => 'fa-solid fa-hammer',
	],
	[
		'name'  => 'Hamsa',
		'class' => 'fa-solid fa-hamsa',
	],
	[
		'name'  => 'Hand',
		'class' => 'fa-solid fa-hand',
	],
	[
		'name'  => 'Hand Back Fist',
		'class' => 'fa-solid fa-hand-back-fist',
	],
	[
		'name'  => 'Hand Dots',
		'class' => 'fa-solid fa-hand-dots',
	],
	[
		'name'  => 'Hand Fist',
		'class' => 'fa-solid fa-hand-fist',
	],
	[
		'name'  => 'Hand Holding',
		'class' => 'fa-solid fa-hand-holding',
	],
	[
		'name'  => 'Hand Holding Dollar',
		'class' => 'fa-solid fa-hand-holding-dollar',
	],
	[
		'name'  => 'Hand Holding Droplet',
		'class' => 'fa-solid fa-hand-holding-droplet',
	],
	[
		'name'  => 'Hand Holding Hand',
		'class' => 'fa-solid fa-hand-holding-hand',
	],
	[
		'name'  => 'Hand Holding Heart',
		'class' => 'fa-solid fa-hand-holding-heart',
	],
	[
		'name'  => 'Hand Holding Medical',
		'class' => 'fa-solid fa-hand-holding-medical',
	],
	[
		'name'  => 'Hand Lizard',
		'class' => 'fa-solid fa-hand-lizard',
	],
	[
		'name'  => 'Hand Middle Finger',
		'class' => 'fa-solid fa-hand-middle-finger',
	],
	[
		'name'  => 'Hand Peace',
		'class' => 'fa-solid fa-hand-peace',
	],
	[
		'name'  => 'Hand Point Down',
		'class' => 'fa-solid fa-hand-point-down',
	],
	[
		'name'  => 'Hand Point Left',
		'class' => 'fa-solid fa-hand-point-left',
	],
	[
		'name'  => 'Hand Point Right',
		'class' => 'fa-solid fa-hand-point-right',
	],
	[
		'name'  => 'Hand Point Up',
		'class' => 'fa-solid fa-hand-point-up',
	],
	[
		'name'  => 'Hand Pointer',
		'class' => 'fa-solid fa-hand-pointer',
	],
	[
		'name'  => 'Hand Scissors',
		'class' => 'fa-solid fa-hand-scissors',
	],
	[
		'name'  => 'Hand Sparkles',
		'class' => 'fa-solid fa-hand-sparkles',
	],
	[
		'name'  => 'Hand Spock',
		'class' => 'fa-solid fa-hand-spock',
	],
	[
		'name'  => 'Handcuffs',
		'class' => 'fa-solid fa-handcuffs',
	],
	[
		'name'  => 'Hands',
		'class' => 'fa-solid fa-hands',
	],
	[
		'name'  => 'Hands Asl Interpreting',
		'class' => 'fa-solid fa-hands-asl-interpreting',
	],
	[
		'name'  => 'Hands Bound',
		'class' => 'fa-solid fa-hands-bound',
	],
	[
		'name'  => 'Hands Bubbles',
		'class' => 'fa-solid fa-hands-bubbles',
	],
	[
		'name'  => 'Hands Clapping',
		'class' => 'fa-solid fa-hands-clapping',
	],
	[
		'name'  => 'Hands Holding',
		'class' => 'fa-solid fa-hands-holding',
	],
	[
		'name'  => 'Hands Holding Child',
		'class' => 'fa-solid fa-hands-holding-child',
	],
	[
		'name'  => 'Hands Holding Circle',
		'class' => 'fa-solid fa-hands-holding-circle',
	],
	[
		'name'  => 'Hands Praying',
		'class' => 'fa-solid fa-hands-praying',
	],
	[
		'name'  => 'Handshake',
		'class' => 'fa-solid fa-handshake',
	],
	[
		'name'  => 'Handshake Angle',
		'class' => 'fa-solid fa-handshake-angle',
	],
	[
		'name'  => 'Handshake Simple',
		'class' => 'fa-solid fa-handshake-simple',
	],
	[
		'name'  => 'Handshake Simple Slash',
		'class' => 'fa-solid fa-handshake-simple-slash',
	],
	[
		'name'  => 'Handshake Slash',
		'class' => 'fa-solid fa-handshake-slash',
	],
	[
		'name'  => 'Hanukiah',
		'class' => 'fa-solid fa-hanukiah',
	],
	[
		'name'  => 'Hard Drive',
		'class' => 'fa-solid fa-hard-drive',
	],
	[
		'name'  => 'Hashnode',
		'class' => 'fa-brands fa-hashnode',
	],
	[
		'name'  => 'Hashtag',
		'class' => 'fa-solid fa-hashtag',
	],
	[
		'name'  => 'Hat Cowboy',
		'class' => 'fa-solid fa-hat-cowboy',
	],
	[
		'name'  => 'Hat Cowboy Side',
		'class' => 'fa-solid fa-hat-cowboy-side',
	],
	[
		'name'  => 'Hat Wizard',
		'class' => 'fa-solid fa-hat-wizard',
	],
	[
		'name'  => 'Head Side Cough',
		'class' => 'fa-solid fa-head-side-cough',
	],
	[
		'name'  => 'Head Side Cough Slash',
		'class' => 'fa-solid fa-head-side-cough-slash',
	],
	[
		'name'  => 'Head Side Mask',
		'class' => 'fa-solid fa-head-side-mask',
	],
	[
		'name'  => 'Head Side Virus',
		'class' => 'fa-solid fa-head-side-virus',
	],
	[
		'name'  => 'Heading',
		'class' => 'fa-solid fa-heading',
	],
	[
		'name'  => 'Headphones',
		'class' => 'fa-solid fa-headphones',
	],
	[
		'name'  => 'Headphones Simple',
		'class' => 'fa-solid fa-headphones-simple',
	],
	[
		'name'  => 'Headset',
		'class' => 'fa-solid fa-headset',
	],
	[
		'name'  => 'Heart',
		'class' => 'fa-solid fa-heart',
	],
	[
		'name'  => 'Heart Circle Bolt',
		'class' => 'fa-solid fa-heart-circle-bolt',
	],
	[
		'name'  => 'Heart Circle Check',
		'class' => 'fa-solid fa-heart-circle-check',
	],
	[
		'name'  => 'Heart Circle Exclamation',
		'class' => 'fa-solid fa-heart-circle-exclamation',
	],
	[
		'name'  => 'Heart Circle Minus',
		'class' => 'fa-solid fa-heart-circle-minus',
	],
	[
		'name'  => 'Heart Circle Plus',
		'class' => 'fa-solid fa-heart-circle-plus',
	],
	[
		'name'  => 'Heart Circle Xmark',
		'class' => 'fa-solid fa-heart-circle-xmark',
	],
	[
		'name'  => 'Heart Crack',
		'class' => 'fa-solid fa-heart-crack',
	],
	[
		'name'  => 'Heart Pulse',
		'class' => 'fa-solid fa-heart-pulse',
	],
	[
		'name'  => 'Helicopter',
		'class' => 'fa-solid fa-helicopter',
	],
	[
		'name'  => 'Helicopter Symbol',
		'class' => 'fa-solid fa-helicopter-symbol',
	],
	[
		'name'  => 'Helmet Safety',
		'class' => 'fa-solid fa-helmet-safety',
	],
	[
		'name'  => 'Helmet Un',
		'class' => 'fa-solid fa-helmet-un',
	],
	[
		'name'  => 'Highlighter',
		'class' => 'fa-solid fa-highlighter',
	],
	[
		'name'  => 'Hill Avalanche',
		'class' => 'fa-solid fa-hill-avalanche',
	],
	[
		'name'  => 'Hill Rockslide',
		'class' => 'fa-solid fa-hill-rockslide',
	],
	[
		'name'  => 'Hippo',
		'class' => 'fa-solid fa-hippo',
	],
	[
		'name'  => 'Hips',
		'class' => 'fa-brands fa-hips',
	],
	[
		'name'  => 'HireAHelper',
		'class' => 'fa-brands fa-hire-a-helper',
	],
	[
		'name'  => 'Hive Blockchain Network',
		'class' => 'fa-brands fa-hive',
	],
	[
		'name'  => 'Hockey Puck',
		'class' => 'fa-solid fa-hockey-puck',
	],
	[
		'name'  => 'Holly Berry',
		'class' => 'fa-solid fa-holly-berry',
	],
	[
		'name'  => 'Hooli',
		'class' => 'fa-brands fa-hooli',
	],
	[
		'name'  => 'Hornbill',
		'class' => 'fa-brands fa-hornbill',
	],
	[
		'name'  => 'Horse',
		'class' => 'fa-solid fa-horse',
	],
	[
		'name'  => 'Horse Head',
		'class' => 'fa-solid fa-horse-head',
	],
	[
		'name'  => 'Hospital',
		'class' => 'fa-solid fa-hospital',
	],
	[
		'name'  => 'Hospital User',
		'class' => 'fa-solid fa-hospital-user',
	],
	[
		'name'  => 'Hot Tub Person',
		'class' => 'fa-solid fa-hot-tub-person',
	],
	[
		'name'  => 'Hotdog',
		'class' => 'fa-solid fa-hotdog',
	],
	[
		'name'  => 'Hotel',
		'class' => 'fa-solid fa-hotel',
	],
	[
		'name'  => 'Hotjar',
		'class' => 'fa-brands fa-hotjar',
	],
	[
		'name'  => 'Hourglass',
		'class' => 'fa-solid fa-hourglass',
	],
	[
		'name'  => 'Hourglass End',
		'class' => 'fa-solid fa-hourglass-end',
	],
	[
		'name'  => 'Hourglass Half',
		'class' => 'fa-solid fa-hourglass-half',
	],
	[
		'name'  => 'Hourglass Start',
		'class' => 'fa-solid fa-hourglass-start',
	],
	[
		'name'  => 'House',
		'class' => 'fa-solid fa-house',
	],
	[
		'name'  => 'House Chimney',
		'class' => 'fa-solid fa-house-chimney',
	],
	[
		'name'  => 'House Chimney Crack',
		'class' => 'fa-solid fa-house-chimney-crack',
	],
	[
		'name'  => 'House Chimney Medical',
		'class' => 'fa-solid fa-house-chimney-medical',
	],
	[
		'name'  => 'House Chimney User',
		'class' => 'fa-solid fa-house-chimney-user',
	],
	[
		'name'  => 'House Chimney Window',
		'class' => 'fa-solid fa-house-chimney-window',
	],
	[
		'name'  => 'House Circle Check',
		'class' => 'fa-solid fa-house-circle-check',
	],
	[
		'name'  => 'House Circle Exclamation',
		'class' => 'fa-solid fa-house-circle-exclamation',
	],
	[
		'name'  => 'House Circle Xmark',
		'class' => 'fa-solid fa-house-circle-xmark',
	],
	[
		'name'  => 'House Crack',
		'class' => 'fa-solid fa-house-crack',
	],
	[
		'name'  => 'House Fire',
		'class' => 'fa-solid fa-house-fire',
	],
	[
		'name'  => 'House Flag',
		'class' => 'fa-solid fa-house-flag',
	],
	[
		'name'  => 'House Flood Water',
		'class' => 'fa-solid fa-house-flood-water',
	],
	[
		'name'  => 'House Flood Water Circle Arrow Right',
		'class' => 'fa-solid fa-house-flood-water-circle-arrow-right',
	],
	[
		'name'  => 'House Laptop',
		'class' => 'fa-solid fa-house-laptop',
	],
	[
		'name'  => 'House Lock',
		'class' => 'fa-solid fa-house-lock',
	],
	[
		'name'  => 'House Medical',
		'class' => 'fa-solid fa-house-medical',
	],
	[
		'name'  => 'House Medical Circle Check',
		'class' => 'fa-solid fa-house-medical-circle-check',
	],
	[
		'name'  => 'House Medical Circle Exclamation',
		'class' => 'fa-solid fa-house-medical-circle-exclamation',
	],
	[
		'name'  => 'House Medical Circle Xmark',
		'class' => 'fa-solid fa-house-medical-circle-xmark',
	],
	[
		'name'  => 'House Medical Flag',
		'class' => 'fa-solid fa-house-medical-flag',
	],
	[
		'name'  => 'House Signal',
		'class' => 'fa-solid fa-house-signal',
	],
	[
		'name'  => 'House Tsunami',
		'class' => 'fa-solid fa-house-tsunami',
	],
	[
		'name'  => 'House User',
		'class' => 'fa-solid fa-house-user',
	],
	[
		'name'  => 'Houzz',
		'class' => 'fa-brands fa-houzz',
	],
	[
		'name'  => 'Hryvnia Sign',
		'class' => 'fa-solid fa-hryvnia-sign',
	],
	[
		'name'  => 'HTML 5 Logo',
		'class' => 'fa-brands fa-html5',
	],
	[
		'name'  => 'HubSpot',
		'class' => 'fa-brands fa-hubspot',
	],
	[
		'name'  => 'Hurricane',
		'class' => 'fa-solid fa-hurricane',
	],
	[
		'name'  => 'I',
		'class' => 'fa-solid fa-i',
	],
	[
		'name'  => 'I Cursor',
		'class' => 'fa-solid fa-i-cursor',
	],
	[
		'name'  => 'Ice Cream',
		'class' => 'fa-solid fa-ice-cream',
	],
	[
		'name'  => 'Icicles',
		'class' => 'fa-solid fa-icicles',
	],
	[
		'name'  => 'Icons',
		'class' => 'fa-solid fa-icons',
	],
	[
		'name'  => 'Id Badge',
		'class' => 'fa-solid fa-id-badge',
	],
	[
		'name'  => 'Id Card',
		'class' => 'fa-solid fa-id-card',
	],
	[
		'name'  => 'Id Card Clip',
		'class' => 'fa-solid fa-id-card-clip',
	],
	[
		'name'  => 'iDeal',
		'class' => 'fa-brands fa-ideal',
	],
	[
		'name'  => 'Igloo',
		'class' => 'fa-solid fa-igloo',
	],
	[
		'name'  => 'Image',
		'class' => 'fa-solid fa-image',
	],
	[
		'name'  => 'Image Portrait',
		'class' => 'fa-solid fa-image-portrait',
	],
	[
		'name'  => 'Images',
		'class' => 'fa-solid fa-images',
	],
	[
		'name'  => 'IMDB',
		'class' => 'fa-brands fa-imdb',
	],
	[
		'name'  => 'Inbox',
		'class' => 'fa-solid fa-inbox',
	],
	[
		'name'  => 'Indent',
		'class' => 'fa-solid fa-indent',
	],
	[
		'name'  => 'Indian Rupee Sign',
		'class' => 'fa-solid fa-indian-rupee-sign',
	],
	[
		'name'  => 'Industry',
		'class' => 'fa-solid fa-industry',
	],
	[
		'name'  => 'Infinity',
		'class' => 'fa-solid fa-infinity',
	],
	[
		'name'  => 'Info',
		'class' => 'fa-solid fa-info',
	],
	[
		'name'  => 'Instagram',
		'class' => 'fa-brands fa-instagram',
	],
	[
		'name'  => 'InstaLOD',
		'class' => 'fa-brands fa-instalod',
	],
	[
		'name'  => 'Intercom',
		'class' => 'fa-brands fa-intercom',
	],
	[
		'name'  => 'Internet-explorer',
		'class' => 'fa-brands fa-internet-explorer',
	],
	[
		'name'  => 'InVision',
		'class' => 'fa-brands fa-invision',
	],
	[
		'name'  => 'ioxhost',
		'class' => 'fa-brands fa-ioxhost',
	],
	[
		'name'  => 'Italic',
		'class' => 'fa-solid fa-italic',
	],
	[
		'name'  => 'itch.io',
		'class' => 'fa-brands fa-itch-io',
	],
	[
		'name'  => 'iTunes',
		'class' => 'fa-brands fa-itunes',
	],
	[
		'name'  => 'Itunes Note',
		'class' => 'fa-brands fa-itunes-note',
	],
	[
		'name'  => 'J',
		'class' => 'fa-solid fa-j',
	],
	[
		'name'  => 'Jar',
		'class' => 'fa-solid fa-jar',
	],
	[
		'name'  => 'Jar Wheat',
		'class' => 'fa-solid fa-jar-wheat',
	],
	[
		'name'  => 'Java',
		'class' => 'fa-brands fa-java',
	],
	[
		'name'  => 'Jedi',
		'class' => 'fa-solid fa-jedi',
	],
	[
		'name'  => 'Jedi Order',
		'class' => 'fa-brands fa-jedi-order',
	],
	[
		'name'  => 'Jenkis',
		'class' => 'fa-brands fa-jenkins',
	],
	[
		'name'  => 'Jet Fighter',
		'class' => 'fa-solid fa-jet-fighter',
	],
	[
		'name'  => 'Jet Fighter Up',
		'class' => 'fa-solid fa-jet-fighter-up',
	],
	[
		'name'  => 'Jira',
		'class' => 'fa-brands fa-jira',
	],
	[
		'name'  => 'Joget',
		'class' => 'fa-brands fa-joget',
	],
	[
		'name'  => 'Joint',
		'class' => 'fa-solid fa-joint',
	],
	[
		'name'  => 'Joomla Logo',
		'class' => 'fa-brands fa-joomla',
	],
	[
		'name'  => 'JavaScript (JS)',
		'class' => 'fa-brands fa-js',
	],
	[
		'name'  => 'jsFiddle',
		'class' => 'fa-brands fa-jsfiddle',
	],
	[
		'name'  => 'Jug Detergent',
		'class' => 'fa-solid fa-jug-detergent',
	],
	[
		'name'  => 'Jxl',
		'class' => 'fa-brands fa-jxl',
	],
	[
		'name'  => 'K',
		'class' => 'fa-solid fa-k',
	],
	[
		'name'  => 'Kaaba',
		'class' => 'fa-solid fa-kaaba',
	],
	[
		'name'  => 'Kaggle',
		'class' => 'fa-brands fa-kaggle',
	],
	[
		'name'  => 'Key',
		'class' => 'fa-solid fa-key',
	],
	[
		'name'  => 'Keybase',
		'class' => 'fa-brands fa-keybase',
	],
	[
		'name'  => 'Keyboard',
		'class' => 'fa-solid fa-keyboard',
	],
	[
		'name'  => 'KeyCDN',
		'class' => 'fa-brands fa-keycdn',
	],
	[
		'name'  => 'Khanda',
		'class' => 'fa-solid fa-khanda',
	],
	[
		'name'  => 'Kickstarter',
		'class' => 'fa-brands fa-kickstarter',
	],
	[
		'name'  => 'Kickstarter K',
		'class' => 'fa-brands fa-kickstarter-k',
	],
	[
		'name'  => 'Kip Sign',
		'class' => 'fa-solid fa-kip-sign',
	],
	[
		'name'  => 'Kit Medical',
		'class' => 'fa-solid fa-kit-medical',
	],
	[
		'name'  => 'Kitchen Set',
		'class' => 'fa-solid fa-kitchen-set',
	],
	[
		'name'  => 'Kiwi Bird',
		'class' => 'fa-solid fa-kiwi-bird',
	],
	[
		'name'  => 'KORVUE',
		'class' => 'fa-brands fa-korvue',
	],
	[
		'name'  => 'L',
		'class' => 'fa-solid fa-l',
	],
	[
		'name'  => 'Land Mine On',
		'class' => 'fa-solid fa-land-mine-on',
	],
	[
		'name'  => 'Landmark',
		'class' => 'fa-solid fa-landmark',
	],
	[
		'name'  => 'Landmark Dome',
		'class' => 'fa-solid fa-landmark-dome',
	],
	[
		'name'  => 'Landmark Flag',
		'class' => 'fa-solid fa-landmark-flag',
	],
	[
		'name'  => 'Language',
		'class' => 'fa-solid fa-language',
	],
	[
		'name'  => 'Laptop',
		'class' => 'fa-solid fa-laptop',
	],
	[
		'name'  => 'Laptop Code',
		'class' => 'fa-solid fa-laptop-code',
	],
	[
		'name'  => 'Laptop File',
		'class' => 'fa-solid fa-laptop-file',
	],
	[
		'name'  => 'Laptop Medical',
		'class' => 'fa-solid fa-laptop-medical',
	],
	[
		'name'  => 'Laravel',
		'class' => 'fa-brands fa-laravel',
	],
	[
		'name'  => 'Lari Sign',
		'class' => 'fa-solid fa-lari-sign',
	],
	[
		'name'  => 'last.fm',
		'class' => 'fa-brands fa-lastfm',
	],
	[
		'name'  => 'Layer Group',
		'class' => 'fa-solid fa-layer-group',
	],
	[
		'name'  => 'Leaf',
		'class' => 'fa-solid fa-leaf',
	],
	[
		'name'  => 'Leanpub',
		'class' => 'fa-brands fa-leanpub',
	],
	[
		'name'  => 'Left Long',
		'class' => 'fa-solid fa-left-long',
	],
	[
		'name'  => 'Left Right',
		'class' => 'fa-solid fa-left-right',
	],
	[
		'name'  => 'Lemon',
		'class' => 'fa-solid fa-lemon',
	],
	[
		'name'  => 'Less',
		'class' => 'fa-brands fa-less',
	],
	[
		'name'  => 'Less Than',
		'class' => 'fa-solid fa-less-than',
	],
	[
		'name'  => 'Less Than Equal',
		'class' => 'fa-solid fa-less-than-equal',
	],
	[
		'name'  => 'Letterboxd',
		'class' => 'fa-brands fa-letterboxd',
	],
	[
		'name'  => 'Life Ring',
		'class' => 'fa-solid fa-life-ring',
	],
	[
		'name'  => 'Lightbulb',
		'class' => 'fa-solid fa-lightbulb',
	],
	[
		'name'  => 'Line',
		'class' => 'fa-brands fa-line',
	],
	[
		'name'  => 'Lines Leaning',
		'class' => 'fa-solid fa-lines-leaning',
	],
	[
		'name'  => 'Link',
		'class' => 'fa-solid fa-link',
	],
	[
		'name'  => 'Link Slash',
		'class' => 'fa-solid fa-link-slash',
	],
	[
		'name'  => 'LinkedIn',
		'class' => 'fa-brands fa-linkedin',
	],
	[
		'name'  => 'LinkedIn In',
		'class' => 'fa-brands fa-linkedin-in',
	],
	[
		'name'  => 'Linode',
		'class' => 'fa-brands fa-linode',
	],
	[
		'name'  => 'Linux',
		'class' => 'fa-brands fa-linux',
	],
	[
		'name'  => 'Lira Sign',
		'class' => 'fa-solid fa-lira-sign',
	],
	[
		'name'  => 'List',
		'class' => 'fa-solid fa-list',
	],
	[
		'name'  => 'List Check',
		'class' => 'fa-solid fa-list-check',
	],
	[
		'name'  => 'List Ol',
		'class' => 'fa-solid fa-list-ol',
	],
	[
		'name'  => 'List Ul',
		'class' => 'fa-solid fa-list-ul',
	],
	[
		'name'  => 'Litecoin Sign',
		'class' => 'fa-solid fa-litecoin-sign',
	],
	[
		'name'  => 'Location Arrow',
		'class' => 'fa-solid fa-location-arrow',
	],
	[
		'name'  => 'Location Crosshairs',
		'class' => 'fa-solid fa-location-crosshairs',
	],
	[
		'name'  => 'Location Dot',
		'class' => 'fa-solid fa-location-dot',
	],
	[
		'name'  => 'Location Pin',
		'class' => 'fa-solid fa-location-pin',
	],
	[
		'name'  => 'Location Pin Lock',
		'class' => 'fa-solid fa-location-pin-lock',
	],
	[
		'name'  => 'Lock',
		'class' => 'fa-solid fa-lock',
	],
	[
		'name'  => 'Lock Open',
		'class' => 'fa-solid fa-lock-open',
	],
	[
		'name'  => 'Locust',
		'class' => 'fa-solid fa-locust',
	],
	[
		'name'  => 'Lungs',
		'class' => 'fa-solid fa-lungs',
	],
	[
		'name'  => 'Lungs Virus',
		'class' => 'fa-solid fa-lungs-virus',
	],
	[
		'name'  => 'lyft',
		'class' => 'fa-brands fa-lyft',
	],
	[
		'name'  => 'M',
		'class' => 'fa-solid fa-m',
	],
	[
		'name'  => 'Magento',
		'class' => 'fa-brands fa-magento',
	],
	[
		'name'  => 'Magnet',
		'class' => 'fa-solid fa-magnet',
	],
	[
		'name'  => 'Magnifying Glass',
		'class' => 'fa-solid fa-magnifying-glass',
	],
	[
		'name'  => 'Magnifying Glass Arrow Right',
		'class' => 'fa-solid fa-magnifying-glass-arrow-right',
	],
	[
		'name'  => 'Magnifying Glass Chart',
		'class' => 'fa-solid fa-magnifying-glass-chart',
	],
	[
		'name'  => 'Magnifying Glass Dollar',
		'class' => 'fa-solid fa-magnifying-glass-dollar',
	],
	[
		'name'  => 'Magnifying Glass Location',
		'class' => 'fa-solid fa-magnifying-glass-location',
	],
	[
		'name'  => 'Magnifying Glass Minus',
		'class' => 'fa-solid fa-magnifying-glass-minus',
	],
	[
		'name'  => 'Magnifying Glass Plus',
		'class' => 'fa-solid fa-magnifying-glass-plus',
	],
	[
		'name'  => 'Mailchimp',
		'class' => 'fa-brands fa-mailchimp',
	],
	[
		'name'  => 'Manat Sign',
		'class' => 'fa-solid fa-manat-sign',
	],
	[
		'name'  => 'Mandalorian',
		'class' => 'fa-brands fa-mandalorian',
	],
	[
		'name'  => 'Map',
		'class' => 'fa-solid fa-map',
	],
	[
		'name'  => 'Map Location',
		'class' => 'fa-solid fa-map-location',
	],
	[
		'name'  => 'Map Location Dot',
		'class' => 'fa-solid fa-map-location-dot',
	],
	[
		'name'  => 'Map Pin',
		'class' => 'fa-solid fa-map-pin',
	],
	[
		'name'  => 'Markdown',
		'class' => 'fa-brands fa-markdown',
	],
	[
		'name'  => 'Marker',
		'class' => 'fa-solid fa-marker',
	],
	[
		'name'  => 'Mars',
		'class' => 'fa-solid fa-mars',
	],
	[
		'name'  => 'Mars And Venus',
		'class' => 'fa-solid fa-mars-and-venus',
	],
	[
		'name'  => 'Mars And Venus Burst',
		'class' => 'fa-solid fa-mars-and-venus-burst',
	],
	[
		'name'  => 'Mars Double',
		'class' => 'fa-solid fa-mars-double',
	],
	[
		'name'  => 'Mars Stroke',
		'class' => 'fa-solid fa-mars-stroke',
	],
	[
		'name'  => 'Mars Stroke Right',
		'class' => 'fa-solid fa-mars-stroke-right',
	],
	[
		'name'  => 'Mars Stroke Up',
		'class' => 'fa-solid fa-mars-stroke-up',
	],
	[
		'name'  => 'Martini Glass',
		'class' => 'fa-solid fa-martini-glass',
	],
	[
		'name'  => 'Martini Glass Citrus',
		'class' => 'fa-solid fa-martini-glass-citrus',
	],
	[
		'name'  => 'Martini Glass Empty',
		'class' => 'fa-solid fa-martini-glass-empty',
	],
	[
		'name'  => 'Mask',
		'class' => 'fa-solid fa-mask',
	],
	[
		'name'  => 'Mask Face',
		'class' => 'fa-solid fa-mask-face',
	],
	[
		'name'  => 'Mask Ventilator',
		'class' => 'fa-solid fa-mask-ventilator',
	],
	[
		'name'  => 'Masks Theater',
		'class' => 'fa-solid fa-masks-theater',
	],
	[
		'name'  => 'Mastodon',
		'class' => 'fa-brands fa-mastodon',
	],
	[
		'name'  => 'Mattress Pillow',
		'class' => 'fa-solid fa-mattress-pillow',
	],
	[
		'name'  => 'MaxCDN',
		'class' => 'fa-brands fa-maxcdn',
	],
	[
		'name'  => 'Maximize',
		'class' => 'fa-solid fa-maximize',
	],
	[
		'name'  => 'Material Design for Bootstrap',
		'class' => 'fa-brands fa-mdb',
	],
	[
		'name'  => 'Medal',
		'class' => 'fa-solid fa-medal',
	],
	[
		'name'  => 'MedApps',
		'class' => 'fa-brands fa-medapps',
	],
	[
		'name'  => 'Medium',
		'class' => 'fa-brands fa-medium',
	],
	[
		'name'  => 'MRT',
		'class' => 'fa-brands fa-medrt',
	],
	[
		'name'  => 'Meetup',
		'class' => 'fa-brands fa-meetup',
	],
	[
		'name'  => 'Megaport',
		'class' => 'fa-brands fa-megaport',
	],
	[
		'name'  => 'Memory',
		'class' => 'fa-solid fa-memory',
	],
	[
		'name'  => 'Mendeley',
		'class' => 'fa-brands fa-mendeley',
	],
	[
		'name'  => 'Menorah',
		'class' => 'fa-solid fa-menorah',
	],
	[
		'name'  => 'Mercury',
		'class' => 'fa-solid fa-mercury',
	],
	[
		'name'  => 'Message',
		'class' => 'fa-solid fa-message',
	],
	[
		'name'  => 'Meta',
		'class' => 'fa-brands fa-meta',
	],
	[
		'name'  => 'Meteor',
		'class' => 'fa-solid fa-meteor',
	],
	[
		'name'  => 'Micro.blog',
		'class' => 'fa-brands fa-microblog',
	],
	[
		'name'  => 'Microchip',
		'class' => 'fa-solid fa-microchip',
	],
	[
		'name'  => 'Microphone',
		'class' => 'fa-solid fa-microphone',
	],
	[
		'name'  => 'Microphone Lines',
		'class' => 'fa-solid fa-microphone-lines',
	],
	[
		'name'  => 'Microphone Lines Slash',
		'class' => 'fa-solid fa-microphone-lines-slash',
	],
	[
		'name'  => 'Microphone Slash',
		'class' => 'fa-solid fa-microphone-slash',
	],
	[
		'name'  => 'Microscope',
		'class' => 'fa-solid fa-microscope',
	],
	[
		'name'  => 'Microsoft',
		'class' => 'fa-brands fa-microsoft',
	],
	[
		'name'  => 'Mill Sign',
		'class' => 'fa-solid fa-mill-sign',
	],
	[
		'name'  => 'Minimize',
		'class' => 'fa-solid fa-minimize',
	],
	[
		'name'  => 'Mintbit',
		'class' => 'fa-brands fa-mintbit',
	],
	[
		'name'  => 'Minus',
		'class' => 'fa-solid fa-minus',
	],
	[
		'name'  => 'Mitten',
		'class' => 'fa-solid fa-mitten',
	],
	[
		'name'  => 'Mix',
		'class' => 'fa-brands fa-mix',
	],
	[
		'name'  => 'Mixcloud',
		'class' => 'fa-brands fa-mixcloud',
	],
	[
		'name'  => 'Mixer',
		'class' => 'fa-brands fa-mixer',
	],
	[
		'name'  => 'Mizuni',
		'class' => 'fa-brands fa-mizuni',
	],
	[
		'name'  => 'Mobile',
		'class' => 'fa-solid fa-mobile',
	],
	[
		'name'  => 'Mobile Button',
		'class' => 'fa-solid fa-mobile-button',
	],
	[
		'name'  => 'Mobile Retro',
		'class' => 'fa-solid fa-mobile-retro',
	],
	[
		'name'  => 'Mobile Screen',
		'class' => 'fa-solid fa-mobile-screen',
	],
	[
		'name'  => 'Mobile Screen Button',
		'class' => 'fa-solid fa-mobile-screen-button',
	],
	[
		'name'  => 'MODX',
		'class' => 'fa-brands fa-modx',
	],
	[
		'name'  => 'Monero',
		'class' => 'fa-brands fa-monero',
	],
	[
		'name'  => 'Money Bill',
		'class' => 'fa-solid fa-money-bill',
	],
	[
		'name'  => 'Money Bill 1',
		'class' => 'fa-solid fa-money-bill-1',
	],
	[
		'name'  => 'Money Bill 1 Wave',
		'class' => 'fa-solid fa-money-bill-1-wave',
	],
	[
		'name'  => 'Money Bill Transfer',
		'class' => 'fa-solid fa-money-bill-transfer',
	],
	[
		'name'  => 'Money Bill Trend Up',
		'class' => 'fa-solid fa-money-bill-trend-up',
	],
	[
		'name'  => 'Money Bill Wave',
		'class' => 'fa-solid fa-money-bill-wave',
	],
	[
		'name'  => 'Money Bill Wheat',
		'class' => 'fa-solid fa-money-bill-wheat',
	],
	[
		'name'  => 'Money Bills',
		'class' => 'fa-solid fa-money-bills',
	],
	[
		'name'  => 'Money Check',
		'class' => 'fa-solid fa-money-check',
	],
	[
		'name'  => 'Money Check Dollar',
		'class' => 'fa-solid fa-money-check-dollar',
	],
	[
		'name'  => 'Monument',
		'class' => 'fa-solid fa-monument',
	],
	[
		'name'  => 'Moon',
		'class' => 'fa-solid fa-moon',
	],
	[
		'name'  => 'Mortar Pestle',
		'class' => 'fa-solid fa-mortar-pestle',
	],
	[
		'name'  => 'Mosque',
		'class' => 'fa-solid fa-mosque',
	],
	[
		'name'  => 'Mosquito',
		'class' => 'fa-solid fa-mosquito',
	],
	[
		'name'  => 'Mosquito Net',
		'class' => 'fa-solid fa-mosquito-net',
	],
	[
		'name'  => 'Motorcycle',
		'class' => 'fa-solid fa-motorcycle',
	],
	[
		'name'  => 'Mound',
		'class' => 'fa-solid fa-mound',
	],
	[
		'name'  => 'Mountain',
		'class' => 'fa-solid fa-mountain',
	],
	[
		'name'  => 'Mountain City',
		'class' => 'fa-solid fa-mountain-city',
	],
	[
		'name'  => 'Mountain Sun',
		'class' => 'fa-solid fa-mountain-sun',
	],
	[
		'name'  => 'Mug Hot',
		'class' => 'fa-solid fa-mug-hot',
	],
	[
		'name'  => 'Mug Saucer',
		'class' => 'fa-solid fa-mug-saucer',
	],
	[
		'name'  => 'Music',
		'class' => 'fa-solid fa-music',
	],
	[
		'name'  => 'N',
		'class' => 'fa-solid fa-n',
	],
	[
		'name'  => 'Naira Sign',
		'class' => 'fa-solid fa-naira-sign',
	],
	[
		'name'  => 'Napster',
		'class' => 'fa-brands fa-napster',
	],
	[
		'name'  => 'Neos',
		'class' => 'fa-brands fa-neos',
	],
	[
		'name'  => 'Network Wired',
		'class' => 'fa-solid fa-network-wired',
	],
	[
		'name'  => 'Neuter',
		'class' => 'fa-solid fa-neuter',
	],
	[
		'name'  => 'Newspaper',
		'class' => 'fa-solid fa-newspaper',
	],
	[
		'name'  => 'NFC Directional',
		'class' => 'fa-brands fa-nfc-directional',
	],
	[
		'name'  => 'Nfc Symbol',
		'class' => 'fa-brands fa-nfc-symbol',
	],
	[
		'name'  => 'Nimblr',
		'class' => 'fa-brands fa-nimblr',
	],
	[
		'name'  => 'Node.js',
		'class' => 'fa-brands fa-node',
	],
	[
		'name'  => 'Node.js JS',
		'class' => 'fa-brands fa-node-js',
	],
	[
		'name'  => 'Not Equal',
		'class' => 'fa-solid fa-not-equal',
	],
	[
		'name'  => 'Notdef',
		'class' => 'fa-solid fa-notdef',
	],
	[
		'name'  => 'Note Sticky',
		'class' => 'fa-solid fa-note-sticky',
	],
	[
		'name'  => 'Notes Medical',
		'class' => 'fa-solid fa-notes-medical',
	],
	[
		'name'  => 'npm',
		'class' => 'fa-brands fa-npm',
	],
	[
		'name'  => 'NS8',
		'class' => 'fa-brands fa-ns8',
	],
	[
		'name'  => 'Nutritionix',
		'class' => 'fa-brands fa-nutritionix',
	],
	[
		'name'  => 'O',
		'class' => 'fa-solid fa-o',
	],
	[
		'name'  => 'Object Group',
		'class' => 'fa-solid fa-object-group',
	],
	[
		'name'  => 'Object Ungroup',
		'class' => 'fa-solid fa-object-ungroup',
	],
	[
		'name'  => 'Octopus Deploy',
		'class' => 'fa-brands fa-octopus-deploy',
	],
	[
		'name'  => 'Odnoklassniki',
		'class' => 'fa-brands fa-odnoklassniki',
	],
	[
		'name'  => 'Odysee',
		'class' => 'fa-brands fa-odysee',
	],
	[
		'name'  => 'Oil Can',
		'class' => 'fa-solid fa-oil-can',
	],
	[
		'name'  => 'Oil Well',
		'class' => 'fa-solid fa-oil-well',
	],
	[
		'name'  => 'Old Republic',
		'class' => 'fa-brands fa-old-republic',
	],
	[
		'name'  => 'Om',
		'class' => 'fa-solid fa-om',
	],
	[
		'name'  => 'OpenCart',
		'class' => 'fa-brands fa-opencart',
	],
	[
		'name'  => 'OpenID',
		'class' => 'fa-brands fa-openid',
	],
	[
		'name'  => 'Opensuse',
		'class' => 'fa-brands fa-opensuse',
	],
	[
		'name'  => 'Opera',
		'class' => 'fa-brands fa-opera',
	],
	[
		'name'  => 'Optin Monster',
		'class' => 'fa-brands fa-optin-monster',
	],
	[
		'name'  => 'ORCID',
		'class' => 'fa-brands fa-orcid',
	],
	[
		'name'  => 'Open Source Initiative',
		'class' => 'fa-brands fa-osi',
	],
	[
		'name'  => 'Otter',
		'class' => 'fa-solid fa-otter',
	],
	[
		'name'  => 'Outdent',
		'class' => 'fa-solid fa-outdent',
	],
	[
		'name'  => 'P',
		'class' => 'fa-solid fa-p',
	],
	[
		'name'  => 'Padlet',
		'class' => 'fa-brands fa-padlet',
	],
	[
		'name'  => 'page4 Corporation',
		'class' => 'fa-brands fa-page4',
	],
	[
		'name'  => 'Pagelines',
		'class' => 'fa-brands fa-pagelines',
	],
	[
		'name'  => 'Pager',
		'class' => 'fa-solid fa-pager',
	],
	[
		'name'  => 'Paint Roller',
		'class' => 'fa-solid fa-paint-roller',
	],
	[
		'name'  => 'Paintbrush',
		'class' => 'fa-solid fa-paintbrush',
	],
	[
		'name'  => 'Palette',
		'class' => 'fa-solid fa-palette',
	],
	[
		'name'  => 'Palfed',
		'class' => 'fa-brands fa-palfed',
	],
	[
		'name'  => 'Pallet',
		'class' => 'fa-solid fa-pallet',
	],
	[
		'name'  => 'Panorama',
		'class' => 'fa-solid fa-panorama',
	],
	[
		'name'  => 'Paper Plane',
		'class' => 'fa-solid fa-paper-plane',
	],
	[
		'name'  => 'Paperclip',
		'class' => 'fa-solid fa-paperclip',
	],
	[
		'name'  => 'Parachute Box',
		'class' => 'fa-solid fa-parachute-box',
	],
	[
		'name'  => 'Paragraph',
		'class' => 'fa-solid fa-paragraph',
	],
	[
		'name'  => 'Passport',
		'class' => 'fa-solid fa-passport',
	],
	[
		'name'  => 'Paste',
		'class' => 'fa-solid fa-paste',
	],
	[
		'name'  => 'Patreon',
		'class' => 'fa-brands fa-patreon',
	],
	[
		'name'  => 'Pause',
		'class' => 'fa-solid fa-pause',
	],
	[
		'name'  => 'Paw',
		'class' => 'fa-solid fa-paw',
	],
	[
		'name'  => 'Paypal',
		'class' => 'fa-brands fa-paypal',
	],
	[
		'name'  => 'Peace',
		'class' => 'fa-solid fa-peace',
	],
	[
		'name'  => 'Pen',
		'class' => 'fa-solid fa-pen',
	],
	[
		'name'  => 'Pen Clip',
		'class' => 'fa-solid fa-pen-clip',
	],
	[
		'name'  => 'Pen Fancy',
		'class' => 'fa-solid fa-pen-fancy',
	],
	[
		'name'  => 'Pen Nib',
		'class' => 'fa-solid fa-pen-nib',
	],
	[
		'name'  => 'Pen Ruler',
		'class' => 'fa-solid fa-pen-ruler',
	],
	[
		'name'  => 'Pen To Square',
		'class' => 'fa-solid fa-pen-to-square',
	],
	[
		'name'  => 'Pencil',
		'class' => 'fa-solid fa-pencil',
	],
	[
		'name'  => 'People Arrows',
		'class' => 'fa-solid fa-people-arrows',
	],
	[
		'name'  => 'People Carry Box',
		'class' => 'fa-solid fa-people-carry-box',
	],
	[
		'name'  => 'People Group',
		'class' => 'fa-solid fa-people-group',
	],
	[
		'name'  => 'People Line',
		'class' => 'fa-solid fa-people-line',
	],
	[
		'name'  => 'People Pulling',
		'class' => 'fa-solid fa-people-pulling',
	],
	[
		'name'  => 'People Robbery',
		'class' => 'fa-solid fa-people-robbery',
	],
	[
		'name'  => 'People Roof',
		'class' => 'fa-solid fa-people-roof',
	],
	[
		'name'  => 'Pepper Hot',
		'class' => 'fa-solid fa-pepper-hot',
	],
	[
		'name'  => 'PerByte',
		'class' => 'fa-brands fa-perbyte',
	],
	[
		'name'  => 'Percent',
		'class' => 'fa-solid fa-percent',
	],
	[
		'name'  => 'Periscope',
		'class' => 'fa-brands fa-periscope',
	],
	[
		'name'  => 'Person',
		'class' => 'fa-solid fa-person',
	],
	[
		'name'  => 'Person Arrow Down To Line',
		'class' => 'fa-solid fa-person-arrow-down-to-line',
	],
	[
		'name'  => 'Person Arrow Up From Line',
		'class' => 'fa-solid fa-person-arrow-up-from-line',
	],
	[
		'name'  => 'Person Biking',
		'class' => 'fa-solid fa-person-biking',
	],
	[
		'name'  => 'Person Booth',
		'class' => 'fa-solid fa-person-booth',
	],
	[
		'name'  => 'Person Breastfeeding',
		'class' => 'fa-solid fa-person-breastfeeding',
	],
	[
		'name'  => 'Person Burst',
		'class' => 'fa-solid fa-person-burst',
	],
	[
		'name'  => 'Person Cane',
		'class' => 'fa-solid fa-person-cane',
	],
	[
		'name'  => 'Person Chalkboard',
		'class' => 'fa-solid fa-person-chalkboard',
	],
	[
		'name'  => 'Person Circle Check',
		'class' => 'fa-solid fa-person-circle-check',
	],
	[
		'name'  => 'Person Circle Exclamation',
		'class' => 'fa-solid fa-person-circle-exclamation',
	],
	[
		'name'  => 'Person Circle Minus',
		'class' => 'fa-solid fa-person-circle-minus',
	],
	[
		'name'  => 'Person Circle Plus',
		'class' => 'fa-solid fa-person-circle-plus',
	],
	[
		'name'  => 'Person Circle Question',
		'class' => 'fa-solid fa-person-circle-question',
	],
	[
		'name'  => 'Person Circle Xmark',
		'class' => 'fa-solid fa-person-circle-xmark',
	],
	[
		'name'  => 'Person Digging',
		'class' => 'fa-solid fa-person-digging',
	],
	[
		'name'  => 'Person Dots From Line',
		'class' => 'fa-solid fa-person-dots-from-line',
	],
	[
		'name'  => 'Person Dress',
		'class' => 'fa-solid fa-person-dress',
	],
	[
		'name'  => 'Person Dress Burst',
		'class' => 'fa-solid fa-person-dress-burst',
	],
	[
		'name'  => 'Person Drowning',
		'class' => 'fa-solid fa-person-drowning',
	],
	[
		'name'  => 'Person Falling',
		'class' => 'fa-solid fa-person-falling',
	],
	[
		'name'  => 'Person Falling Burst',
		'class' => 'fa-solid fa-person-falling-burst',
	],
	[
		'name'  => 'Person Half Dress',
		'class' => 'fa-solid fa-person-half-dress',
	],
	[
		'name'  => 'Person Harassing',
		'class' => 'fa-solid fa-person-harassing',
	],
	[
		'name'  => 'Person Hiking',
		'class' => 'fa-solid fa-person-hiking',
	],
	[
		'name'  => 'Person Military Pointing',
		'class' => 'fa-solid fa-person-military-pointing',
	],
	[
		'name'  => 'Person Military Rifle',
		'class' => 'fa-solid fa-person-military-rifle',
	],
	[
		'name'  => 'Person Military To Person',
		'class' => 'fa-solid fa-person-military-to-person',
	],
	[
		'name'  => 'Person Praying',
		'class' => 'fa-solid fa-person-praying',
	],
	[
		'name'  => 'Person Pregnant',
		'class' => 'fa-solid fa-person-pregnant',
	],
	[
		'name'  => 'Person Rays',
		'class' => 'fa-solid fa-person-rays',
	],
	[
		'name'  => 'Person Rifle',
		'class' => 'fa-solid fa-person-rifle',
	],
	[
		'name'  => 'Person Running',
		'class' => 'fa-solid fa-person-running',
	],
	[
		'name'  => 'Person Shelter',
		'class' => 'fa-solid fa-person-shelter',
	],
	[
		'name'  => 'Person Skating',
		'class' => 'fa-solid fa-person-skating',
	],
	[
		'name'  => 'Person Skiing',
		'class' => 'fa-solid fa-person-skiing',
	],
	[
		'name'  => 'Person Skiing Nordic',
		'class' => 'fa-solid fa-person-skiing-nordic',
	],
	[
		'name'  => 'Person Snowboarding',
		'class' => 'fa-solid fa-person-snowboarding',
	],
	[
		'name'  => 'Person Swimming',
		'class' => 'fa-solid fa-person-swimming',
	],
	[
		'name'  => 'Person Through Window',
		'class' => 'fa-solid fa-person-through-window',
	],
	[
		'name'  => 'Person Walking',
		'class' => 'fa-solid fa-person-walking',
	],
	[
		'name'  => 'Person Walking Arrow Loop Left',
		'class' => 'fa-solid fa-person-walking-arrow-loop-left',
	],
	[
		'name'  => 'Person Walking Arrow Right',
		'class' => 'fa-solid fa-person-walking-arrow-right',
	],
	[
		'name'  => 'Person Walking Dashed Line Arrow Right',
		'class' => 'fa-solid fa-person-walking-dashed-line-arrow-right',
	],
	[
		'name'  => 'Person Walking Luggage',
		'class' => 'fa-solid fa-person-walking-luggage',
	],
	[
		'name'  => 'Person Walking With Cane',
		'class' => 'fa-solid fa-person-walking-with-cane',
	],
	[
		'name'  => 'Peseta Sign',
		'class' => 'fa-solid fa-peseta-sign',
	],
	[
		'name'  => 'Peso Sign',
		'class' => 'fa-solid fa-peso-sign',
	],
	[
		'name'  => 'Phabricator',
		'class' => 'fa-brands fa-phabricator',
	],
	[
		'name'  => 'Phoenix Framework',
		'class' => 'fa-brands fa-phoenix-framework',
	],
	[
		'name'  => 'Phoenix Squadron',
		'class' => 'fa-brands fa-phoenix-squadron',
	],
	[
		'name'  => 'Phone',
		'class' => 'fa-solid fa-phone',
	],
	[
		'name'  => 'Phone Flip',
		'class' => 'fa-solid fa-phone-flip',
	],
	[
		'name'  => 'Phone Slash',
		'class' => 'fa-solid fa-phone-slash',
	],
	[
		'name'  => 'Phone Volume',
		'class' => 'fa-solid fa-phone-volume',
	],
	[
		'name'  => 'Photo Film',
		'class' => 'fa-solid fa-photo-film',
	],
	[
		'name'  => 'PHP',
		'class' => 'fa-brands fa-php',
	],
	[
		'name'  => 'Pied Piper Logo',
		'class' => 'fa-brands fa-pied-piper',
	],
	[
		'name'  => 'Alternate Pied Piper Logo (Old)',
		'class' => 'fa-brands fa-pied-piper-alt',
	],
	[
		'name'  => 'Pied Piper Hat (Old)',
		'class' => 'fa-brands fa-pied-piper-hat',
	],
	[
		'name'  => 'Pied Piper PP Logo (Old)',
		'class' => 'fa-brands fa-pied-piper-pp',
	],
	[
		'name'  => 'Piggy Bank',
		'class' => 'fa-solid fa-piggy-bank',
	],
	[
		'name'  => 'Pills',
		'class' => 'fa-solid fa-pills',
	],
	[
		'name'  => 'Pinterest',
		'class' => 'fa-brands fa-pinterest',
	],
	[
		'name'  => 'Pinterest P',
		'class' => 'fa-brands fa-pinterest-p',
	],
	[
		'name'  => 'Pix',
		'class' => 'fa-brands fa-pix',
	],
	[
		'name'  => 'Pixiv',
		'class' => 'fa-brands fa-pixiv',
	],
	[
		'name'  => 'Pizza Slice',
		'class' => 'fa-solid fa-pizza-slice',
	],
	[
		'name'  => 'Place Of Worship',
		'class' => 'fa-solid fa-place-of-worship',
	],
	[
		'name'  => 'Plane',
		'class' => 'fa-solid fa-plane',
	],
	[
		'name'  => 'Plane Arrival',
		'class' => 'fa-solid fa-plane-arrival',
	],
	[
		'name'  => 'Plane Circle Check',
		'class' => 'fa-solid fa-plane-circle-check',
	],
	[
		'name'  => 'Plane Circle Exclamation',
		'class' => 'fa-solid fa-plane-circle-exclamation',
	],
	[
		'name'  => 'Plane Circle Xmark',
		'class' => 'fa-solid fa-plane-circle-xmark',
	],
	[
		'name'  => 'Plane Departure',
		'class' => 'fa-solid fa-plane-departure',
	],
	[
		'name'  => 'Plane Lock',
		'class' => 'fa-solid fa-plane-lock',
	],
	[
		'name'  => 'Plane Slash',
		'class' => 'fa-solid fa-plane-slash',
	],
	[
		'name'  => 'Plane Up',
		'class' => 'fa-solid fa-plane-up',
	],
	[
		'name'  => 'Plant Wilt',
		'class' => 'fa-solid fa-plant-wilt',
	],
	[
		'name'  => 'Plate Wheat',
		'class' => 'fa-solid fa-plate-wheat',
	],
	[
		'name'  => 'Play',
		'class' => 'fa-solid fa-play',
	],
	[
		'name'  => 'PlayStation',
		'class' => 'fa-brands fa-playstation',
	],
	[
		'name'  => 'Plug',
		'class' => 'fa-solid fa-plug',
	],
	[
		'name'  => 'Plug Circle Bolt',
		'class' => 'fa-solid fa-plug-circle-bolt',
	],
	[
		'name'  => 'Plug Circle Check',
		'class' => 'fa-solid fa-plug-circle-check',
	],
	[
		'name'  => 'Plug Circle Exclamation',
		'class' => 'fa-solid fa-plug-circle-exclamation',
	],
	[
		'name'  => 'Plug Circle Minus',
		'class' => 'fa-solid fa-plug-circle-minus',
	],
	[
		'name'  => 'Plug Circle Plus',
		'class' => 'fa-solid fa-plug-circle-plus',
	],
	[
		'name'  => 'Plug Circle Xmark',
		'class' => 'fa-solid fa-plug-circle-xmark',
	],
	[
		'name'  => 'Plus',
		'class' => 'fa-solid fa-plus',
	],
	[
		'name'  => 'Plus Minus',
		'class' => 'fa-solid fa-plus-minus',
	],
	[
		'name'  => 'Podcast',
		'class' => 'fa-solid fa-podcast',
	],
	[
		'name'  => 'Poo',
		'class' => 'fa-solid fa-poo',
	],
	[
		'name'  => 'Poo Storm',
		'class' => 'fa-solid fa-poo-storm',
	],
	[
		'name'  => 'Poop',
		'class' => 'fa-solid fa-poop',
	],
	[
		'name'  => 'Power Off',
		'class' => 'fa-solid fa-power-off',
	],
	[
		'name'  => 'Prescription',
		'class' => 'fa-solid fa-prescription',
	],
	[
		'name'  => 'Prescription Bottle',
		'class' => 'fa-solid fa-prescription-bottle',
	],
	[
		'name'  => 'Prescription Bottle Medical',
		'class' => 'fa-solid fa-prescription-bottle-medical',
	],
	[
		'name'  => 'Print',
		'class' => 'fa-solid fa-print',
	],
	[
		'name'  => 'Product Hunt',
		'class' => 'fa-brands fa-product-hunt',
	],
	[
		'name'  => 'Pump Medical',
		'class' => 'fa-solid fa-pump-medical',
	],
	[
		'name'  => 'Pump Soap',
		'class' => 'fa-solid fa-pump-soap',
	],
	[
		'name'  => 'Pushed',
		'class' => 'fa-brands fa-pushed',
	],
	[
		'name'  => 'Puzzle Piece',
		'class' => 'fa-solid fa-puzzle-piece',
	],
	[
		'name'  => 'Python',
		'class' => 'fa-brands fa-python',
	],
	[
		'name'  => 'Q',
		'class' => 'fa-solid fa-q',
	],
	[
		'name'  => 'QQ',
		'class' => 'fa-brands fa-qq',
	],
	[
		'name'  => 'Qrcode',
		'class' => 'fa-solid fa-qrcode',
	],
	[
		'name'  => 'Question',
		'class' => 'fa-solid fa-question',
	],
	[
		'name'  => 'QuinScape',
		'class' => 'fa-brands fa-quinscape',
	],
	[
		'name'  => 'Quora',
		'class' => 'fa-brands fa-quora',
	],
	[
		'name'  => 'Quote Left',
		'class' => 'fa-solid fa-quote-left',
	],
	[
		'name'  => 'Quote Right',
		'class' => 'fa-solid fa-quote-right',
	],
	[
		'name'  => 'R',
		'class' => 'fa-solid fa-r',
	],
	[
		'name'  => 'R Project',
		'class' => 'fa-brands fa-r-project',
	],
	[
		'name'  => 'Radiation',
		'class' => 'fa-solid fa-radiation',
	],
	[
		'name'  => 'Radio',
		'class' => 'fa-solid fa-radio',
	],
	[
		'name'  => 'Rainbow',
		'class' => 'fa-solid fa-rainbow',
	],
	[
		'name'  => 'Ranking Star',
		'class' => 'fa-solid fa-ranking-star',
	],
	[
		'name'  => 'Raspberry Pi',
		'class' => 'fa-brands fa-raspberry-pi',
	],
	[
		'name'  => 'Ravelry',
		'class' => 'fa-brands fa-ravelry',
	],
	[
		'name'  => 'React',
		'class' => 'fa-brands fa-react',
	],
	[
		'name'  => 'ReactEurope',
		'class' => 'fa-brands fa-reacteurope',
	],
	[
		'name'  => 'ReadMe',
		'class' => 'fa-brands fa-readme',
	],
	[
		'name'  => 'Rebel Alliance',
		'class' => 'fa-brands fa-rebel',
	],
	[
		'name'  => 'Receipt',
		'class' => 'fa-solid fa-receipt',
	],
	[
		'name'  => 'Record Vinyl',
		'class' => 'fa-solid fa-record-vinyl',
	],
	[
		'name'  => 'Rectangle Ad',
		'class' => 'fa-solid fa-rectangle-ad',
	],
	[
		'name'  => 'Rectangle List',
		'class' => 'fa-solid fa-rectangle-list',
	],
	[
		'name'  => 'Rectangle Xmark',
		'class' => 'fa-solid fa-rectangle-xmark',
	],
	[
		'name'  => 'Recycle',
		'class' => 'fa-solid fa-recycle',
	],
	[
		'name'  => 'red river',
		'class' => 'fa-brands fa-red-river',
	],
	[
		'name'  => 'Reddit',
		'class' => 'fa-brands fa-reddit',
	],
	[
		'name'  => 'Reddit Alien',
		'class' => 'fa-brands fa-reddit-alien',
	],
	[
		'name'  => 'Redhat',
		'class' => 'fa-brands fa-redhat',
	],
	[
		'name'  => 'Registered',
		'class' => 'fa-solid fa-registered',
	],
	[
		'name'  => 'Renren',
		'class' => 'fa-brands fa-renren',
	],
	[
		'name'  => 'Repeat',
		'class' => 'fa-solid fa-repeat',
	],
	[
		'name'  => 'Reply',
		'class' => 'fa-solid fa-reply',
	],
	[
		'name'  => 'Reply All',
		'class' => 'fa-solid fa-reply-all',
	],
	[
		'name'  => 'replyd',
		'class' => 'fa-brands fa-replyd',
	],
	[
		'name'  => 'Republican',
		'class' => 'fa-solid fa-republican',
	],
	[
		'name'  => 'Researchgate',
		'class' => 'fa-brands fa-researchgate',
	],
	[
		'name'  => 'Resolving',
		'class' => 'fa-brands fa-resolving',
	],
	[
		'name'  => 'Restroom',
		'class' => 'fa-solid fa-restroom',
	],
	[
		'name'  => 'Retweet',
		'class' => 'fa-solid fa-retweet',
	],
	[
		'name'  => 'Rev.io',
		'class' => 'fa-brands fa-rev',
	],
	[
		'name'  => 'Ribbon',
		'class' => 'fa-solid fa-ribbon',
	],
	[
		'name'  => 'Right From Bracket',
		'class' => 'fa-solid fa-right-from-bracket',
	],
	[
		'name'  => 'Right Left',
		'class' => 'fa-solid fa-right-left',
	],
	[
		'name'  => 'Right Long',
		'class' => 'fa-solid fa-right-long',
	],
	[
		'name'  => 'Right To Bracket',
		'class' => 'fa-solid fa-right-to-bracket',
	],
	[
		'name'  => 'Ring',
		'class' => 'fa-solid fa-ring',
	],
	[
		'name'  => 'Road',
		'class' => 'fa-solid fa-road',
	],
	[
		'name'  => 'Road Barrier',
		'class' => 'fa-solid fa-road-barrier',
	],
	[
		'name'  => 'Road Bridge',
		'class' => 'fa-solid fa-road-bridge',
	],
	[
		'name'  => 'Road Circle Check',
		'class' => 'fa-solid fa-road-circle-check',
	],
	[
		'name'  => 'Road Circle Exclamation',
		'class' => 'fa-solid fa-road-circle-exclamation',
	],
	[
		'name'  => 'Road Circle Xmark',
		'class' => 'fa-solid fa-road-circle-xmark',
	],
	[
		'name'  => 'Road Lock',
		'class' => 'fa-solid fa-road-lock',
	],
	[
		'name'  => 'Road Spikes',
		'class' => 'fa-solid fa-road-spikes',
	],
	[
		'name'  => 'Robot',
		'class' => 'fa-solid fa-robot',
	],
	[
		'name'  => 'Rocket',
		'class' => 'fa-solid fa-rocket',
	],
	[
		'name'  => 'Rocket.Chat',
		'class' => 'fa-brands fa-rocketchat',
	],
	[
		'name'  => 'Rockrms',
		'class' => 'fa-brands fa-rockrms',
	],
	[
		'name'  => 'Rotate',
		'class' => 'fa-solid fa-rotate',
	],
	[
		'name'  => 'Rotate Left',
		'class' => 'fa-solid fa-rotate-left',
	],
	[
		'name'  => 'Rotate Right',
		'class' => 'fa-solid fa-rotate-right',
	],
	[
		'name'  => 'Route',
		'class' => 'fa-solid fa-route',
	],
	[
		'name'  => 'Rss',
		'class' => 'fa-solid fa-rss',
	],
	[
		'name'  => 'Ruble Sign',
		'class' => 'fa-solid fa-ruble-sign',
	],
	[
		'name'  => 'Rug',
		'class' => 'fa-solid fa-rug',
	],
	[
		'name'  => 'Ruler',
		'class' => 'fa-solid fa-ruler',
	],
	[
		'name'  => 'Ruler Combined',
		'class' => 'fa-solid fa-ruler-combined',
	],
	[
		'name'  => 'Ruler Horizontal',
		'class' => 'fa-solid fa-ruler-horizontal',
	],
	[
		'name'  => 'Ruler Vertical',
		'class' => 'fa-solid fa-ruler-vertical',
	],
	[
		'name'  => 'Rupee Sign',
		'class' => 'fa-solid fa-rupee-sign',
	],
	[
		'name'  => 'Rupiah Sign',
		'class' => 'fa-solid fa-rupiah-sign',
	],
	[
		'name'  => 'Rust',
		'class' => 'fa-brands fa-rust',
	],
	[
		'name'  => 'S',
		'class' => 'fa-solid fa-s',
	],
	[
		'name'  => 'Sack Dollar',
		'class' => 'fa-solid fa-sack-dollar',
	],
	[
		'name'  => 'Sack Xmark',
		'class' => 'fa-solid fa-sack-xmark',
	],
	[
		'name'  => 'Safari',
		'class' => 'fa-brands fa-safari',
	],
	[
		'name'  => 'Sailboat',
		'class' => 'fa-solid fa-sailboat',
	],
	[
		'name'  => 'Salesforce',
		'class' => 'fa-brands fa-salesforce',
	],
	[
		'name'  => 'Sass',
		'class' => 'fa-brands fa-sass',
	],
	[
		'name'  => 'Satellite',
		'class' => 'fa-solid fa-satellite',
	],
	[
		'name'  => 'Satellite Dish',
		'class' => 'fa-solid fa-satellite-dish',
	],
	[
		'name'  => 'Scale Balanced',
		'class' => 'fa-solid fa-scale-balanced',
	],
	[
		'name'  => 'Scale Unbalanced',
		'class' => 'fa-solid fa-scale-unbalanced',
	],
	[
		'name'  => 'Scale Unbalanced Flip',
		'class' => 'fa-solid fa-scale-unbalanced-flip',
	],
	[
		'name'  => 'SCHLIX',
		'class' => 'fa-brands fa-schlix',
	],
	[
		'name'  => 'School',
		'class' => 'fa-solid fa-school',
	],
	[
		'name'  => 'School Circle Check',
		'class' => 'fa-solid fa-school-circle-check',
	],
	[
		'name'  => 'School Circle Exclamation',
		'class' => 'fa-solid fa-school-circle-exclamation',
	],
	[
		'name'  => 'School Circle Xmark',
		'class' => 'fa-solid fa-school-circle-xmark',
	],
	[
		'name'  => 'School Flag',
		'class' => 'fa-solid fa-school-flag',
	],
	[
		'name'  => 'School Lock',
		'class' => 'fa-solid fa-school-lock',
	],
	[
		'name'  => 'Scissors',
		'class' => 'fa-solid fa-scissors',
	],
	[
		'name'  => 'Screenpal',
		'class' => 'fa-brands fa-screenpal',
	],
	[
		'name'  => 'Screwdriver',
		'class' => 'fa-solid fa-screwdriver',
	],
	[
		'name'  => 'Screwdriver Wrench',
		'class' => 'fa-solid fa-screwdriver-wrench',
	],
	[
		'name'  => 'Scribd',
		'class' => 'fa-brands fa-scribd',
	],
	[
		'name'  => 'Scroll',
		'class' => 'fa-solid fa-scroll',
	],
	[
		'name'  => 'Scroll Torah',
		'class' => 'fa-solid fa-scroll-torah',
	],
	[
		'name'  => 'Sd Card',
		'class' => 'fa-solid fa-sd-card',
	],
	[
		'name'  => 'Searchengin',
		'class' => 'fa-brands fa-searchengin',
	],
	[
		'name'  => 'Section',
		'class' => 'fa-solid fa-section',
	],
	[
		'name'  => 'Seedling',
		'class' => 'fa-solid fa-seedling',
	],
	[
		'name'  => 'Sellcast',
		'class' => 'fa-brands fa-sellcast',
	],
	[
		'name'  => 'Sellsy',
		'class' => 'fa-brands fa-sellsy',
	],
	[
		'name'  => 'Server',
		'class' => 'fa-solid fa-server',
	],
	[
		'name'  => 'Servicestack',
		'class' => 'fa-brands fa-servicestack',
	],
	[
		'name'  => 'Shapes',
		'class' => 'fa-solid fa-shapes',
	],
	[
		'name'  => 'Share',
		'class' => 'fa-solid fa-share',
	],
	[
		'name'  => 'Share From Square',
		'class' => 'fa-solid fa-share-from-square',
	],
	[
		'name'  => 'Share Nodes',
		'class' => 'fa-solid fa-share-nodes',
	],
	[
		'name'  => 'Sheet Plastic',
		'class' => 'fa-solid fa-sheet-plastic',
	],
	[
		'name'  => 'Shekel Sign',
		'class' => 'fa-solid fa-shekel-sign',
	],
	[
		'name'  => 'Shield',
		'class' => 'fa-solid fa-shield',
	],
	[
		'name'  => 'Shield Cat',
		'class' => 'fa-solid fa-shield-cat',
	],
	[
		'name'  => 'Shield Dog',
		'class' => 'fa-solid fa-shield-dog',
	],
	[
		'name'  => 'Shield Halved',
		'class' => 'fa-solid fa-shield-halved',
	],
	[
		'name'  => 'Shield Heart',
		'class' => 'fa-solid fa-shield-heart',
	],
	[
		'name'  => 'Shield Virus',
		'class' => 'fa-solid fa-shield-virus',
	],
	[
		'name'  => 'Ship',
		'class' => 'fa-solid fa-ship',
	],
	[
		'name'  => 'Shirt',
		'class' => 'fa-solid fa-shirt',
	],
	[
		'name'  => 'Shirts in Bulk',
		'class' => 'fa-brands fa-shirtsinbulk',
	],
	[
		'name'  => 'Shoe Prints',
		'class' => 'fa-solid fa-shoe-prints',
	],
	[
		'name'  => 'Shoelace',
		'class' => 'fa-brands fa-shoelace',
	],
	[
		'name'  => 'Shop',
		'class' => 'fa-solid fa-shop',
	],
	[
		'name'  => 'Shop Lock',
		'class' => 'fa-solid fa-shop-lock',
	],
	[
		'name'  => 'Shop Slash',
		'class' => 'fa-solid fa-shop-slash',
	],
	[
		'name'  => 'Shopify',
		'class' => 'fa-brands fa-shopify',
	],
	[
		'name'  => 'Shopware',
		'class' => 'fa-brands fa-shopware',
	],
	[
		'name'  => 'Shower',
		'class' => 'fa-solid fa-shower',
	],
	[
		'name'  => 'Shrimp',
		'class' => 'fa-solid fa-shrimp',
	],
	[
		'name'  => 'Shuffle',
		'class' => 'fa-solid fa-shuffle',
	],
	[
		'name'  => 'Shuttle Space',
		'class' => 'fa-solid fa-shuttle-space',
	],
	[
		'name'  => 'Sign Hanging',
		'class' => 'fa-solid fa-sign-hanging',
	],
	[
		'name'  => 'Signal',
		'class' => 'fa-solid fa-signal',
	],
	[
		'name'  => 'Signal Messenger',
		'class' => 'fa-brands fa-signal-messenger',
	],
	[
		'name'  => 'Signature',
		'class' => 'fa-solid fa-signature',
	],
	[
		'name'  => 'Signs Post',
		'class' => 'fa-solid fa-signs-post',
	],
	[
		'name'  => 'Sim Card',
		'class' => 'fa-solid fa-sim-card',
	],
	[
		'name'  => 'SimplyBuilt',
		'class' => 'fa-brands fa-simplybuilt',
	],
	[
		'name'  => 'Sink',
		'class' => 'fa-solid fa-sink',
	],
	[
		'name'  => 'SISTRIX',
		'class' => 'fa-brands fa-sistrix',
	],
	[
		'name'  => 'Sitemap',
		'class' => 'fa-solid fa-sitemap',
	],
	[
		'name'  => 'Sith',
		'class' => 'fa-brands fa-sith',
	],
	[
		'name'  => 'Sitrox',
		'class' => 'fa-brands fa-sitrox',
	],
	[
		'name'  => 'Sketch',
		'class' => 'fa-brands fa-sketch',
	],
	[
		'name'  => 'Skull',
		'class' => 'fa-solid fa-skull',
	],
	[
		'name'  => 'Skull Crossbones',
		'class' => 'fa-solid fa-skull-crossbones',
	],
	[
		'name'  => 'skyatlas',
		'class' => 'fa-brands fa-skyatlas',
	],
	[
		'name'  => 'Skype',
		'class' => 'fa-brands fa-skype',
	],
	[
		'name'  => 'Slack Logo',
		'class' => 'fa-brands fa-slack',
	],
	[
		'name'  => 'Slash',
		'class' => 'fa-solid fa-slash',
	],
	[
		'name'  => 'Sleigh',
		'class' => 'fa-solid fa-sleigh',
	],
	[
		'name'  => 'Sliders',
		'class' => 'fa-solid fa-sliders',
	],
	[
		'name'  => 'Slideshare',
		'class' => 'fa-brands fa-slideshare',
	],
	[
		'name'  => 'Smog',
		'class' => 'fa-solid fa-smog',
	],
	[
		'name'  => 'Smoking',
		'class' => 'fa-solid fa-smoking',
	],
	[
		'name'  => 'Snapchat',
		'class' => 'fa-brands fa-snapchat',
	],
	[
		'name'  => 'Snowflake',
		'class' => 'fa-solid fa-snowflake',
	],
	[
		'name'  => 'Snowman',
		'class' => 'fa-solid fa-snowman',
	],
	[
		'name'  => 'Snowplow',
		'class' => 'fa-solid fa-snowplow',
	],
	[
		'name'  => 'Soap',
		'class' => 'fa-solid fa-soap',
	],
	[
		'name'  => 'Socks',
		'class' => 'fa-solid fa-socks',
	],
	[
		'name'  => 'Solar Panel',
		'class' => 'fa-solid fa-solar-panel',
	],
	[
		'name'  => 'Sort',
		'class' => 'fa-solid fa-sort',
	],
	[
		'name'  => 'Sort Down',
		'class' => 'fa-solid fa-sort-down',
	],
	[
		'name'  => 'Sort Up',
		'class' => 'fa-solid fa-sort-up',
	],
	[
		'name'  => 'SoundCloud',
		'class' => 'fa-brands fa-soundcloud',
	],
	[
		'name'  => 'Sourcetree',
		'class' => 'fa-brands fa-sourcetree',
	],
	[
		'name'  => 'Spa',
		'class' => 'fa-solid fa-spa',
	],
	[
		'name'  => 'Space Awesome',
		'class' => 'fa-brands fa-space-awesome',
	],
	[
		'name'  => 'Spaghetti Monster Flying',
		'class' => 'fa-solid fa-spaghetti-monster-flying',
	],
	[
		'name'  => 'Speakap',
		'class' => 'fa-brands fa-speakap',
	],
	[
		'name'  => 'Speaker Deck',
		'class' => 'fa-brands fa-speaker-deck',
	],
	[
		'name'  => 'Spell Check',
		'class' => 'fa-solid fa-spell-check',
	],
	[
		'name'  => 'Spider',
		'class' => 'fa-solid fa-spider',
	],
	[
		'name'  => 'Spinner',
		'class' => 'fa-solid fa-spinner',
	],
	[
		'name'  => 'Splotch',
		'class' => 'fa-solid fa-splotch',
	],
	[
		'name'  => 'Spoon',
		'class' => 'fa-solid fa-spoon',
	],
	[
		'name'  => 'Spotify',
		'class' => 'fa-brands fa-spotify',
	],
	[
		'name'  => 'Spray Can',
		'class' => 'fa-solid fa-spray-can',
	],
	[
		'name'  => 'Spray Can Sparkles',
		'class' => 'fa-solid fa-spray-can-sparkles',
	],
	[
		'name'  => 'Square',
		'class' => 'fa-solid fa-square',
	],
	[
		'name'  => 'Square Arrow Up Right',
		'class' => 'fa-solid fa-square-arrow-up-right',
	],
	[
		'name'  => 'Square Behance',
		'class' => 'fa-brands fa-square-behance',
	],
	[
		'name'  => 'Square Caret Down',
		'class' => 'fa-solid fa-square-caret-down',
	],
	[
		'name'  => 'Square Caret Left',
		'class' => 'fa-solid fa-square-caret-left',
	],
	[
		'name'  => 'Square Caret Right',
		'class' => 'fa-solid fa-square-caret-right',
	],
	[
		'name'  => 'Square Caret Up',
		'class' => 'fa-solid fa-square-caret-up',
	],
	[
		'name'  => 'Square Check',
		'class' => 'fa-solid fa-square-check',
	],
	[
		'name'  => 'Square Dribbble',
		'class' => 'fa-brands fa-square-dribbble',
	],
	[
		'name'  => 'Square Envelope',
		'class' => 'fa-solid fa-square-envelope',
	],
	[
		'name'  => 'Square Facebook',
		'class' => 'fa-brands fa-square-facebook',
	],
	[
		'name'  => 'Square Font Awesome',
		'class' => 'fa-brands fa-square-font-awesome',
	],
	[
		'name'  => 'Square Font Awesome Stroke',
		'class' => 'fa-brands fa-square-font-awesome-stroke',
	],
	[
		'name'  => 'Square Full',
		'class' => 'fa-solid fa-square-full',
	],
	[
		'name'  => 'Square Git',
		'class' => 'fa-brands fa-square-git',
	],
	[
		'name'  => 'Square Github',
		'class' => 'fa-brands fa-square-github',
	],
	[
		'name'  => 'Square Gitlab',
		'class' => 'fa-brands fa-square-gitlab',
	],
	[
		'name'  => 'Square Google Plus',
		'class' => 'fa-brands fa-square-google-plus',
	],
	[
		'name'  => 'Square H',
		'class' => 'fa-solid fa-square-h',
	],
	[
		'name'  => 'Square Hacker News',
		'class' => 'fa-brands fa-square-hacker-news',
	],
	[
		'name'  => 'Square Instagram',
		'class' => 'fa-brands fa-square-instagram',
	],
	[
		'name'  => 'Square Js',
		'class' => 'fa-brands fa-square-js',
	],
	[
		'name'  => 'Square Lastfm',
		'class' => 'fa-brands fa-square-lastfm',
	],
	[
		'name'  => 'Square Letterboxd',
		'class' => 'fa-brands fa-square-letterboxd',
	],
	[
		'name'  => 'Square Minus',
		'class' => 'fa-solid fa-square-minus',
	],
	[
		'name'  => 'Square Nfi',
		'class' => 'fa-solid fa-square-nfi',
	],
	[
		'name'  => 'Square Odnoklassniki',
		'class' => 'fa-brands fa-square-odnoklassniki',
	],
	[
		'name'  => 'Square Parking',
		'class' => 'fa-solid fa-square-parking',
	],
	[
		'name'  => 'Square Pen',
		'class' => 'fa-solid fa-square-pen',
	],
	[
		'name'  => 'Square Person Confined',
		'class' => 'fa-solid fa-square-person-confined',
	],
	[
		'name'  => 'Square Phone',
		'class' => 'fa-solid fa-square-phone',
	],
	[
		'name'  => 'Square Phone Flip',
		'class' => 'fa-solid fa-square-phone-flip',
	],
	[
		'name'  => 'Pied Piper Square Logo (Old)',
		'class' => 'fa-brands fa-square-pied-piper',
	],
	[
		'name'  => 'Square Pinterest',
		'class' => 'fa-brands fa-square-pinterest',
	],
	[
		'name'  => 'Square Plus',
		'class' => 'fa-solid fa-square-plus',
	],
	[
		'name'  => 'Square Poll Horizontal',
		'class' => 'fa-solid fa-square-poll-horizontal',
	],
	[
		'name'  => 'Square Poll Vertical',
		'class' => 'fa-solid fa-square-poll-vertical',
	],
	[
		'name'  => 'Square Reddit',
		'class' => 'fa-brands fa-square-reddit',
	],
	[
		'name'  => 'Square Root Variable',
		'class' => 'fa-solid fa-square-root-variable',
	],
	[
		'name'  => 'Square Rss',
		'class' => 'fa-solid fa-square-rss',
	],
	[
		'name'  => 'Square Share Nodes',
		'class' => 'fa-solid fa-square-share-nodes',
	],
	[
		'name'  => 'Snapchat Square',
		'class' => 'fa-brands fa-square-snapchat',
	],
	[
		'name'  => 'Square Steam',
		'class' => 'fa-brands fa-square-steam',
	],
	[
		'name'  => 'Square Threads',
		'class' => 'fa-brands fa-square-threads',
	],
	[
		'name'  => 'Square Tumblr',
		'class' => 'fa-brands fa-square-tumblr',
	],
	[
		'name'  => 'Square Twitter',
		'class' => 'fa-brands fa-square-twitter',
	],
	[
		'name'  => 'Square Up Right',
		'class' => 'fa-solid fa-square-up-right',
	],
	[
		'name'  => 'Square Upwork',
		'class' => 'fa-brands fa-square-upwork',
	],
	[
		'name'  => 'Square Viadeo',
		'class' => 'fa-brands fa-square-viadeo',
	],
	[
		'name'  => 'Square Vimeo',
		'class' => 'fa-brands fa-square-vimeo',
	],
	[
		'name'  => 'Square Virus',
		'class' => 'fa-solid fa-square-virus',
	],
	[
		'name'  => 'Square Web Awesome',
		'class' => 'fa-brands fa-square-web-awesome',
	],
	[
		'name'  => 'Square Web Awesome Stroke',
		'class' => 'fa-brands fa-square-web-awesome-stroke',
	],
	[
		'name'  => 'Square Whatsapp',
		'class' => 'fa-brands fa-square-whatsapp',
	],
	[
		'name'  => 'Square X Twitter',
		'class' => 'fa-brands fa-square-x-twitter',
	],
	[
		'name'  => 'Square Xing',
		'class' => 'fa-brands fa-square-xing',
	],
	[
		'name'  => 'Square Xmark',
		'class' => 'fa-solid fa-square-xmark',
	],
	[
		'name'  => 'Square Youtube',
		'class' => 'fa-brands fa-square-youtube',
	],
	[
		'name'  => 'Squarespace',
		'class' => 'fa-brands fa-squarespace',
	],
	[
		'name'  => 'Stack Exchange',
		'class' => 'fa-brands fa-stack-exchange',
	],
	[
		'name'  => 'Stack Overflow',
		'class' => 'fa-brands fa-stack-overflow',
	],
	[
		'name'  => 'Stackpath',
		'class' => 'fa-brands fa-stackpath',
	],
	[
		'name'  => 'Staff Snake',
		'class' => 'fa-solid fa-staff-snake',
	],
	[
		'name'  => 'Stairs',
		'class' => 'fa-solid fa-stairs',
	],
	[
		'name'  => 'Stamp',
		'class' => 'fa-solid fa-stamp',
	],
	[
		'name'  => 'Stapler',
		'class' => 'fa-solid fa-stapler',
	],
	[
		'name'  => 'Star',
		'class' => 'fa-solid fa-star',
	],
	[
		'name'  => 'Star And Crescent',
		'class' => 'fa-solid fa-star-and-crescent',
	],
	[
		'name'  => 'Star Half',
		'class' => 'fa-solid fa-star-half',
	],
	[
		'name'  => 'Star Half Stroke',
		'class' => 'fa-solid fa-star-half-stroke',
	],
	[
		'name'  => 'Star Of David',
		'class' => 'fa-solid fa-star-of-david',
	],
	[
		'name'  => 'Star Of Life',
		'class' => 'fa-solid fa-star-of-life',
	],
	[
		'name'  => 'StayLinked',
		'class' => 'fa-brands fa-staylinked',
	],
	[
		'name'  => 'Steam',
		'class' => 'fa-brands fa-steam',
	],
	[
		'name'  => 'Steam Symbol',
		'class' => 'fa-brands fa-steam-symbol',
	],
	[
		'name'  => 'Sterling Sign',
		'class' => 'fa-solid fa-sterling-sign',
	],
	[
		'name'  => 'Stethoscope',
		'class' => 'fa-solid fa-stethoscope',
	],
	[
		'name'  => 'Sticker Mule',
		'class' => 'fa-brands fa-sticker-mule',
	],
	[
		'name'  => 'Stop',
		'class' => 'fa-solid fa-stop',
	],
	[
		'name'  => 'Stopwatch',
		'class' => 'fa-solid fa-stopwatch',
	],
	[
		'name'  => 'Stopwatch 20',
		'class' => 'fa-solid fa-stopwatch-20',
	],
	[
		'name'  => 'Store',
		'class' => 'fa-solid fa-store',
	],
	[
		'name'  => 'Store Slash',
		'class' => 'fa-solid fa-store-slash',
	],
	[
		'name'  => 'Strava',
		'class' => 'fa-brands fa-strava',
	],
	[
		'name'  => 'Street View',
		'class' => 'fa-solid fa-street-view',
	],
	[
		'name'  => 'Strikethrough',
		'class' => 'fa-solid fa-strikethrough',
	],
	[
		'name'  => 'Stripe',
		'class' => 'fa-brands fa-stripe',
	],
	[
		'name'  => 'Stripe S',
		'class' => 'fa-brands fa-stripe-s',
	],
	[
		'name'  => 'Stroopwafel',
		'class' => 'fa-solid fa-stroopwafel',
	],
	[
		'name'  => 'Stubber',
		'class' => 'fa-brands fa-stubber',
	],
	[
		'name'  => 'Studio Vinari',
		'class' => 'fa-brands fa-studiovinari',
	],
	[
		'name'  => 'StumbleUpon Logo',
		'class' => 'fa-brands fa-stumbleupon',
	],
	[
		'name'  => 'StumbleUpon Circle',
		'class' => 'fa-brands fa-stumbleupon-circle',
	],
	[
		'name'  => 'Subscript',
		'class' => 'fa-solid fa-subscript',
	],
	[
		'name'  => 'Suitcase',
		'class' => 'fa-solid fa-suitcase',
	],
	[
		'name'  => 'Suitcase Medical',
		'class' => 'fa-solid fa-suitcase-medical',
	],
	[
		'name'  => 'Suitcase Rolling',
		'class' => 'fa-solid fa-suitcase-rolling',
	],
	[
		'name'  => 'Sun',
		'class' => 'fa-solid fa-sun',
	],
	[
		'name'  => 'Sun Plant Wilt',
		'class' => 'fa-solid fa-sun-plant-wilt',
	],
	[
		'name'  => 'Superpowers',
		'class' => 'fa-brands fa-superpowers',
	],
	[
		'name'  => 'Superscript',
		'class' => 'fa-solid fa-superscript',
	],
	[
		'name'  => 'Supple',
		'class' => 'fa-brands fa-supple',
	],
	[
		'name'  => 'Suse',
		'class' => 'fa-brands fa-suse',
	],
	[
		'name'  => 'Swatchbook',
		'class' => 'fa-solid fa-swatchbook',
	],
	[
		'name'  => 'Swift',
		'class' => 'fa-brands fa-swift',
	],
	[
		'name'  => 'Symfony',
		'class' => 'fa-brands fa-symfony',
	],
	[
		'name'  => 'Synagogue',
		'class' => 'fa-solid fa-synagogue',
	],
	[
		'name'  => 'Syringe',
		'class' => 'fa-solid fa-syringe',
	],
	[
		'name'  => 'T',
		'class' => 'fa-solid fa-t',
	],
	[
		'name'  => 'Table',
		'class' => 'fa-solid fa-table',
	],
	[
		'name'  => 'Table Cells',
		'class' => 'fa-solid fa-table-cells',
	],
	[
		'name'  => 'Table Cells Column Lock',
		'class' => 'fa-solid fa-table-cells-column-lock',
	],
	[
		'name'  => 'Table Cells Large',
		'class' => 'fa-solid fa-table-cells-large',
	],
	[
		'name'  => 'Table Cells Row Lock',
		'class' => 'fa-solid fa-table-cells-row-lock',
	],
	[
		'name'  => 'Table Columns',
		'class' => 'fa-solid fa-table-columns',
	],
	[
		'name'  => 'Table List',
		'class' => 'fa-solid fa-table-list',
	],
	[
		'name'  => 'Table Tennis Paddle Ball',
		'class' => 'fa-solid fa-table-tennis-paddle-ball',
	],
	[
		'name'  => 'Tablet',
		'class' => 'fa-solid fa-tablet',
	],
	[
		'name'  => 'Tablet Button',
		'class' => 'fa-solid fa-tablet-button',
	],
	[
		'name'  => 'Tablet Screen Button',
		'class' => 'fa-solid fa-tablet-screen-button',
	],
	[
		'name'  => 'Tablets',
		'class' => 'fa-solid fa-tablets',
	],
	[
		'name'  => 'Tachograph Digital',
		'class' => 'fa-solid fa-tachograph-digital',
	],
	[
		'name'  => 'Tag',
		'class' => 'fa-solid fa-tag',
	],
	[
		'name'  => 'Tags',
		'class' => 'fa-solid fa-tags',
	],
	[
		'name'  => 'Tape',
		'class' => 'fa-solid fa-tape',
	],
	[
		'name'  => 'Tarp',
		'class' => 'fa-solid fa-tarp',
	],
	[
		'name'  => 'Tarp Droplet',
		'class' => 'fa-solid fa-tarp-droplet',
	],
	[
		'name'  => 'Taxi',
		'class' => 'fa-solid fa-taxi',
	],
	[
		'name'  => 'Teamspeak',
		'class' => 'fa-brands fa-teamspeak',
	],
	[
		'name'  => 'Teeth',
		'class' => 'fa-solid fa-teeth',
	],
	[
		'name'  => 'Teeth Open',
		'class' => 'fa-solid fa-teeth-open',
	],
	[
		'name'  => 'Telegram',
		'class' => 'fa-brands fa-telegram',
	],
	[
		'name'  => 'Temperature Arrow Down',
		'class' => 'fa-solid fa-temperature-arrow-down',
	],
	[
		'name'  => 'Temperature Arrow Up',
		'class' => 'fa-solid fa-temperature-arrow-up',
	],
	[
		'name'  => 'Temperature Empty',
		'class' => 'fa-solid fa-temperature-empty',
	],
	[
		'name'  => 'Temperature Full',
		'class' => 'fa-solid fa-temperature-full',
	],
	[
		'name'  => 'Temperature Half',
		'class' => 'fa-solid fa-temperature-half',
	],
	[
		'name'  => 'Temperature High',
		'class' => 'fa-solid fa-temperature-high',
	],
	[
		'name'  => 'Temperature Low',
		'class' => 'fa-solid fa-temperature-low',
	],
	[
		'name'  => 'Temperature Quarter',
		'class' => 'fa-solid fa-temperature-quarter',
	],
	[
		'name'  => 'Temperature Three Quarters',
		'class' => 'fa-solid fa-temperature-three-quarters',
	],
	[
		'name'  => 'Tencent Weibo',
		'class' => 'fa-brands fa-tencent-weibo',
	],
	[
		'name'  => 'Tenge Sign',
		'class' => 'fa-solid fa-tenge-sign',
	],
	[
		'name'  => 'Tent',
		'class' => 'fa-solid fa-tent',
	],
	[
		'name'  => 'Tent Arrow Down To Line',
		'class' => 'fa-solid fa-tent-arrow-down-to-line',
	],
	[
		'name'  => 'Tent Arrow Left Right',
		'class' => 'fa-solid fa-tent-arrow-left-right',
	],
	[
		'name'  => 'Tent Arrow Turn Left',
		'class' => 'fa-solid fa-tent-arrow-turn-left',
	],
	[
		'name'  => 'Tent Arrows Down',
		'class' => 'fa-solid fa-tent-arrows-down',
	],
	[
		'name'  => 'Tents',
		'class' => 'fa-solid fa-tents',
	],
	[
		'name'  => 'Terminal',
		'class' => 'fa-solid fa-terminal',
	],
	[
		'name'  => 'Text Height',
		'class' => 'fa-solid fa-text-height',
	],
	[
		'name'  => 'Text Slash',
		'class' => 'fa-solid fa-text-slash',
	],
	[
		'name'  => 'Text Width',
		'class' => 'fa-solid fa-text-width',
	],
	[
		'name'  => 'The Red Yeti',
		'class' => 'fa-brands fa-the-red-yeti',
	],
	[
		'name'  => 'Themeco',
		'class' => 'fa-brands fa-themeco',
	],
	[
		'name'  => 'ThemeIsle',
		'class' => 'fa-brands fa-themeisle',
	],
	[
		'name'  => 'Thermometer',
		'class' => 'fa-solid fa-thermometer',
	],
	[
		'name'  => 'Think Peaks',
		'class' => 'fa-brands fa-think-peaks',
	],
	[
		'name'  => 'Threads',
		'class' => 'fa-brands fa-threads',
	],
	[
		'name'  => 'Thumbs Down',
		'class' => 'fa-solid fa-thumbs-down',
	],
	[
		'name'  => 'Thumbs Up',
		'class' => 'fa-solid fa-thumbs-up',
	],
	[
		'name'  => 'Thumbtack',
		'class' => 'fa-solid fa-thumbtack',
	],
	[
		'name'  => 'Ticket',
		'class' => 'fa-solid fa-ticket',
	],
	[
		'name'  => 'Ticket Simple',
		'class' => 'fa-solid fa-ticket-simple',
	],
	[
		'name'  => 'TikTok',
		'class' => 'fa-brands fa-tiktok',
	],
	[
		'name'  => 'Timeline',
		'class' => 'fa-solid fa-timeline',
	],
	[
		'name'  => 'Toggle Off',
		'class' => 'fa-solid fa-toggle-off',
	],
	[
		'name'  => 'Toggle On',
		'class' => 'fa-solid fa-toggle-on',
	],
	[
		'name'  => 'Toilet',
		'class' => 'fa-solid fa-toilet',
	],
	[
		'name'  => 'Toilet Paper',
		'class' => 'fa-solid fa-toilet-paper',
	],
	[
		'name'  => 'Toilet Paper Slash',
		'class' => 'fa-solid fa-toilet-paper-slash',
	],
	[
		'name'  => 'Toilet Portable',
		'class' => 'fa-solid fa-toilet-portable',
	],
	[
		'name'  => 'Toilets Portable',
		'class' => 'fa-solid fa-toilets-portable',
	],
	[
		'name'  => 'Toolbox',
		'class' => 'fa-solid fa-toolbox',
	],
	[
		'name'  => 'Tooth',
		'class' => 'fa-solid fa-tooth',
	],
	[
		'name'  => 'Torii Gate',
		'class' => 'fa-solid fa-torii-gate',
	],
	[
		'name'  => 'Tornado',
		'class' => 'fa-solid fa-tornado',
	],
	[
		'name'  => 'Tower Broadcast',
		'class' => 'fa-solid fa-tower-broadcast',
	],
	[
		'name'  => 'Tower Cell',
		'class' => 'fa-solid fa-tower-cell',
	],
	[
		'name'  => 'Tower Observation',
		'class' => 'fa-solid fa-tower-observation',
	],
	[
		'name'  => 'Tractor',
		'class' => 'fa-solid fa-tractor',
	],
	[
		'name'  => 'Trade Federation',
		'class' => 'fa-brands fa-trade-federation',
	],
	[
		'name'  => 'Trademark',
		'class' => 'fa-solid fa-trademark',
	],
	[
		'name'  => 'Traffic Light',
		'class' => 'fa-solid fa-traffic-light',
	],
	[
		'name'  => 'Trailer',
		'class' => 'fa-solid fa-trailer',
	],
	[
		'name'  => 'Train',
		'class' => 'fa-solid fa-train',
	],
	[
		'name'  => 'Train Subway',
		'class' => 'fa-solid fa-train-subway',
	],
	[
		'name'  => 'Train Tram',
		'class' => 'fa-solid fa-train-tram',
	],
	[
		'name'  => 'Transgender',
		'class' => 'fa-solid fa-transgender',
	],
	[
		'name'  => 'Trash',
		'class' => 'fa-solid fa-trash',
	],
	[
		'name'  => 'Trash Arrow Up',
		'class' => 'fa-solid fa-trash-arrow-up',
	],
	[
		'name'  => 'Trash Can',
		'class' => 'fa-solid fa-trash-can',
	],
	[
		'name'  => 'Trash Can Arrow Up',
		'class' => 'fa-solid fa-trash-can-arrow-up',
	],
	[
		'name'  => 'Tree',
		'class' => 'fa-solid fa-tree',
	],
	[
		'name'  => 'Tree City',
		'class' => 'fa-solid fa-tree-city',
	],
	[
		'name'  => 'Trello',
		'class' => 'fa-brands fa-trello',
	],
	[
		'name'  => 'Triangle Exclamation',
		'class' => 'fa-solid fa-triangle-exclamation',
	],
	[
		'name'  => 'Trophy',
		'class' => 'fa-solid fa-trophy',
	],
	[
		'name'  => 'Trowel',
		'class' => 'fa-solid fa-trowel',
	],
	[
		'name'  => 'Trowel Bricks',
		'class' => 'fa-solid fa-trowel-bricks',
	],
	[
		'name'  => 'Truck',
		'class' => 'fa-solid fa-truck',
	],
	[
		'name'  => 'Truck Arrow Right',
		'class' => 'fa-solid fa-truck-arrow-right',
	],
	[
		'name'  => 'Truck Droplet',
		'class' => 'fa-solid fa-truck-droplet',
	],
	[
		'name'  => 'Truck Fast',
		'class' => 'fa-solid fa-truck-fast',
	],
	[
		'name'  => 'Truck Field',
		'class' => 'fa-solid fa-truck-field',
	],
	[
		'name'  => 'Truck Field Un',
		'class' => 'fa-solid fa-truck-field-un',
	],
	[
		'name'  => 'Truck Front',
		'class' => 'fa-solid fa-truck-front',
	],
	[
		'name'  => 'Truck Medical',
		'class' => 'fa-solid fa-truck-medical',
	],
	[
		'name'  => 'Truck Monster',
		'class' => 'fa-solid fa-truck-monster',
	],
	[
		'name'  => 'Truck Moving',
		'class' => 'fa-solid fa-truck-moving',
	],
	[
		'name'  => 'Truck Pickup',
		'class' => 'fa-solid fa-truck-pickup',
	],
	[
		'name'  => 'Truck Plane',
		'class' => 'fa-solid fa-truck-plane',
	],
	[
		'name'  => 'Truck Ramp Box',
		'class' => 'fa-solid fa-truck-ramp-box',
	],
	[
		'name'  => 'Tty',
		'class' => 'fa-solid fa-tty',
	],
	[
		'name'  => 'Tumblr',
		'class' => 'fa-brands fa-tumblr',
	],
	[
		'name'  => 'Turkish Lira Sign',
		'class' => 'fa-solid fa-turkish-lira-sign',
	],
	[
		'name'  => 'Turn Down',
		'class' => 'fa-solid fa-turn-down',
	],
	[
		'name'  => 'Turn Up',
		'class' => 'fa-solid fa-turn-up',
	],
	[
		'name'  => 'Tv',
		'class' => 'fa-solid fa-tv',
	],
	[
		'name'  => 'Twitch',
		'class' => 'fa-brands fa-twitch',
	],
	[
		'name'  => 'Twitter',
		'class' => 'fa-brands fa-twitter',
	],
	[
		'name'  => 'Typo3',
		'class' => 'fa-brands fa-typo3',
	],
	[
		'name'  => 'U',
		'class' => 'fa-solid fa-u',
	],
	[
		'name'  => 'Uber',
		'class' => 'fa-brands fa-uber',
	],
	[
		'name'  => 'Ubuntu',
		'class' => 'fa-brands fa-ubuntu',
	],
	[
		'name'  => 'UIkit',
		'class' => 'fa-brands fa-uikit',
	],
	[
		'name'  => 'Umbraco',
		'class' => 'fa-brands fa-umbraco',
	],
	[
		'name'  => 'Umbrella',
		'class' => 'fa-solid fa-umbrella',
	],
	[
		'name'  => 'Umbrella Beach',
		'class' => 'fa-solid fa-umbrella-beach',
	],
	[
		'name'  => 'Uncharted Software',
		'class' => 'fa-brands fa-uncharted',
	],
	[
		'name'  => 'Underline',
		'class' => 'fa-solid fa-underline',
	],
	[
		'name'  => 'Uniregistry',
		'class' => 'fa-brands fa-uniregistry',
	],
	[
		'name'  => 'Unity 3D',
		'class' => 'fa-brands fa-unity',
	],
	[
		'name'  => 'Universal Access',
		'class' => 'fa-solid fa-universal-access',
	],
	[
		'name'  => 'Unlock',
		'class' => 'fa-solid fa-unlock',
	],
	[
		'name'  => 'Unlock Keyhole',
		'class' => 'fa-solid fa-unlock-keyhole',
	],
	[
		'name'  => 'Unsplash',
		'class' => 'fa-brands fa-unsplash',
	],
	[
		'name'  => 'Untappd',
		'class' => 'fa-brands fa-untappd',
	],
	[
		'name'  => 'Up Down',
		'class' => 'fa-solid fa-up-down',
	],
	[
		'name'  => 'Up Down Left Right',
		'class' => 'fa-solid fa-up-down-left-right',
	],
	[
		'name'  => 'Up Long',
		'class' => 'fa-solid fa-up-long',
	],
	[
		'name'  => 'Up Right And Down Left From Center',
		'class' => 'fa-solid fa-up-right-and-down-left-from-center',
	],
	[
		'name'  => 'Up Right From Square',
		'class' => 'fa-solid fa-up-right-from-square',
	],
	[
		'name'  => 'Upload',
		'class' => 'fa-solid fa-upload',
	],
	[
		'name'  => 'UPS',
		'class' => 'fa-brands fa-ups',
	],
	[
		'name'  => 'Upwork',
		'class' => 'fa-brands fa-upwork',
	],
	[
		'name'  => 'USB',
		'class' => 'fa-brands fa-usb',
	],
	[
		'name'  => 'User',
		'class' => 'fa-solid fa-user',
	],
	[
		'name'  => 'User Astronaut',
		'class' => 'fa-solid fa-user-astronaut',
	],
	[
		'name'  => 'User Check',
		'class' => 'fa-solid fa-user-check',
	],
	[
		'name'  => 'User Clock',
		'class' => 'fa-solid fa-user-clock',
	],
	[
		'name'  => 'User Doctor',
		'class' => 'fa-solid fa-user-doctor',
	],
	[
		'name'  => 'User Gear',
		'class' => 'fa-solid fa-user-gear',
	],
	[
		'name'  => 'User Graduate',
		'class' => 'fa-solid fa-user-graduate',
	],
	[
		'name'  => 'User Group',
		'class' => 'fa-solid fa-user-group',
	],
	[
		'name'  => 'User Injured',
		'class' => 'fa-solid fa-user-injured',
	],
	[
		'name'  => 'User Large',
		'class' => 'fa-solid fa-user-large',
	],
	[
		'name'  => 'User Large Slash',
		'class' => 'fa-solid fa-user-large-slash',
	],
	[
		'name'  => 'User Lock',
		'class' => 'fa-solid fa-user-lock',
	],
	[
		'name'  => 'User Minus',
		'class' => 'fa-solid fa-user-minus',
	],
	[
		'name'  => 'User Ninja',
		'class' => 'fa-solid fa-user-ninja',
	],
	[
		'name'  => 'User Nurse',
		'class' => 'fa-solid fa-user-nurse',
	],
	[
		'name'  => 'User Pen',
		'class' => 'fa-solid fa-user-pen',
	],
	[
		'name'  => 'User Plus',
		'class' => 'fa-solid fa-user-plus',
	],
	[
		'name'  => 'User Secret',
		'class' => 'fa-solid fa-user-secret',
	],
	[
		'name'  => 'User Shield',
		'class' => 'fa-solid fa-user-shield',
	],
	[
		'name'  => 'User Slash',
		'class' => 'fa-solid fa-user-slash',
	],
	[
		'name'  => 'User Tag',
		'class' => 'fa-solid fa-user-tag',
	],
	[
		'name'  => 'User Tie',
		'class' => 'fa-solid fa-user-tie',
	],
	[
		'name'  => 'User Xmark',
		'class' => 'fa-solid fa-user-xmark',
	],
	[
		'name'  => 'Users',
		'class' => 'fa-solid fa-users',
	],
	[
		'name'  => 'Users Between Lines',
		'class' => 'fa-solid fa-users-between-lines',
	],
	[
		'name'  => 'Users Gear',
		'class' => 'fa-solid fa-users-gear',
	],
	[
		'name'  => 'Users Line',
		'class' => 'fa-solid fa-users-line',
	],
	[
		'name'  => 'Users Rays',
		'class' => 'fa-solid fa-users-rays',
	],
	[
		'name'  => 'Users Rectangle',
		'class' => 'fa-solid fa-users-rectangle',
	],
	[
		'name'  => 'Users Slash',
		'class' => 'fa-solid fa-users-slash',
	],
	[
		'name'  => 'Users Viewfinder',
		'class' => 'fa-solid fa-users-viewfinder',
	],
	[
		'name'  => 'United States Postal Service',
		'class' => 'fa-brands fa-usps',
	],
	[
		'name'  => 'us-Sunnah Foundation',
		'class' => 'fa-brands fa-ussunnah',
	],
	[
		'name'  => 'Utensils',
		'class' => 'fa-solid fa-utensils',
	],
	[
		'name'  => 'V',
		'class' => 'fa-solid fa-v',
	],
	[
		'name'  => 'Vaadin',
		'class' => 'fa-brands fa-vaadin',
	],
	[
		'name'  => 'Van Shuttle',
		'class' => 'fa-solid fa-van-shuttle',
	],
	[
		'name'  => 'Vault',
		'class' => 'fa-solid fa-vault',
	],
	[
		'name'  => 'Vector Square',
		'class' => 'fa-solid fa-vector-square',
	],
	[
		'name'  => 'Venus',
		'class' => 'fa-solid fa-venus',
	],
	[
		'name'  => 'Venus Double',
		'class' => 'fa-solid fa-venus-double',
	],
	[
		'name'  => 'Venus Mars',
		'class' => 'fa-solid fa-venus-mars',
	],
	[
		'name'  => 'Vest',
		'class' => 'fa-solid fa-vest',
	],
	[
		'name'  => 'Vest Patches',
		'class' => 'fa-solid fa-vest-patches',
	],
	[
		'name'  => 'Viacoin',
		'class' => 'fa-brands fa-viacoin',
	],
	[
		'name'  => 'Viadeo',
		'class' => 'fa-brands fa-viadeo',
	],
	[
		'name'  => 'Vial',
		'class' => 'fa-solid fa-vial',
	],
	[
		'name'  => 'Vial Circle Check',
		'class' => 'fa-solid fa-vial-circle-check',
	],
	[
		'name'  => 'Vial Virus',
		'class' => 'fa-solid fa-vial-virus',
	],
	[
		'name'  => 'Vials',
		'class' => 'fa-solid fa-vials',
	],
	[
		'name'  => 'Viber',
		'class' => 'fa-brands fa-viber',
	],
	[
		'name'  => 'Video',
		'class' => 'fa-solid fa-video',
	],
	[
		'name'  => 'Video Slash',
		'class' => 'fa-solid fa-video-slash',
	],
	[
		'name'  => 'Vihara',
		'class' => 'fa-solid fa-vihara',
	],
	[
		'name'  => 'Vimeo',
		'class' => 'fa-brands fa-vimeo',
	],
	[
		'name'  => 'Vimeo',
		'class' => 'fa-brands fa-vimeo-v',
	],
	[
		'name'  => 'Vine',
		'class' => 'fa-brands fa-vine',
	],
	[
		'name'  => 'Virus',
		'class' => 'fa-solid fa-virus',
	],
	[
		'name'  => 'Virus Covid',
		'class' => 'fa-solid fa-virus-covid',
	],
	[
		'name'  => 'Virus Covid Slash',
		'class' => 'fa-solid fa-virus-covid-slash',
	],
	[
		'name'  => 'Virus Slash',
		'class' => 'fa-solid fa-virus-slash',
	],
	[
		'name'  => 'Viruses',
		'class' => 'fa-solid fa-viruses',
	],
	[
		'name'  => 'VK',
		'class' => 'fa-brands fa-vk',
	],
	[
		'name'  => 'VNV',
		'class' => 'fa-brands fa-vnv',
	],
	[
		'name'  => 'Voicemail',
		'class' => 'fa-solid fa-voicemail',
	],
	[
		'name'  => 'Volcano',
		'class' => 'fa-solid fa-volcano',
	],
	[
		'name'  => 'Volleyball',
		'class' => 'fa-solid fa-volleyball',
	],
	[
		'name'  => 'Volume High',
		'class' => 'fa-solid fa-volume-high',
	],
	[
		'name'  => 'Volume Low',
		'class' => 'fa-solid fa-volume-low',
	],
	[
		'name'  => 'Volume Off',
		'class' => 'fa-solid fa-volume-off',
	],
	[
		'name'  => 'Volume Xmark',
		'class' => 'fa-solid fa-volume-xmark',
	],
	[
		'name'  => 'Vr Cardboard',
		'class' => 'fa-solid fa-vr-cardboard',
	],
	[
		'name'  => 'Vue.js',
		'class' => 'fa-brands fa-vuejs',
	],
	[
		'name'  => 'W',
		'class' => 'fa-solid fa-w',
	],
	[
		'name'  => 'Walkie Talkie',
		'class' => 'fa-solid fa-walkie-talkie',
	],
	[
		'name'  => 'Wallet',
		'class' => 'fa-solid fa-wallet',
	],
	[
		'name'  => 'Wand Magic',
		'class' => 'fa-solid fa-wand-magic',
	],
	[
		'name'  => 'Wand Magic Sparkles',
		'class' => 'fa-solid fa-wand-magic-sparkles',
	],
	[
		'name'  => 'Wand Sparkles',
		'class' => 'fa-solid fa-wand-sparkles',
	],
	[
		'name'  => 'Warehouse',
		'class' => 'fa-solid fa-warehouse',
	],
	[
		'name'  => 'Watchman Monitoring',
		'class' => 'fa-brands fa-watchman-monitoring',
	],
	[
		'name'  => 'Water',
		'class' => 'fa-solid fa-water',
	],
	[
		'name'  => 'Water Ladder',
		'class' => 'fa-solid fa-water-ladder',
	],
	[
		'name'  => 'Wave Square',
		'class' => 'fa-solid fa-wave-square',
	],
	[
		'name'  => 'Waze',
		'class' => 'fa-brands fa-waze',
	],
	[
		'name'  => 'Web Awesome',
		'class' => 'fa-brands fa-web-awesome',
	],
	[
		'name'  => 'Webflow',
		'class' => 'fa-brands fa-webflow',
	],
	[
		'name'  => 'Weebly',
		'class' => 'fa-brands fa-weebly',
	],
	[
		'name'  => 'Weibo',
		'class' => 'fa-brands fa-weibo',
	],
	[
		'name'  => 'Weight Hanging',
		'class' => 'fa-solid fa-weight-hanging',
	],
	[
		'name'  => 'Weight Scale',
		'class' => 'fa-solid fa-weight-scale',
	],
	[
		'name'  => 'Weixin (WeChat)',
		'class' => 'fa-brands fa-weixin',
	],
	[
		'name'  => 'What\'s App',
		'class' => 'fa-brands fa-whatsapp',
	],
	[
		'name'  => 'Wheat Awn',
		'class' => 'fa-solid fa-wheat-awn',
	],
	[
		'name'  => 'Wheat Awn Circle Exclamation',
		'class' => 'fa-solid fa-wheat-awn-circle-exclamation',
	],
	[
		'name'  => 'Wheelchair',
		'class' => 'fa-solid fa-wheelchair',
	],
	[
		'name'  => 'Wheelchair Move',
		'class' => 'fa-solid fa-wheelchair-move',
	],
	[
		'name'  => 'Whiskey Glass',
		'class' => 'fa-solid fa-whiskey-glass',
	],
	[
		'name'  => 'WHMCS',
		'class' => 'fa-brands fa-whmcs',
	],
	[
		'name'  => 'Wifi',
		'class' => 'fa-solid fa-wifi',
	],
	[
		'name'  => 'Wikipedia W',
		'class' => 'fa-brands fa-wikipedia-w',
	],
	[
		'name'  => 'Wind',
		'class' => 'fa-solid fa-wind',
	],
	[
		'name'  => 'Window Maximize',
		'class' => 'fa-solid fa-window-maximize',
	],
	[
		'name'  => 'Window Minimize',
		'class' => 'fa-solid fa-window-minimize',
	],
	[
		'name'  => 'Window Restore',
		'class' => 'fa-solid fa-window-restore',
	],
	[
		'name'  => 'Windows',
		'class' => 'fa-brands fa-windows',
	],
	[
		'name'  => 'Wine Bottle',
		'class' => 'fa-solid fa-wine-bottle',
	],
	[
		'name'  => 'Wine Glass',
		'class' => 'fa-solid fa-wine-glass',
	],
	[
		'name'  => 'Wine Glass Empty',
		'class' => 'fa-solid fa-wine-glass-empty',
	],
	[
		'name'  => 'wirsindhandwerk',
		'class' => 'fa-brands fa-wirsindhandwerk',
	],
	[
		'name'  => 'Wix',
		'class' => 'fa-brands fa-wix',
	],
	[
		'name'  => 'Wizards of the Coast',
		'class' => 'fa-brands fa-wizards-of-the-coast',
	],
	[
		'name'  => 'Wodu',
		'class' => 'fa-brands fa-wodu',
	],
	[
		'name'  => 'Wolf Pack Battalion',
		'class' => 'fa-brands fa-wolf-pack-battalion',
	],
	[
		'name'  => 'Won Sign',
		'class' => 'fa-solid fa-won-sign',
	],
	[
		'name'  => 'WordPress Logo',
		'class' => 'fa-brands fa-wordpress',
	],
	[
		'name'  => 'Wordpress Simple',
		'class' => 'fa-brands fa-wordpress-simple',
	],
	[
		'name'  => 'Worm',
		'class' => 'fa-solid fa-worm',
	],
	[
		'name'  => 'WPBeginner',
		'class' => 'fa-brands fa-wpbeginner',
	],
	[
		'name'  => 'WPExplorer',
		'class' => 'fa-brands fa-wpexplorer',
	],
	[
		'name'  => 'WPForms',
		'class' => 'fa-brands fa-wpforms',
	],
	[
		'name'  => 'wpressr',
		'class' => 'fa-brands fa-wpressr',
	],
	[
		'name'  => 'Wrench',
		'class' => 'fa-solid fa-wrench',
	],
	[
		'name'  => 'X',
		'class' => 'fa-solid fa-x',
	],
	[
		'name'  => 'X Ray',
		'class' => 'fa-solid fa-x-ray',
	],
	[
		'name'  => 'X Twitter',
		'class' => 'fa-brands fa-x-twitter',
	],
	[
		'name'  => 'Xbox',
		'class' => 'fa-brands fa-xbox',
	],
	[
		'name'  => 'Xing',
		'class' => 'fa-brands fa-xing',
	],
	[
		'name'  => 'Xmark',
		'class' => 'fa-solid fa-xmark',
	],
	[
		'name'  => 'Xmarks Lines',
		'class' => 'fa-solid fa-xmarks-lines',
	],
	[
		'name'  => 'Y',
		'class' => 'fa-solid fa-y',
	],
	[
		'name'  => 'Y Combinator',
		'class' => 'fa-brands fa-y-combinator',
	],
	[
		'name'  => 'Yahoo Logo',
		'class' => 'fa-brands fa-yahoo',
	],
	[
		'name'  => 'Yammer',
		'class' => 'fa-brands fa-yammer',
	],
	[
		'name'  => 'Yandex',
		'class' => 'fa-brands fa-yandex',
	],
	[
		'name'  => 'Yandex International',
		'class' => 'fa-brands fa-yandex-international',
	],
	[
		'name'  => 'Yarn',
		'class' => 'fa-brands fa-yarn',
	],
	[
		'name'  => 'Yelp',
		'class' => 'fa-brands fa-yelp',
	],
	[
		'name'  => 'Yen Sign',
		'class' => 'fa-solid fa-yen-sign',
	],
	[
		'name'  => 'Yin Yang',
		'class' => 'fa-solid fa-yin-yang',
	],
	[
		'name'  => 'Yoast',
		'class' => 'fa-brands fa-yoast',
	],
	[
		'name'  => 'YouTube',
		'class' => 'fa-brands fa-youtube',
	],
	[
		'name'  => 'Z',
		'class' => 'fa-solid fa-z',
	],
	[
		'name'  => 'Zhihu',
		'class' => 'fa-brands fa-zhihu',
	],
];
