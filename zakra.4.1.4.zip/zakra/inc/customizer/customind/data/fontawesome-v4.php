<?php return [
	[
		'name'  => 'Glass',
		'class' => 'fa fa-glass',
	],
	[
		'name'  => 'Music',
		'class' => 'fa fa-music',
	],
	[
		'name'  => 'Search',
		'class' => 'fa fa-search',
	],
	[
		'name'  => 'Envelope Outlined',
		'class' => 'fa fa-envelope-o',
	],
	[
		'name'  => 'Heart',
		'class' => 'fa fa-heart',
	],
	[
		'name'  => 'Star',
		'class' => 'fa fa-star',
	],
	[
		'name'  => 'Star Outlined',
		'class' => 'fa fa-star-o',
	],
	[
		'name'  => 'User',
		'class' => 'fa fa-user',
	],
	[
		'name'  => 'Film',
		'class' => 'fa fa-film',
	],
	[
		'name'  => 'th-large',
		'class' => 'fa fa-th-large',
	],
	[
		'name'  => 'th',
		'class' => 'fa fa-th',
	],
	[
		'name'  => 'th-list',
		'class' => 'fa fa-th-list',
	],
	[
		'name'  => 'Check',
		'class' => 'fa fa-check',
	],
	[
		'name'  => 'Times',
		'class' => 'fa fa-times',
	],
	[
		'name'  => 'Search Plus',
		'class' => 'fa fa-search-plus',
	],
	[
		'name'  => 'Search Minus',
		'class' => 'fa fa-search-minus',
	],
	[
		'name'  => 'Power Off',
		'class' => 'fa fa-power-off',
	],
	[
		'name'  => 'signal',
		'class' => 'fa fa-signal',
	],
	[
		'name'  => 'cog',
		'class' => 'fa fa-cog',
	],
	[
		'name'  => 'Trash Outlined',
		'class' => 'fa fa-trash-o',
	],
	[
		'name'  => 'home',
		'class' => 'fa fa-home',
	],
	[
		'name'  => 'File Outlined',
		'class' => 'fa fa-file-o',
	],
	[
		'name'  => 'Clock Outlined',
		'class' => 'fa fa-clock-o',
	],
	[
		'name'  => 'road',
		'class' => 'fa fa-road',
	],
	[
		'name'  => 'Download',
		'class' => 'fa fa-download',
	],
	[
		'name'  => 'Arrow Circle Outlined Down',
		'class' => 'fa fa-arrow-circle-o-down',
	],
	[
		'name'  => 'Arrow Circle Outlined Up',
		'class' => 'fa fa-arrow-circle-o-up',
	],
	[
		'name'  => 'inbox',
		'class' => 'fa fa-inbox',
	],
	[
		'name'  => 'Play Circle Outlined',
		'class' => 'fa fa-play-circle-o',
	],
	[
		'name'  => 'Repeat',
		'class' => 'fa fa-repeat',
	],
	[
		'name'  => 'refresh',
		'class' => 'fa fa-refresh',
	],
	[
		'name'  => 'list-alt',
		'class' => 'fa fa-list-alt',
	],
	[
		'name'  => 'lock',
		'class' => 'fa fa-lock',
	],
	[
		'name'  => 'flag',
		'class' => 'fa fa-flag',
	],
	[
		'name'  => 'headphones',
		'class' => 'fa fa-headphones',
	],
	[
		'name'  => 'volume-off',
		'class' => 'fa fa-volume-off',
	],
	[
		'name'  => 'volume-down',
		'class' => 'fa fa-volume-down',
	],
	[
		'name'  => 'volume-up',
		'class' => 'fa fa-volume-up',
	],
	[
		'name'  => 'qrcode',
		'class' => 'fa fa-qrcode',
	],
	[
		'name'  => 'barcode',
		'class' => 'fa fa-barcode',
	],
	[
		'name'  => 'tag',
		'class' => 'fa fa-tag',
	],
	[
		'name'  => 'tags',
		'class' => 'fa fa-tags',
	],
	[
		'name'  => 'book',
		'class' => 'fa fa-book',
	],
	[
		'name'  => 'bookmark',
		'class' => 'fa fa-bookmark',
	],
	[
		'name'  => 'print',
		'class' => 'fa fa-print',
	],
	[
		'name'  => 'camera',
		'class' => 'fa fa-camera',
	],
	[
		'name'  => 'font',
		'class' => 'fa fa-font',
	],
	[
		'name'  => 'bold',
		'class' => 'fa fa-bold',
	],
	[
		'name'  => 'italic',
		'class' => 'fa fa-italic',
	],
	[
		'name'  => 'text-height',
		'class' => 'fa fa-text-height',
	],
	[
		'name'  => 'text-width',
		'class' => 'fa fa-text-width',
	],
	[
		'name'  => 'align-left',
		'class' => 'fa fa-align-left',
	],
	[
		'name'  => 'align-center',
		'class' => 'fa fa-align-center',
	],
	[
		'name'  => 'align-right',
		'class' => 'fa fa-align-right',
	],
	[
		'name'  => 'align-justify',
		'class' => 'fa fa-align-justify',
	],
	[
		'name'  => 'list',
		'class' => 'fa fa-list',
	],
	[
		'name'  => 'Outdent',
		'class' => 'fa fa-outdent',
	],
	[
		'name'  => 'Indent',
		'class' => 'fa fa-indent',
	],
	[
		'name'  => 'Video Camera',
		'class' => 'fa fa-video-camera',
	],
	[
		'name'  => 'Picture Outlined',
		'class' => 'fa fa-picture-o',
	],
	[
		'name'  => 'pencil',
		'class' => 'fa fa-pencil',
	],
	[
		'name'  => 'map-marker',
		'class' => 'fa fa-map-marker',
	],
	[
		'name'  => 'adjust',
		'class' => 'fa fa-adjust',
	],
	[
		'name'  => 'tint',
		'class' => 'fa fa-tint',
	],
	[
		'name'  => 'Pencil Square Outlined',
		'class' => 'fa fa-pencil-square-o',
	],
	[
		'name'  => 'Share Square Outlined',
		'class' => 'fa fa-share-square-o',
	],
	[
		'name'  => 'Check Square Outlined',
		'class' => 'fa fa-check-square-o',
	],
	[
		'name'  => 'Arrows',
		'class' => 'fa fa-arrows',
	],
	[
		'name'  => 'step-backward',
		'class' => 'fa fa-step-backward',
	],
	[
		'name'  => 'fast-backward',
		'class' => 'fa fa-fast-backward',
	],
	[
		'name'  => 'backward',
		'class' => 'fa fa-backward',
	],
	[
		'name'  => 'play',
		'class' => 'fa fa-play',
	],
	[
		'name'  => 'pause',
		'class' => 'fa fa-pause',
	],
	[
		'name'  => 'stop',
		'class' => 'fa fa-stop',
	],
	[
		'name'  => 'forward',
		'class' => 'fa fa-forward',
	],
	[
		'name'  => 'fast-forward',
		'class' => 'fa fa-fast-forward',
	],
	[
		'name'  => 'step-forward',
		'class' => 'fa fa-step-forward',
	],
	[
		'name'  => 'eject',
		'class' => 'fa fa-eject',
	],
	[
		'name'  => 'chevron-left',
		'class' => 'fa fa-chevron-left',
	],
	[
		'name'  => 'chevron-right',
		'class' => 'fa fa-chevron-right',
	],
	[
		'name'  => 'Plus Circle',
		'class' => 'fa fa-plus-circle',
	],
	[
		'name'  => 'Minus Circle',
		'class' => 'fa fa-minus-circle',
	],
	[
		'name'  => 'Times Circle',
		'class' => 'fa fa-times-circle',
	],
	[
		'name'  => 'Check Circle',
		'class' => 'fa fa-check-circle',
	],
	[
		'name'  => 'Question Circle',
		'class' => 'fa fa-question-circle',
	],
	[
		'name'  => 'Info Circle',
		'class' => 'fa fa-info-circle',
	],
	[
		'name'  => 'Crosshairs',
		'class' => 'fa fa-crosshairs',
	],
	[
		'name'  => 'Times Circle Outlined',
		'class' => 'fa fa-times-circle-o',
	],
	[
		'name'  => 'Check Circle Outlined',
		'class' => 'fa fa-check-circle-o',
	],
	[
		'name'  => 'ban',
		'class' => 'fa fa-ban',
	],
	[
		'name'  => 'arrow-left',
		'class' => 'fa fa-arrow-left',
	],
	[
		'name'  => 'arrow-right',
		'class' => 'fa fa-arrow-right',
	],
	[
		'name'  => 'arrow-up',
		'class' => 'fa fa-arrow-up',
	],
	[
		'name'  => 'arrow-down',
		'class' => 'fa fa-arrow-down',
	],
	[
		'name'  => 'Share',
		'class' => 'fa fa-share',
	],
	[
		'name'  => 'Expand',
		'class' => 'fa fa-expand',
	],
	[
		'name'  => 'Compress',
		'class' => 'fa fa-compress',
	],
	[
		'name'  => 'plus',
		'class' => 'fa fa-plus',
	],
	[
		'name'  => 'minus',
		'class' => 'fa fa-minus',
	],
	[
		'name'  => 'asterisk',
		'class' => 'fa fa-asterisk',
	],
	[
		'name'  => 'Exclamation Circle',
		'class' => 'fa fa-exclamation-circle',
	],
	[
		'name'  => 'gift',
		'class' => 'fa fa-gift',
	],
	[
		'name'  => 'leaf',
		'class' => 'fa fa-leaf',
	],
	[
		'name'  => 'fire',
		'class' => 'fa fa-fire',
	],
	[
		'name'  => 'Eye',
		'class' => 'fa fa-eye',
	],
	[
		'name'  => 'Eye Slash',
		'class' => 'fa fa-eye-slash',
	],
	[
		'name'  => 'Exclamation Triangle',
		'class' => 'fa fa-exclamation-triangle',
	],
	[
		'name'  => 'plane',
		'class' => 'fa fa-plane',
	],
	[
		'name'  => 'calendar',
		'class' => 'fa fa-calendar',
	],
	[
		'name'  => 'random',
		'class' => 'fa fa-random',
	],
	[
		'name'  => 'comment',
		'class' => 'fa fa-comment',
	],
	[
		'name'  => 'magnet',
		'class' => 'fa fa-magnet',
	],
	[
		'name'  => 'chevron-up',
		'class' => 'fa fa-chevron-up',
	],
	[
		'name'  => 'chevron-down',
		'class' => 'fa fa-chevron-down',
	],
	[
		'name'  => 'retweet',
		'class' => 'fa fa-retweet',
	],
	[
		'name'  => 'shopping-cart',
		'class' => 'fa fa-shopping-cart',
	],
	[
		'name'  => 'Folder',
		'class' => 'fa fa-folder',
	],
	[
		'name'  => 'Folder Open',
		'class' => 'fa fa-folder-open',
	],
	[
		'name'  => 'Arrows Vertical',
		'class' => 'fa fa-arrows-v',
	],
	[
		'name'  => 'Arrows Horizontal',
		'class' => 'fa fa-arrows-h',
	],
	[
		'name'  => 'Bar Chart',
		'class' => 'fa fa-bar-chart',
	],
	[
		'name'  => 'Twitter Square',
		'class' => 'fa fa-twitter-square',
	],
	[
		'name'  => 'Facebook Square',
		'class' => 'fa fa-facebook-square',
	],
	[
		'name'  => 'camera-retro',
		'class' => 'fa fa-camera-retro',
	],
	[
		'name'  => 'key',
		'class' => 'fa fa-key',
	],
	[
		'name'  => 'cogs',
		'class' => 'fa fa-cogs',
	],
	[
		'name'  => 'comments',
		'class' => 'fa fa-comments',
	],
	[
		'name'  => 'Thumbs Up Outlined',
		'class' => 'fa fa-thumbs-o-up',
	],
	[
		'name'  => 'Thumbs Down Outlined',
		'class' => 'fa fa-thumbs-o-down',
	],
	[
		'name'  => 'star-half',
		'class' => 'fa fa-star-half',
	],
	[
		'name'  => 'Heart Outlined',
		'class' => 'fa fa-heart-o',
	],
	[
		'name'  => 'Sign Out',
		'class' => 'fa fa-sign-out',
	],
	[
		'name'  => 'LinkedIn Square',
		'class' => 'fa fa-linkedin-square',
	],
	[
		'name'  => 'Thumb Tack',
		'class' => 'fa fa-thumb-tack',
	],
	[
		'name'  => 'External Link',
		'class' => 'fa fa-external-link',
	],
	[
		'name'  => 'Sign In',
		'class' => 'fa fa-sign-in',
	],
	[
		'name'  => 'trophy',
		'class' => 'fa fa-trophy',
	],
	[
		'name'  => 'GitHub Square',
		'class' => 'fa fa-github-square',
	],
	[
		'name'  => 'Upload',
		'class' => 'fa fa-upload',
	],
	[
		'name'  => 'Lemon Outlined',
		'class' => 'fa fa-lemon-o',
	],
	[
		'name'  => 'Phone',
		'class' => 'fa fa-phone',
	],
	[
		'name'  => 'Square Outlined',
		'class' => 'fa fa-square-o',
	],
	[
		'name'  => 'Bookmark Outlined',
		'class' => 'fa fa-bookmark-o',
	],
	[
		'name'  => 'Phone Square',
		'class' => 'fa fa-phone-square',
	],
	[
		'name'  => 'Twitter',
		'class' => 'fa fa-twitter',
	],
	[
		'name'  => 'Facebook',
		'class' => 'fa fa-facebook',
	],
	[
		'name'  => 'GitHub',
		'class' => 'fa fa-github',
	],
	[
		'name'  => 'unlock',
		'class' => 'fa fa-unlock',
	],
	[
		'name'  => 'credit-card',
		'class' => 'fa fa-credit-card',
	],
	[
		'name'  => 'rss',
		'class' => 'fa fa-rss',
	],
	[
		'name'  => 'HDD',
		'class' => 'fa fa-hdd-o',
	],
	[
		'name'  => 'bullhorn',
		'class' => 'fa fa-bullhorn',
	],
	[
		'name'  => 'bell',
		'class' => 'fa fa-bell',
	],
	[
		'name'  => 'certificate',
		'class' => 'fa fa-certificate',
	],
	[
		'name'  => 'Hand Outlined Right',
		'class' => 'fa fa-hand-o-right',
	],
	[
		'name'  => 'Hand Outlined Left',
		'class' => 'fa fa-hand-o-left',
	],
	[
		'name'  => 'Hand Outlined Up',
		'class' => 'fa fa-hand-o-up',
	],
	[
		'name'  => 'Hand Outlined Down',
		'class' => 'fa fa-hand-o-down',
	],
	[
		'name'  => 'Arrow Circle Left',
		'class' => 'fa fa-arrow-circle-left',
	],
	[
		'name'  => 'Arrow Circle Right',
		'class' => 'fa fa-arrow-circle-right',
	],
	[
		'name'  => 'Arrow Circle Up',
		'class' => 'fa fa-arrow-circle-up',
	],
	[
		'name'  => 'Arrow Circle Down',
		'class' => 'fa fa-arrow-circle-down',
	],
	[
		'name'  => 'Globe',
		'class' => 'fa fa-globe',
	],
	[
		'name'  => 'Wrench',
		'class' => 'fa fa-wrench',
	],
	[
		'name'  => 'Tasks',
		'class' => 'fa fa-tasks',
	],
	[
		'name'  => 'Filter',
		'class' => 'fa fa-filter',
	],
	[
		'name'  => 'Briefcase',
		'class' => 'fa fa-briefcase',
	],
	[
		'name'  => 'Arrows Alt',
		'class' => 'fa fa-arrows-alt',
	],
	[
		'name'  => 'Users',
		'class' => 'fa fa-users',
	],
	[
		'name'  => 'Link',
		'class' => 'fa fa-link',
	],
	[
		'name'  => 'Cloud',
		'class' => 'fa fa-cloud',
	],
	[
		'name'  => 'Flask',
		'class' => 'fa fa-flask',
	],
	[
		'name'  => 'Scissors',
		'class' => 'fa fa-scissors',
	],
	[
		'name'  => 'Files Outlined',
		'class' => 'fa fa-files-o',
	],
	[
		'name'  => 'Paperclip',
		'class' => 'fa fa-paperclip',
	],
	[
		'name'  => 'Floppy Outlined',
		'class' => 'fa fa-floppy-o',
	],
	[
		'name'  => 'Square',
		'class' => 'fa fa-square',
	],
	[
		'name'  => 'Bars',
		'class' => 'fa fa-bars',
	],
	[
		'name'  => 'list-ul',
		'class' => 'fa fa-list-ul',
	],
	[
		'name'  => 'list-ol',
		'class' => 'fa fa-list-ol',
	],
	[
		'name'  => 'Strikethrough',
		'class' => 'fa fa-strikethrough',
	],
	[
		'name'  => 'Underline',
		'class' => 'fa fa-underline',
	],
	[
		'name'  => 'table',
		'class' => 'fa fa-table',
	],
	[
		'name'  => 'magic',
		'class' => 'fa fa-magic',
	],
	[
		'name'  => 'truck',
		'class' => 'fa fa-truck',
	],
	[
		'name'  => 'Pinterest',
		'class' => 'fa fa-pinterest',
	],
	[
		'name'  => 'Pinterest Square',
		'class' => 'fa fa-pinterest-square',
	],
	[
		'name'  => 'Google Plus Square',
		'class' => 'fa fa-google-plus-square',
	],
	[
		'name'  => 'Google Plus',
		'class' => 'fa fa-google-plus',
	],
	[
		'name'  => 'Money',
		'class' => 'fa fa-money',
	],
	[
		'name'  => 'Caret Down',
		'class' => 'fa fa-caret-down',
	],
	[
		'name'  => 'Caret Up',
		'class' => 'fa fa-caret-up',
	],
	[
		'name'  => 'Caret Left',
		'class' => 'fa fa-caret-left',
	],
	[
		'name'  => 'Caret Right',
		'class' => 'fa fa-caret-right',
	],
	[
		'name'  => 'Columns',
		'class' => 'fa fa-columns',
	],
	[
		'name'  => 'Sort',
		'class' => 'fa fa-sort',
	],
	[
		'name'  => 'Sort Descending',
		'class' => 'fa fa-sort-desc',
	],
	[
		'name'  => 'Sort Ascending',
		'class' => 'fa fa-sort-asc',
	],
	[
		'name'  => 'Envelope',
		'class' => 'fa fa-envelope',
	],
	[
		'name'  => 'LinkedIn',
		'class' => 'fa fa-linkedin',
	],
	[
		'name'  => 'Undo',
		'class' => 'fa fa-undo',
	],
	[
		'name'  => 'Gavel',
		'class' => 'fa fa-gavel',
	],
	[
		'name'  => 'Tachometer',
		'class' => 'fa fa-tachometer',
	],
	[
		'name'  => 'comment-o',
		'class' => 'fa fa-comment-o',
	],
	[
		'name'  => 'comments-o',
		'class' => 'fa fa-comments-o',
	],
	[
		'name'  => 'Lightning Bolt',
		'class' => 'fa fa-bolt',
	],
	[
		'name'  => 'Sitemap',
		'class' => 'fa fa-sitemap',
	],
	[
		'name'  => 'Umbrella',
		'class' => 'fa fa-umbrella',
	],
	[
		'name'  => 'Clipboard',
		'class' => 'fa fa-clipboard',
	],
	[
		'name'  => 'Lightbulb Outlined',
		'class' => 'fa fa-lightbulb-o',
	],
	[
		'name'  => 'Exchange',
		'class' => 'fa fa-exchange',
	],
	[
		'name'  => 'Cloud Download',
		'class' => 'fa fa-cloud-download',
	],
	[
		'name'  => 'Cloud Upload',
		'class' => 'fa fa-cloud-upload',
	],
	[
		'name'  => 'user-md',
		'class' => 'fa fa-user-md',
	],
	[
		'name'  => 'Stethoscope',
		'class' => 'fa fa-stethoscope',
	],
	[
		'name'  => 'Suitcase',
		'class' => 'fa fa-suitcase',
	],
	[
		'name'  => 'Bell Outlined',
		'class' => 'fa fa-bell-o',
	],
	[
		'name'  => 'Coffee',
		'class' => 'fa fa-coffee',
	],
	[
		'name'  => 'Cutlery',
		'class' => 'fa fa-cutlery',
	],
	[
		'name'  => 'File Text Outlined',
		'class' => 'fa fa-file-text-o',
	],
	[
		'name'  => 'Building Outlined',
		'class' => 'fa fa-building-o',
	],
	[
		'name'  => 'hospital Outlined',
		'class' => 'fa fa-hospital-o',
	],
	[
		'name'  => 'ambulance',
		'class' => 'fa fa-ambulance',
	],
	[
		'name'  => 'medkit',
		'class' => 'fa fa-medkit',
	],
	[
		'name'  => 'fighter-jet',
		'class' => 'fa fa-fighter-jet',
	],
	[
		'name'  => 'beer',
		'class' => 'fa fa-beer',
	],
	[
		'name'  => 'H Square',
		'class' => 'fa fa-h-square',
	],
	[
		'name'  => 'Plus Square',
		'class' => 'fa fa-plus-square',
	],
	[
		'name'  => 'Angle Double Left',
		'class' => 'fa fa-angle-double-left',
	],
	[
		'name'  => 'Angle Double Right',
		'class' => 'fa fa-angle-double-right',
	],
	[
		'name'  => 'Angle Double Up',
		'class' => 'fa fa-angle-double-up',
	],
	[
		'name'  => 'Angle Double Down',
		'class' => 'fa fa-angle-double-down',
	],
	[
		'name'  => 'angle-left',
		'class' => 'fa fa-angle-left',
	],
	[
		'name'  => 'angle-right',
		'class' => 'fa fa-angle-right',
	],
	[
		'name'  => 'angle-up',
		'class' => 'fa fa-angle-up',
	],
	[
		'name'  => 'angle-down',
		'class' => 'fa fa-angle-down',
	],
	[
		'name'  => 'Desktop',
		'class' => 'fa fa-desktop',
	],
	[
		'name'  => 'Laptop',
		'class' => 'fa fa-laptop',
	],
	[
		'name'  => 'tablet',
		'class' => 'fa fa-tablet',
	],
	[
		'name'  => 'Mobile Phone',
		'class' => 'fa fa-mobile',
	],
	[
		'name'  => 'Circle Outlined',
		'class' => 'fa fa-circle-o',
	],
	[
		'name'  => 'quote-left',
		'class' => 'fa fa-quote-left',
	],
	[
		'name'  => 'quote-right',
		'class' => 'fa fa-quote-right',
	],
	[
		'name'  => 'Spinner',
		'class' => 'fa fa-spinner',
	],
	[
		'name'  => 'Circle',
		'class' => 'fa fa-circle',
	],
	[
		'name'  => 'Reply',
		'class' => 'fa fa-reply',
	],
	[
		'name'  => 'GitHub Alt',
		'class' => 'fa fa-github-alt',
	],
	[
		'name'  => 'Folder Outlined',
		'class' => 'fa fa-folder-o',
	],
	[
		'name'  => 'Folder Open Outlined',
		'class' => 'fa fa-folder-open-o',
	],
	[
		'name'  => 'Smile Outlined',
		'class' => 'fa fa-smile-o',
	],
	[
		'name'  => 'Frown Outlined',
		'class' => 'fa fa-frown-o',
	],
	[
		'name'  => 'Meh Outlined',
		'class' => 'fa fa-meh-o',
	],
	[
		'name'  => 'Gamepad',
		'class' => 'fa fa-gamepad',
	],
	[
		'name'  => 'Keyboard Outlined',
		'class' => 'fa fa-keyboard-o',
	],
	[
		'name'  => 'Flag Outlined',
		'class' => 'fa fa-flag-o',
	],
	[
		'name'  => 'flag-checkered',
		'class' => 'fa fa-flag-checkered',
	],
	[
		'name'  => 'Terminal',
		'class' => 'fa fa-terminal',
	],
	[
		'name'  => 'Code',
		'class' => 'fa fa-code',
	],
	[
		'name'  => 'reply-all',
		'class' => 'fa fa-reply-all',
	],
	[
		'name'  => 'Star Half Outlined',
		'class' => 'fa fa-star-half-o',
	],
	[
		'name'  => 'location-arrow',
		'class' => 'fa fa-location-arrow',
	],
	[
		'name'  => 'crop',
		'class' => 'fa fa-crop',
	],
	[
		'name'  => 'code-fork',
		'class' => 'fa fa-code-fork',
	],
	[
		'name'  => 'Chain Broken',
		'class' => 'fa fa-chain-broken',
	],
	[
		'name'  => 'Question',
		'class' => 'fa fa-question',
	],
	[
		'name'  => 'Info',
		'class' => 'fa fa-info',
	],
	[
		'name'  => 'exclamation',
		'class' => 'fa fa-exclamation',
	],
	[
		'name'  => 'superscript',
		'class' => 'fa fa-superscript',
	],
	[
		'name'  => 'subscript',
		'class' => 'fa fa-subscript',
	],
	[
		'name'  => 'eraser',
		'class' => 'fa fa-eraser',
	],
	[
		'name'  => 'Puzzle Piece',
		'class' => 'fa fa-puzzle-piece',
	],
	[
		'name'  => 'microphone',
		'class' => 'fa fa-microphone',
	],
	[
		'name'  => 'Microphone Slash',
		'class' => 'fa fa-microphone-slash',
	],
	[
		'name'  => 'shield',
		'class' => 'fa fa-shield',
	],
	[
		'name'  => 'calendar-o',
		'class' => 'fa fa-calendar-o',
	],
	[
		'name'  => 'fire-extinguisher',
		'class' => 'fa fa-fire-extinguisher',
	],
	[
		'name'  => 'rocket',
		'class' => 'fa fa-rocket',
	],
	[
		'name'  => 'MaxCDN',
		'class' => 'fa fa-maxcdn',
	],
	[
		'name'  => 'Chevron Circle Left',
		'class' => 'fa fa-chevron-circle-left',
	],
	[
		'name'  => 'Chevron Circle Right',
		'class' => 'fa fa-chevron-circle-right',
	],
	[
		'name'  => 'Chevron Circle Up',
		'class' => 'fa fa-chevron-circle-up',
	],
	[
		'name'  => 'Chevron Circle Down',
		'class' => 'fa fa-chevron-circle-down',
	],
	[
		'name'  => 'HTML 5 Logo',
		'class' => 'fa fa-html5',
	],
	[
		'name'  => 'CSS 3 Logo',
		'class' => 'fa fa-css3',
	],
	[
		'name'  => 'Anchor',
		'class' => 'fa fa-anchor',
	],
	[
		'name'  => 'Unlock Alt',
		'class' => 'fa fa-unlock-alt',
	],
	[
		'name'  => 'Bullseye',
		'class' => 'fa fa-bullseye',
	],
	[
		'name'  => 'Ellipsis Horizontal',
		'class' => 'fa fa-ellipsis-h',
	],
	[
		'name'  => 'Ellipsis Vertical',
		'class' => 'fa fa-ellipsis-v',
	],
	[
		'name'  => 'RSS Square',
		'class' => 'fa fa-rss-square',
	],
	[
		'name'  => 'Play Circle',
		'class' => 'fa fa-play-circle',
	],
	[
		'name'  => 'Ticket',
		'class' => 'fa fa-ticket',
	],
	[
		'name'  => 'Minus Square',
		'class' => 'fa fa-minus-square',
	],
	[
		'name'  => 'Minus Square Outlined',
		'class' => 'fa fa-minus-square-o',
	],
	[
		'name'  => 'Level Up',
		'class' => 'fa fa-level-up',
	],
	[
		'name'  => 'Level Down',
		'class' => 'fa fa-level-down',
	],
	[
		'name'  => 'Check Square',
		'class' => 'fa fa-check-square',
	],
	[
		'name'  => 'Pencil Square',
		'class' => 'fa fa-pencil-square',
	],
	[
		'name'  => 'External Link Square',
		'class' => 'fa fa-external-link-square',
	],
	[
		'name'  => 'Share Square',
		'class' => 'fa fa-share-square',
	],
	[
		'name'  => 'Compass',
		'class' => 'fa fa-compass',
	],
	[
		'name'  => 'Caret Square Outlined Down',
		'class' => 'fa fa-caret-square-o-down',
	],
	[
		'name'  => 'Caret Square Outlined Up',
		'class' => 'fa fa-caret-square-o-up',
	],
	[
		'name'  => 'Caret Square Outlined Right',
		'class' => 'fa fa-caret-square-o-right',
	],
	[
		'name'  => 'Euro (EUR)',
		'class' => 'fa fa-eur',
	],
	[
		'name'  => 'GBP',
		'class' => 'fa fa-gbp',
	],
	[
		'name'  => 'US Dollar',
		'class' => 'fa fa-usd',
	],
	[
		'name'  => 'Indian Rupee (INR)',
		'class' => 'fa fa-inr',
	],
	[
		'name'  => 'Japanese Yen (JPY)',
		'class' => 'fa fa-jpy',
	],
	[
		'name'  => 'Russian Ruble (RUB)',
		'class' => 'fa fa-rub',
	],
	[
		'name'  => 'Korean Won (KRW)',
		'class' => 'fa fa-krw',
	],
	[
		'name'  => 'Bitcoin (BTC)',
		'class' => 'fa fa-btc',
	],
	[
		'name'  => 'File',
		'class' => 'fa fa-file',
	],
	[
		'name'  => 'File Text',
		'class' => 'fa fa-file-text',
	],
	[
		'name'  => 'Sort Alpha Ascending',
		'class' => 'fa fa-sort-alpha-asc',
	],
	[
		'name'  => 'Sort Alpha Descending',
		'class' => 'fa fa-sort-alpha-desc',
	],
	[
		'name'  => 'Sort Amount Ascending',
		'class' => 'fa fa-sort-amount-asc',
	],
	[
		'name'  => 'Sort Amount Descending',
		'class' => 'fa fa-sort-amount-desc',
	],
	[
		'name'  => 'Sort Numeric Ascending',
		'class' => 'fa fa-sort-numeric-asc',
	],
	[
		'name'  => 'Sort Numeric Descending',
		'class' => 'fa fa-sort-numeric-desc',
	],
	[
		'name'  => 'thumbs-up',
		'class' => 'fa fa-thumbs-up',
	],
	[
		'name'  => 'thumbs-down',
		'class' => 'fa fa-thumbs-down',
	],
	[
		'name'  => 'YouTube Square',
		'class' => 'fa fa-youtube-square',
	],
	[
		'name'  => 'YouTube',
		'class' => 'fa fa-youtube',
	],
	[
		'name'  => 'Xing',
		'class' => 'fa fa-xing',
	],
	[
		'name'  => 'Xing Square',
		'class' => 'fa fa-xing-square',
	],
	[
		'name'  => 'YouTube Play',
		'class' => 'fa fa-youtube-play',
	],
	[
		'name'  => 'Dropbox',
		'class' => 'fa fa-dropbox',
	],
	[
		'name'  => 'Stack Overflow',
		'class' => 'fa fa-stack-overflow',
	],
	[
		'name'  => 'Instagram',
		'class' => 'fa fa-instagram',
	],
	[
		'name'  => 'Flickr',
		'class' => 'fa fa-flickr',
	],
	[
		'name'  => 'App.net',
		'class' => 'fa fa-adn',
	],
	[
		'name'  => 'Bitbucket',
		'class' => 'fa fa-bitbucket',
	],
	[
		'name'  => 'Bitbucket Square',
		'class' => 'fa fa-bitbucket-square',
	],
	[
		'name'  => 'Tumblr',
		'class' => 'fa fa-tumblr',
	],
	[
		'name'  => 'Tumblr Square',
		'class' => 'fa fa-tumblr-square',
	],
	[
		'name'  => 'Long Arrow Down',
		'class' => 'fa fa-long-arrow-down',
	],
	[
		'name'  => 'Long Arrow Up',
		'class' => 'fa fa-long-arrow-up',
	],
	[
		'name'  => 'Long Arrow Left',
		'class' => 'fa fa-long-arrow-left',
	],
	[
		'name'  => 'Long Arrow Right',
		'class' => 'fa fa-long-arrow-right',
	],
	[
		'name'  => 'Apple',
		'class' => 'fa fa-apple',
	],
	[
		'name'  => 'Windows',
		'class' => 'fa fa-windows',
	],
	[
		'name'  => 'Android',
		'class' => 'fa fa-android',
	],
	[
		'name'  => 'Linux',
		'class' => 'fa fa-linux',
	],
	[
		'name'  => 'Dribbble',
		'class' => 'fa fa-dribbble',
	],
	[
		'name'  => 'Skype',
		'class' => 'fa fa-skype',
	],
	[
		'name'  => 'Foursquare',
		'class' => 'fa fa-foursquare',
	],
	[
		'name'  => 'Trello',
		'class' => 'fa fa-trello',
	],
	[
		'name'  => 'Female',
		'class' => 'fa fa-female',
	],
	[
		'name'  => 'Male',
		'class' => 'fa fa-male',
	],
	[
		'name'  => 'Gratipay (Gittip)',
		'class' => 'fa fa-gratipay',
	],
	[
		'name'  => 'Sun Outlined',
		'class' => 'fa fa-sun-o',
	],
	[
		'name'  => 'Moon Outlined',
		'class' => 'fa fa-moon-o',
	],
	[
		'name'  => 'Archive',
		'class' => 'fa fa-archive',
	],
	[
		'name'  => 'Bug',
		'class' => 'fa fa-bug',
	],
	[
		'name'  => 'VK',
		'class' => 'fa fa-vk',
	],
	[
		'name'  => 'Weibo',
		'class' => 'fa fa-weibo',
	],
	[
		'name'  => 'Renren',
		'class' => 'fa fa-renren',
	],
	[
		'name'  => 'Pagelines',
		'class' => 'fa fa-pagelines',
	],
	[
		'name'  => 'Stack Exchange',
		'class' => 'fa fa-stack-exchange',
	],
	[
		'name'  => 'Arrow Circle Outlined Right',
		'class' => 'fa fa-arrow-circle-o-right',
	],
	[
		'name'  => 'Arrow Circle Outlined Left',
		'class' => 'fa fa-arrow-circle-o-left',
	],
	[
		'name'  => 'Caret Square Outlined Left',
		'class' => 'fa fa-caret-square-o-left',
	],
	[
		'name'  => 'Dot Circle Outlined',
		'class' => 'fa fa-dot-circle-o',
	],
	[
		'name'  => 'Wheelchair',
		'class' => 'fa fa-wheelchair',
	],
	[
		'name'  => 'Vimeo Square',
		'class' => 'fa fa-vimeo-square',
	],
	[
		'name'  => 'Turkish Lira (TRY)',
		'class' => 'fa fa-try',
	],
	[
		'name'  => 'Plus Square Outlined',
		'class' => 'fa fa-plus-square-o',
	],
	[
		'name'  => 'Space Shuttle',
		'class' => 'fa fa-space-shuttle',
	],
	[
		'name'  => 'Slack Logo',
		'class' => 'fa fa-slack',
	],
	[
		'name'  => 'Envelope Square',
		'class' => 'fa fa-envelope-square',
	],
	[
		'name'  => 'WordPress Logo',
		'class' => 'fa fa-wordpress',
	],
	[
		'name'  => 'OpenID',
		'class' => 'fa fa-openid',
	],
	[
		'name'  => 'University',
		'class' => 'fa fa-university',
	],
	[
		'name'  => 'Graduation Cap',
		'class' => 'fa fa-graduation-cap',
	],
	[
		'name'  => 'Yahoo Logo',
		'class' => 'fa fa-yahoo',
	],
	[
		'name'  => 'Google Logo',
		'class' => 'fa fa-google',
	],
	[
		'name'  => 'reddit Logo',
		'class' => 'fa fa-reddit',
	],
	[
		'name'  => 'reddit Square',
		'class' => 'fa fa-reddit-square',
	],
	[
		'name'  => 'StumbleUpon Circle',
		'class' => 'fa fa-stumbleupon-circle',
	],
	[
		'name'  => 'StumbleUpon Logo',
		'class' => 'fa fa-stumbleupon',
	],
	[
		'name'  => 'Delicious Logo',
		'class' => 'fa fa-delicious',
	],
	[
		'name'  => 'Digg Logo',
		'class' => 'fa fa-digg',
	],
	[
		'name'  => 'Pied Piper PP Logo (Old)',
		'class' => 'fa fa-pied-piper-pp',
	],
	[
		'name'  => 'Pied Piper Alternate Logo',
		'class' => 'fa fa-pied-piper-alt',
	],
	[
		'name'  => 'Drupal Logo',
		'class' => 'fa fa-drupal',
	],
	[
		'name'  => 'Joomla Logo',
		'class' => 'fa fa-joomla',
	],
	[
		'name'  => 'Language',
		'class' => 'fa fa-language',
	],
	[
		'name'  => 'Fax',
		'class' => 'fa fa-fax',
	],
	[
		'name'  => 'Building',
		'class' => 'fa fa-building',
	],
	[
		'name'  => 'Child',
		'class' => 'fa fa-child',
	],
	[
		'name'  => 'Paw',
		'class' => 'fa fa-paw',
	],
	[
		'name'  => 'spoon',
		'class' => 'fa fa-spoon',
	],
	[
		'name'  => 'Cube',
		'class' => 'fa fa-cube',
	],
	[
		'name'  => 'Cubes',
		'class' => 'fa fa-cubes',
	],
	[
		'name'  => 'Behance',
		'class' => 'fa fa-behance',
	],
	[
		'name'  => 'Behance Square',
		'class' => 'fa fa-behance-square',
	],
	[
		'name'  => 'Steam',
		'class' => 'fa fa-steam',
	],
	[
		'name'  => 'Steam Square',
		'class' => 'fa fa-steam-square',
	],
	[
		'name'  => 'Recycle',
		'class' => 'fa fa-recycle',
	],
	[
		'name'  => 'Car',
		'class' => 'fa fa-car',
	],
	[
		'name'  => 'Taxi',
		'class' => 'fa fa-taxi',
	],
	[
		'name'  => 'Tree',
		'class' => 'fa fa-tree',
	],
	[
		'name'  => 'Spotify',
		'class' => 'fa fa-spotify',
	],
	[
		'name'  => 'deviantART',
		'class' => 'fa fa-deviantart',
	],
	[
		'name'  => 'SoundCloud',
		'class' => 'fa fa-soundcloud',
	],
	[
		'name'  => 'Database',
		'class' => 'fa fa-database',
	],
	[
		'name'  => 'PDF File Outlined',
		'class' => 'fa fa-file-pdf-o',
	],
	[
		'name'  => 'Word File Outlined',
		'class' => 'fa fa-file-word-o',
	],
	[
		'name'  => 'Excel File Outlined',
		'class' => 'fa fa-file-excel-o',
	],
	[
		'name'  => 'Powerpoint File Outlined',
		'class' => 'fa fa-file-powerpoint-o',
	],
	[
		'name'  => 'Image File Outlined',
		'class' => 'fa fa-file-image-o',
	],
	[
		'name'  => 'Archive File Outlined',
		'class' => 'fa fa-file-archive-o',
	],
	[
		'name'  => 'Audio File Outlined',
		'class' => 'fa fa-file-audio-o',
	],
	[
		'name'  => 'Video File Outlined',
		'class' => 'fa fa-file-video-o',
	],
	[
		'name'  => 'Code File Outlined',
		'class' => 'fa fa-file-code-o',
	],
	[
		'name'  => 'Vine',
		'class' => 'fa fa-vine',
	],
	[
		'name'  => 'Codepen',
		'class' => 'fa fa-codepen',
	],
	[
		'name'  => 'jsFiddle',
		'class' => 'fa fa-jsfiddle',
	],
	[
		'name'  => 'Life Ring',
		'class' => 'fa fa-life-ring',
	],
	[
		'name'  => 'Circle Outlined Notched',
		'class' => 'fa fa-circle-o-notch',
	],
	[
		'name'  => 'Rebel Alliance',
		'class' => 'fa fa-rebel',
	],
	[
		'name'  => 'Galactic Empire',
		'class' => 'fa fa-empire',
	],
	[
		'name'  => 'Git Square',
		'class' => 'fa fa-git-square',
	],
	[
		'name'  => 'Git',
		'class' => 'fa fa-git',
	],
	[
		'name'  => 'Hacker News',
		'class' => 'fa fa-hacker-news',
	],
	[
		'name'  => 'Tencent Weibo',
		'class' => 'fa fa-tencent-weibo',
	],
	[
		'name'  => 'QQ',
		'class' => 'fa fa-qq',
	],
	[
		'name'  => 'Weixin (WeChat)',
		'class' => 'fa fa-weixin',
	],
	[
		'name'  => 'Paper Plane',
		'class' => 'fa fa-paper-plane',
	],
	[
		'name'  => 'Paper Plane Outlined',
		'class' => 'fa fa-paper-plane-o',
	],
	[
		'name'  => 'History',
		'class' => 'fa fa-history',
	],
	[
		'name'  => 'Circle Outlined Thin',
		'class' => 'fa fa-circle-thin',
	],
	[
		'name'  => 'header',
		'class' => 'fa fa-header',
	],
	[
		'name'  => 'paragraph',
		'class' => 'fa fa-paragraph',
	],
	[
		'name'  => 'Sliders',
		'class' => 'fa fa-sliders',
	],
	[
		'name'  => 'Share Alt',
		'class' => 'fa fa-share-alt',
	],
	[
		'name'  => 'Share Alt Square',
		'class' => 'fa fa-share-alt-square',
	],
	[
		'name'  => 'Bomb',
		'class' => 'fa fa-bomb',
	],
	[
		'name'  => 'Futbol Outlined',
		'class' => 'fa fa-futbol-o',
	],
	[
		'name'  => 'TTY',
		'class' => 'fa fa-tty',
	],
	[
		'name'  => 'Binoculars',
		'class' => 'fa fa-binoculars',
	],
	[
		'name'  => 'Plug',
		'class' => 'fa fa-plug',
	],
	[
		'name'  => 'Slideshare',
		'class' => 'fa fa-slideshare',
	],
	[
		'name'  => 'Twitch',
		'class' => 'fa fa-twitch',
	],
	[
		'name'  => 'Yelp',
		'class' => 'fa fa-yelp',
	],
	[
		'name'  => 'Newspaper Outlined',
		'class' => 'fa fa-newspaper-o',
	],
	[
		'name'  => 'WiFi',
		'class' => 'fa fa-wifi',
	],
	[
		'name'  => 'Calculator',
		'class' => 'fa fa-calculator',
	],
	[
		'name'  => 'Paypal',
		'class' => 'fa fa-paypal',
	],
	[
		'name'  => 'Google Wallet',
		'class' => 'fa fa-google-wallet',
	],
	[
		'name'  => 'Visa Credit Card',
		'class' => 'fa fa-cc-visa',
	],
	[
		'name'  => 'MasterCard Credit Card',
		'class' => 'fa fa-cc-mastercard',
	],
	[
		'name'  => 'Discover Credit Card',
		'class' => 'fa fa-cc-discover',
	],
	[
		'name'  => 'American Express Credit Card',
		'class' => 'fa fa-cc-amex',
	],
	[
		'name'  => 'Paypal Credit Card',
		'class' => 'fa fa-cc-paypal',
	],
	[
		'name'  => 'Stripe Credit Card',
		'class' => 'fa fa-cc-stripe',
	],
	[
		'name'  => 'Bell Slash',
		'class' => 'fa fa-bell-slash',
	],
	[
		'name'  => 'Bell Slash Outlined',
		'class' => 'fa fa-bell-slash-o',
	],
	[
		'name'  => 'Trash',
		'class' => 'fa fa-trash',
	],
	[
		'name'  => 'Copyright',
		'class' => 'fa fa-copyright',
	],
	[
		'name'  => 'At',
		'class' => 'fa fa-at',
	],
	[
		'name'  => 'Eyedropper',
		'class' => 'fa fa-eyedropper',
	],
	[
		'name'  => 'Paint Brush',
		'class' => 'fa fa-paint-brush',
	],
	[
		'name'  => 'Birthday Cake',
		'class' => 'fa fa-birthday-cake',
	],
	[
		'name'  => 'Area Chart',
		'class' => 'fa fa-area-chart',
	],
	[
		'name'  => 'Pie Chart',
		'class' => 'fa fa-pie-chart',
	],
	[
		'name'  => 'Line Chart',
		'class' => 'fa fa-line-chart',
	],
	[
		'name'  => 'last.fm',
		'class' => 'fa fa-lastfm',
	],
	[
		'name'  => 'last.fm Square',
		'class' => 'fa fa-lastfm-square',
	],
	[
		'name'  => 'Toggle Off',
		'class' => 'fa fa-toggle-off',
	],
	[
		'name'  => 'Toggle On',
		'class' => 'fa fa-toggle-on',
	],
	[
		'name'  => 'Bicycle',
		'class' => 'fa fa-bicycle',
	],
	[
		'name'  => 'Bus',
		'class' => 'fa fa-bus',
	],
	[
		'name'  => 'ioxhost',
		'class' => 'fa fa-ioxhost',
	],
	[
		'name'  => 'AngelList',
		'class' => 'fa fa-angellist',
	],
	[
		'name'  => 'Closed Captions',
		'class' => 'fa fa-cc',
	],
	[
		'name'  => 'Shekel (ILS)',
		'class' => 'fa fa-ils',
	],
	[
		'name'  => 'meanpath',
		'class' => 'fa fa-meanpath',
	],
	[
		'name'  => 'BuySellAds',
		'class' => 'fa fa-buysellads',
	],
	[
		'name'  => 'Connect Develop',
		'class' => 'fa fa-connectdevelop',
	],
	[
		'name'  => 'DashCube',
		'class' => 'fa fa-dashcube',
	],
	[
		'name'  => 'Forumbee',
		'class' => 'fa fa-forumbee',
	],
	[
		'name'  => 'Leanpub',
		'class' => 'fa fa-leanpub',
	],
	[
		'name'  => 'Sellsy',
		'class' => 'fa fa-sellsy',
	],
	[
		'name'  => 'Shirts in Bulk',
		'class' => 'fa fa-shirtsinbulk',
	],
	[
		'name'  => 'SimplyBuilt',
		'class' => 'fa fa-simplybuilt',
	],
	[
		'name'  => 'skyatlas',
		'class' => 'fa fa-skyatlas',
	],
	[
		'name'  => 'Add to Shopping Cart',
		'class' => 'fa fa-cart-plus',
	],
	[
		'name'  => 'Shopping Cart Arrow Down',
		'class' => 'fa fa-cart-arrow-down',
	],
	[
		'name'  => 'Diamond',
		'class' => 'fa fa-diamond',
	],
	[
		'name'  => 'Ship',
		'class' => 'fa fa-ship',
	],
	[
		'name'  => 'User Secret',
		'class' => 'fa fa-user-secret',
	],
	[
		'name'  => 'Motorcycle',
		'class' => 'fa fa-motorcycle',
	],
	[
		'name'  => 'Street View',
		'class' => 'fa fa-street-view',
	],
	[
		'name'  => 'Heartbeat',
		'class' => 'fa fa-heartbeat',
	],
	[
		'name'  => 'Venus',
		'class' => 'fa fa-venus',
	],
	[
		'name'  => 'Mars',
		'class' => 'fa fa-mars',
	],
	[
		'name'  => 'Mercury',
		'class' => 'fa fa-mercury',
	],
	[
		'name'  => 'Transgender',
		'class' => 'fa fa-transgender',
	],
	[
		'name'  => 'Transgender Alt',
		'class' => 'fa fa-transgender-alt',
	],
	[
		'name'  => 'Venus Double',
		'class' => 'fa fa-venus-double',
	],
	[
		'name'  => 'Mars Double',
		'class' => 'fa fa-mars-double',
	],
	[
		'name'  => 'Venus Mars',
		'class' => 'fa fa-venus-mars',
	],
	[
		'name'  => 'Mars Stroke',
		'class' => 'fa fa-mars-stroke',
	],
	[
		'name'  => 'Mars Stroke Vertical',
		'class' => 'fa fa-mars-stroke-v',
	],
	[
		'name'  => 'Mars Stroke Horizontal',
		'class' => 'fa fa-mars-stroke-h',
	],
	[
		'name'  => 'Neuter',
		'class' => 'fa fa-neuter',
	],
	[
		'name'  => 'Genderless',
		'class' => 'fa fa-genderless',
	],
	[
		'name'  => 'Facebook Official',
		'class' => 'fa fa-facebook-official',
	],
	[
		'name'  => 'Pinterest P',
		'class' => 'fa fa-pinterest-p',
	],
	[
		'name'  => 'What\'s App',
		'class' => 'fa fa-whatsapp',
	],
	[
		'name'  => 'Server',
		'class' => 'fa fa-server',
	],
	[
		'name'  => 'Add User',
		'class' => 'fa fa-user-plus',
	],
	[
		'name'  => 'Remove User',
		'class' => 'fa fa-user-times',
	],
	[
		'name'  => 'Bed',
		'class' => 'fa fa-bed',
	],
	[
		'name'  => 'Viacoin (VIA)',
		'class' => 'fa fa-viacoin',
	],
	[
		'name'  => 'Train',
		'class' => 'fa fa-train',
	],
	[
		'name'  => 'Subway',
		'class' => 'fa fa-subway',
	],
	[
		'name'  => 'Medium',
		'class' => 'fa fa-medium',
	],
	[
		'name'  => 'Y Combinator',
		'class' => 'fa fa-y-combinator',
	],
	[
		'name'  => 'Optin Monster',
		'class' => 'fa fa-optin-monster',
	],
	[
		'name'  => 'OpenCart',
		'class' => 'fa fa-opencart',
	],
	[
		'name'  => 'ExpeditedSSL',
		'class' => 'fa fa-expeditedssl',
	],
	[
		'name'  => 'Battery Full',
		'class' => 'fa fa-battery-full',
	],
	[
		'name'  => 'Battery 3/4 Full',
		'class' => 'fa fa-battery-three-quarters',
	],
	[
		'name'  => 'Battery 1/2 Full',
		'class' => 'fa fa-battery-half',
	],
	[
		'name'  => 'Battery 1/4 Full',
		'class' => 'fa fa-battery-quarter',
	],
	[
		'name'  => 'Battery Empty',
		'class' => 'fa fa-battery-empty',
	],
	[
		'name'  => 'Mouse Pointer',
		'class' => 'fa fa-mouse-pointer',
	],
	[
		'name'  => 'I Beam Cursor',
		'class' => 'fa fa-i-cursor',
	],
	[
		'name'  => 'Object Group',
		'class' => 'fa fa-object-group',
	],
	[
		'name'  => 'Object Ungroup',
		'class' => 'fa fa-object-ungroup',
	],
	[
		'name'  => 'Sticky Note',
		'class' => 'fa fa-sticky-note',
	],
	[
		'name'  => 'Sticky Note Outlined',
		'class' => 'fa fa-sticky-note-o',
	],
	[
		'name'  => 'JCB Credit Card',
		'class' => 'fa fa-cc-jcb',
	],
	[
		'name'  => 'Diner\'s Club Credit Card',
		'class' => 'fa fa-cc-diners-club',
	],
	[
		'name'  => 'Clone',
		'class' => 'fa fa-clone',
	],
	[
		'name'  => 'Balance Scale',
		'class' => 'fa fa-balance-scale',
	],
	[
		'name'  => 'Hourglass Outlined',
		'class' => 'fa fa-hourglass-o',
	],
	[
		'name'  => 'Hourglass Start',
		'class' => 'fa fa-hourglass-start',
	],
	[
		'name'  => 'Hourglass Half',
		'class' => 'fa fa-hourglass-half',
	],
	[
		'name'  => 'Hourglass End',
		'class' => 'fa fa-hourglass-end',
	],
	[
		'name'  => 'Hourglass',
		'class' => 'fa fa-hourglass',
	],
	[
		'name'  => 'Rock (Hand)',
		'class' => 'fa fa-hand-rock-o',
	],
	[
		'name'  => 'Paper (Hand)',
		'class' => 'fa fa-hand-paper-o',
	],
	[
		'name'  => 'Scissors (Hand)',
		'class' => 'fa fa-hand-scissors-o',
	],
	[
		'name'  => 'Lizard (Hand)',
		'class' => 'fa fa-hand-lizard-o',
	],
	[
		'name'  => 'Spock (Hand)',
		'class' => 'fa fa-hand-spock-o',
	],
	[
		'name'  => 'Hand Pointer',
		'class' => 'fa fa-hand-pointer-o',
	],
	[
		'name'  => 'Hand Peace',
		'class' => 'fa fa-hand-peace-o',
	],
	[
		'name'  => 'Trademark',
		'class' => 'fa fa-trademark',
	],
	[
		'name'  => 'Registered Trademark',
		'class' => 'fa fa-registered',
	],
	[
		'name'  => 'Creative Commons',
		'class' => 'fa fa-creative-commons',
	],
	[
		'name'  => 'GG Currency',
		'class' => 'fa fa-gg',
	],
	[
		'name'  => 'GG Currency Circle',
		'class' => 'fa fa-gg-circle',
	],
	[
		'name'  => 'TripAdvisor',
		'class' => 'fa fa-tripadvisor',
	],
	[
		'name'  => 'Odnoklassniki',
		'class' => 'fa fa-odnoklassniki',
	],
	[
		'name'  => 'Odnoklassniki Square',
		'class' => 'fa fa-odnoklassniki-square',
	],
	[
		'name'  => 'Get Pocket',
		'class' => 'fa fa-get-pocket',
	],
	[
		'name'  => 'Wikipedia W',
		'class' => 'fa fa-wikipedia-w',
	],
	[
		'name'  => 'Safari',
		'class' => 'fa fa-safari',
	],
	[
		'name'  => 'Chrome',
		'class' => 'fa fa-chrome',
	],
	[
		'name'  => 'Firefox',
		'class' => 'fa fa-firefox',
	],
	[
		'name'  => 'Opera',
		'class' => 'fa fa-opera',
	],
	[
		'name'  => 'Internet-explorer',
		'class' => 'fa fa-internet-explorer',
	],
	[
		'name'  => 'Television',
		'class' => 'fa fa-television',
	],
	[
		'name'  => 'Contao',
		'class' => 'fa fa-contao',
	],
	[
		'name'  => '500px',
		'class' => 'fa fa-500px',
	],
	[
		'name'  => 'Amazon',
		'class' => 'fa fa-amazon',
	],
	[
		'name'  => 'Calendar Plus Outlined',
		'class' => 'fa fa-calendar-plus-o',
	],
	[
		'name'  => 'Calendar Minus Outlined',
		'class' => 'fa fa-calendar-minus-o',
	],
	[
		'name'  => 'Calendar Times Outlined',
		'class' => 'fa fa-calendar-times-o',
	],
	[
		'name'  => 'Calendar Check Outlined',
		'class' => 'fa fa-calendar-check-o',
	],
	[
		'name'  => 'Industry',
		'class' => 'fa fa-industry',
	],
	[
		'name'  => 'Map Pin',
		'class' => 'fa fa-map-pin',
	],
	[
		'name'  => 'Map Signs',
		'class' => 'fa fa-map-signs',
	],
	[
		'name'  => 'Map Outlined',
		'class' => 'fa fa-map-o',
	],
	[
		'name'  => 'Map',
		'class' => 'fa fa-map',
	],
	[
		'name'  => 'Commenting',
		'class' => 'fa fa-commenting',
	],
	[
		'name'  => 'Commenting Outlined',
		'class' => 'fa fa-commenting-o',
	],
	[
		'name'  => 'Houzz',
		'class' => 'fa fa-houzz',
	],
	[
		'name'  => 'Vimeo',
		'class' => 'fa fa-vimeo',
	],
	[
		'name'  => 'Font Awesome Black Tie',
		'class' => 'fa fa-black-tie',
	],
	[
		'name'  => 'Fonticons',
		'class' => 'fa fa-fonticons',
	],
	[
		'name'  => 'reddit Alien',
		'class' => 'fa fa-reddit-alien',
	],
	[
		'name'  => 'Edge Browser',
		'class' => 'fa fa-edge',
	],
	[
		'name'  => 'Credit Card',
		'class' => 'fa fa-credit-card-alt',
	],
	[
		'name'  => 'Codie Pie',
		'class' => 'fa fa-codiepie',
	],
	[
		'name'  => 'MODX',
		'class' => 'fa fa-modx',
	],
	[
		'name'  => 'Fort Awesome',
		'class' => 'fa fa-fort-awesome',
	],
	[
		'name'  => 'USB',
		'class' => 'fa fa-usb',
	],
	[
		'name'  => 'Product Hunt',
		'class' => 'fa fa-product-hunt',
	],
	[
		'name'  => 'Mixcloud',
		'class' => 'fa fa-mixcloud',
	],
	[
		'name'  => 'Scribd',
		'class' => 'fa fa-scribd',
	],
	[
		'name'  => 'Pause Circle',
		'class' => 'fa fa-pause-circle',
	],
	[
		'name'  => 'Pause Circle Outlined',
		'class' => 'fa fa-pause-circle-o',
	],
	[
		'name'  => 'Stop Circle',
		'class' => 'fa fa-stop-circle',
	],
	[
		'name'  => 'Stop Circle Outlined',
		'class' => 'fa fa-stop-circle-o',
	],
	[
		'name'  => 'Shopping Bag',
		'class' => 'fa fa-shopping-bag',
	],
	[
		'name'  => 'Shopping Basket',
		'class' => 'fa fa-shopping-basket',
	],
	[
		'name'  => 'Hashtag',
		'class' => 'fa fa-hashtag',
	],
	[
		'name'  => 'Bluetooth',
		'class' => 'fa fa-bluetooth',
	],
	[
		'name'  => 'Bluetooth',
		'class' => 'fa fa-bluetooth-b',
	],
	[
		'name'  => 'Percent',
		'class' => 'fa fa-percent',
	],
	[
		'name'  => 'GitLab',
		'class' => 'fa fa-gitlab',
	],
	[
		'name'  => 'WPBeginner',
		'class' => 'fa fa-wpbeginner',
	],
	[
		'name'  => 'WPForms',
		'class' => 'fa fa-wpforms',
	],
	[
		'name'  => 'Envira Gallery',
		'class' => 'fa fa-envira',
	],
	[
		'name'  => 'Universal Access',
		'class' => 'fa fa-universal-access',
	],
	[
		'name'  => 'Wheelchair Alt',
		'class' => 'fa fa-wheelchair-alt',
	],
	[
		'name'  => 'Question Circle Outlined',
		'class' => 'fa fa-question-circle-o',
	],
	[
		'name'  => 'Blind',
		'class' => 'fa fa-blind',
	],
	[
		'name'  => 'Audio Description',
		'class' => 'fa fa-audio-description',
	],
	[
		'name'  => 'Volume Control Phone',
		'class' => 'fa fa-volume-control-phone',
	],
	[
		'name'  => 'Braille',
		'class' => 'fa fa-braille',
	],
	[
		'name'  => 'Assistive Listening Systems',
		'class' => 'fa fa-assistive-listening-systems',
	],
	[
		'name'  => 'American Sign Language Interpreting',
		'class' => 'fa fa-american-sign-language-interpreting',
	],
	[
		'name'  => 'Deaf',
		'class' => 'fa fa-deaf',
	],
	[
		'name'  => 'Glide',
		'class' => 'fa fa-glide',
	],
	[
		'name'  => 'Glide G',
		'class' => 'fa fa-glide-g',
	],
	[
		'name'  => 'Sign Language',
		'class' => 'fa fa-sign-language',
	],
	[
		'name'  => 'Low Vision',
		'class' => 'fa fa-low-vision',
	],
	[
		'name'  => 'Viadeo',
		'class' => 'fa fa-viadeo',
	],
	[
		'name'  => 'Viadeo Square',
		'class' => 'fa fa-viadeo-square',
	],
	[
		'name'  => 'Snapchat',
		'class' => 'fa fa-snapchat',
	],
	[
		'name'  => 'Snapchat Ghost',
		'class' => 'fa fa-snapchat-ghost',
	],
	[
		'name'  => 'Snapchat Square',
		'class' => 'fa fa-snapchat-square',
	],
	[
		'name'  => 'Pied Piper Logo',
		'class' => 'fa fa-pied-piper',
	],
	[
		'name'  => 'First Order',
		'class' => 'fa fa-first-order',
	],
	[
		'name'  => 'Yoast',
		'class' => 'fa fa-yoast',
	],
	[
		'name'  => 'ThemeIsle',
		'class' => 'fa fa-themeisle',
	],
	[
		'name'  => 'Google Plus Official',
		'class' => 'fa fa-google-plus-official',
	],
	[
		'name'  => 'Font Awesome',
		'class' => 'fa fa-font-awesome',
	],
	[
		'name'  => 'Handshake Outlined',
		'class' => 'fa fa-handshake-o',
	],
	[
		'name'  => 'Envelope Open',
		'class' => 'fa fa-envelope-open',
	],
	[
		'name'  => 'Envelope Open Outlined',
		'class' => 'fa fa-envelope-open-o',
	],
	[
		'name'  => 'Linode',
		'class' => 'fa fa-linode',
	],
	[
		'name'  => 'Address Book',
		'class' => 'fa fa-address-book',
	],
	[
		'name'  => 'Address Book Outlined',
		'class' => 'fa fa-address-book-o',
	],
	[
		'name'  => 'Address Card',
		'class' => 'fa fa-address-card',
	],
	[
		'name'  => 'Address Card Outlined',
		'class' => 'fa fa-address-card-o',
	],
	[
		'name'  => 'User Circle',
		'class' => 'fa fa-user-circle',
	],
	[
		'name'  => 'User Circle Outlined',
		'class' => 'fa fa-user-circle-o',
	],
	[
		'name'  => 'User Outlined',
		'class' => 'fa fa-user-o',
	],
	[
		'name'  => 'Identification Badge',
		'class' => 'fa fa-id-badge',
	],
	[
		'name'  => 'Identification Card',
		'class' => 'fa fa-id-card',
	],
	[
		'name'  => 'Identification Card Outlined',
		'class' => 'fa fa-id-card-o',
	],
	[
		'name'  => 'Quora',
		'class' => 'fa fa-quora',
	],
	[
		'name'  => 'Free Code Camp',
		'class' => 'fa fa-free-code-camp',
	],
	[
		'name'  => 'Telegram',
		'class' => 'fa fa-telegram',
	],
	[
		'name'  => 'Thermometer Full',
		'class' => 'fa fa-thermometer-full',
	],
	[
		'name'  => 'Thermometer 3/4 Full',
		'class' => 'fa fa-thermometer-three-quarters',
	],
	[
		'name'  => 'Thermometer 1/2 Full',
		'class' => 'fa fa-thermometer-half',
	],
	[
		'name'  => 'Thermometer 1/4 Full',
		'class' => 'fa fa-thermometer-quarter',
	],
	[
		'name'  => 'Thermometer Empty',
		'class' => 'fa fa-thermometer-empty',
	],
	[
		'name'  => 'Shower',
		'class' => 'fa fa-shower',
	],
	[
		'name'  => 'Bath',
		'class' => 'fa fa-bath',
	],
	[
		'name'  => 'Podcast',
		'class' => 'fa fa-podcast',
	],
	[
		'name'  => 'Window Maximize',
		'class' => 'fa fa-window-maximize',
	],
	[
		'name'  => 'Window Minimize',
		'class' => 'fa fa-window-minimize',
	],
	[
		'name'  => 'Window Restore',
		'class' => 'fa fa-window-restore',
	],
	[
		'name'  => 'Window Close',
		'class' => 'fa fa-window-close',
	],
	[
		'name'  => 'Window Close Outline',
		'class' => 'fa fa-window-close-o',
	],
	[
		'name'  => 'Bandcamp',
		'class' => 'fa fa-bandcamp',
	],
	[
		'name'  => 'Grav',
		'class' => 'fa fa-grav',
	],
	[
		'name'  => 'Etsy',
		'class' => 'fa fa-etsy',
	],
	[
		'name'  => 'IMDB',
		'class' => 'fa fa-imdb',
	],
	[
		'name'  => 'Ravelry',
		'class' => 'fa fa-ravelry',
	],
	[
		'name'  => 'Eercast',
		'class' => 'fa fa-eercast',
	],
	[
		'name'  => 'Microchip',
		'class' => 'fa fa-microchip',
	],
	[
		'name'  => 'Snowflake Outlined',
		'class' => 'fa fa-snowflake-o',
	],
	[
		'name'  => 'Superpowers',
		'class' => 'fa fa-superpowers',
	],
	[
		'name'  => 'WPExplorer',
		'class' => 'fa fa-wpexplorer',
	],
	[
		'name'  => 'Meetup',
		'class' => 'fa fa-meetup',
	],
];
