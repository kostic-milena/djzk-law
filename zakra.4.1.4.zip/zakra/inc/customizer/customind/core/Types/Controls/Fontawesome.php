<?php
/**
 * Fontawesome control class.
 */
namespace Customind\Core\Types\Controls;

/**
 * Fontawesome control class.
 */
class Fontawesome extends AbstractControl {

	/**
	 * {@inheritDoc}
	 */
	public $type = 'customind-fontawesome';
}
