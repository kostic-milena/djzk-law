<?php
/**
 * Radio image control class.
 */
namespace Customind\Core\Types\Controls;

/**
 * Radio image control class.
 */
class RadioImage extends AbstractControl {
	/**
	 * {@inheritDoc}
	 */
	public $type = 'customind-radio-image';
}
