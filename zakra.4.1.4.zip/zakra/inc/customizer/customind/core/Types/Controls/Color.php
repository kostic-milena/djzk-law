<?php

namespace Customind\Core\Types\Controls;

class Color extends AbstractControl {
	public $type = 'customind-color';
}
