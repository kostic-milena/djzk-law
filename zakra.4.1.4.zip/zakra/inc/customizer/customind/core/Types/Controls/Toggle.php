<?php
/**
 * Toggle class.
 */
namespace Customind\Core\Types\Controls;

/**
 * Toggle class.
 */
class Toggle extends AbstractControl {

	/**
	 * {@inheritDoc}
	 */
	public $type = 'customind-toggle';
}
